extern const char CCACHE_VERSION[];
const char CCACHE_VERSION[] = "4.10.2";

# CMake generated Testfile for 
# Source directory: /usr/lib/cjson/ptest/fuzzing
# Build directory: /usr/lib/cjson/ptest/fuzzing
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.

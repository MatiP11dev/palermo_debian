# CMake generated Testfile for 
# Source directory: /usr/lib/cjson/ptest
# Build directory: /usr/lib/cjson/ptest
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(cJSON_test "/usr/lib/cjson/ptest/cJSON_test")
set_tests_properties(cJSON_test PROPERTIES  _BACKTRACE_TRIPLES "/usr/lib/cjson/ptest/CMakeLists.txt;248;add_test;/usr/lib/cjson/ptest/CMakeLists.txt;0;")
subdirs("tests")
subdirs("fuzzing")

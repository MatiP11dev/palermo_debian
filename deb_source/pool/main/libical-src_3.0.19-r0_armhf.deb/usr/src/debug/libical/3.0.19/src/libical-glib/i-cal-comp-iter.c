/* Generated file (by generator) */

/*
 * Copyright (C) 2015 William Yu <williamyu@gnome.org>
 *
 * This library is free software: you can redistribute it and/or modify it
 * under the terms of version 2.1. of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <https://www.gnu.org/licenses/>.
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "i-cal-comp-iter.h"
#include "libical-glib-private.h"

G_DEFINE_TYPE (ICalCompIter, i_cal_comp_iter, I_CAL_TYPE_OBJECT)

static void i_cal_comp_iter_class_init (G_GNUC_UNUSED ICalCompIterClass *klass)
{
}

static void i_cal_comp_iter_init (G_GNUC_UNUSED ICalCompIter *self)
{
}

/**
 * i_cal_comp_iter_new_full: (skip)
 * @native: The native libical object.
 *
 * Create a new libical-glib object from the native libical object and the owner.
 *
 * Returns: (transfer full): The newly create libical-glib object.
 *
 * Since: 1.0
 **/
ICalCompIter *
i_cal_comp_iter_new_full (struct icalcompiter native)
{
    ICalCompIter *object;
    struct icalcompiter *clone;
    
    
    clone = g_new (struct icalcompiter, 1);
    *clone = native;
    object = i_cal_object_construct (I_CAL_TYPE_COMP_ITER,
                            (gpointer) clone,
                            (GDestroyNotify) g_free,
                            FALSE,
                            NULL);

    return object;
}


/**
 * i_cal_comp_iter_new_default: (skip)
 *
 * Returns: (transfer none): The newly created default native icalcompiter
 *
 * Since: 1.0
 *
 **/
struct icalcompiter
i_cal_comp_iter_new_default (void)
{
        icalcompiter compiter;
        compiter.iter = 0;
        compiter.kind = ICAL_NO_COMPONENT;
        return compiter;
}

/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_GISCANNER_SCANNERPARSER_H_INCLUDED
# define YY_YY_GISCANNER_SCANNERPARSER_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    BASIC_TYPE = 258,              /* BASIC_TYPE  */
    IDENTIFIER = 259,              /* "identifier"  */
    TYPEDEF_NAME = 260,            /* "typedef-name"  */
    INTEGER = 261,                 /* INTEGER  */
    FLOATING = 262,                /* FLOATING  */
    BOOLEAN = 263,                 /* BOOLEAN  */
    CHARACTER = 264,               /* CHARACTER  */
    STRING = 265,                  /* STRING  */
    INTL_CONST = 266,              /* INTL_CONST  */
    INTUL_CONST = 267,             /* INTUL_CONST  */
    ELLIPSIS = 268,                /* ELLIPSIS  */
    ADDEQ = 269,                   /* ADDEQ  */
    SUBEQ = 270,                   /* SUBEQ  */
    MULEQ = 271,                   /* MULEQ  */
    DIVEQ = 272,                   /* DIVEQ  */
    MODEQ = 273,                   /* MODEQ  */
    XOREQ = 274,                   /* XOREQ  */
    ANDEQ = 275,                   /* ANDEQ  */
    OREQ = 276,                    /* OREQ  */
    SL = 277,                      /* SL  */
    SR = 278,                      /* SR  */
    SLEQ = 279,                    /* SLEQ  */
    SREQ = 280,                    /* SREQ  */
    EQ = 281,                      /* EQ  */
    NOTEQ = 282,                   /* NOTEQ  */
    LTEQ = 283,                    /* LTEQ  */
    GTEQ = 284,                    /* GTEQ  */
    ANDAND = 285,                  /* ANDAND  */
    OROR = 286,                    /* OROR  */
    PLUSPLUS = 287,                /* PLUSPLUS  */
    MINUSMINUS = 288,              /* MINUSMINUS  */
    ARROW = 289,                   /* ARROW  */
    AUTO = 290,                    /* AUTO  */
    BREAK = 291,                   /* BREAK  */
    CASE = 292,                    /* CASE  */
    CONST = 293,                   /* CONST  */
    CONTINUE = 294,                /* CONTINUE  */
    DEFAULT = 295,                 /* DEFAULT  */
    DO = 296,                      /* DO  */
    ELSE = 297,                    /* ELSE  */
    ENUM = 298,                    /* ENUM  */
    EXTENSION = 299,               /* EXTENSION  */
    EXTERN = 300,                  /* EXTERN  */
    FOR = 301,                     /* FOR  */
    GOTO = 302,                    /* GOTO  */
    IF = 303,                      /* IF  */
    INLINE = 304,                  /* INLINE  */
    REGISTER = 305,                /* REGISTER  */
    RESTRICT = 306,                /* RESTRICT  */
    RETURN = 307,                  /* RETURN  */
    SHORT = 308,                   /* SHORT  */
    SIGNED = 309,                  /* SIGNED  */
    SIZEOF = 310,                  /* SIZEOF  */
    STATIC = 311,                  /* STATIC  */
    STRUCT = 312,                  /* STRUCT  */
    SWITCH = 313,                  /* SWITCH  */
    THREAD_LOCAL = 314,            /* THREAD_LOCAL  */
    TYPEDEF = 315,                 /* TYPEDEF  */
    UNION = 316,                   /* UNION  */
    UNSIGNED = 317,                /* UNSIGNED  */
    VOID = 318,                    /* VOID  */
    VOLATILE = 319,                /* VOLATILE  */
    WHILE = 320,                   /* WHILE  */
    FUNCTION_MACRO = 321,          /* FUNCTION_MACRO  */
    OBJECT_MACRO = 322,            /* OBJECT_MACRO  */
    IFDEF_GI_SCANNER = 323,        /* IFDEF_GI_SCANNER  */
    IFNDEF_GI_SCANNER = 324,       /* IFNDEF_GI_SCANNER  */
    IFDEF_COND = 325,              /* IFDEF_COND  */
    IFNDEF_COND = 326,             /* IFNDEF_COND  */
    IF_COND = 327,                 /* IF_COND  */
    ELIF_COND = 328,               /* ELIF_COND  */
    ELSE_COND = 329,               /* ELSE_COND  */
    ENDIF_COND = 330               /* ENDIF_COND  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 254 "../gobject-introspection-1.82.0/giscanner/scannerparser.y"

  char *str;
  GList *list;
  GISourceSymbol *symbol;
  GISourceType *ctype;
  StorageClassSpecifier storage_class_specifier;
  TypeQualifier type_qualifier;
  FunctionSpecifier function_specifier;
  UnaryOperator unary_operator;

#line 150 "giscanner/scannerparser.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (GISourceScanner* scanner);


#endif /* !YY_YY_GISCANNER_SCANNERPARSER_H_INCLUDED  */

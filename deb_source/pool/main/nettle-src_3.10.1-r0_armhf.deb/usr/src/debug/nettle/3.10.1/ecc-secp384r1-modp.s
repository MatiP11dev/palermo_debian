







	.file "ecc-secp384r1-modp.asm"
	.arm















	
	
	.text
	.align 2

.globl _nettle_ecc_secp384r1_modp
.type _nettle_ecc_secp384r1_modp,%function
_nettle_ecc_secp384r1_modp: 
	push	{r4,r5,r6,r7,r8,r10,r11,lr}

	add	r2, r2, #80
	ldm	r2, {r0, r3, r4, r5}	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	adds	r6, r0, r3
	adcs	r7, r3, #0
	adcs	r8, r5, #0
	subs	r6, r6, r5
	sbcs	r7, r7, #0
	sbcs	r8, r8, #0

	
	
	
	

	mov	r11, #0
	adds	r7, r7, r4
	adcs	r8, r8, r4
	adcs	r10, r5, #0
	adcs	r11, r11, #0

	
	sub	r2, r2, #32
	ldm	r2, {r0, r3, r4, r5}	
	mov	lr, #0
	adds	r6, r0, r6
	adcs	r7, r3, r7
	adcs	r8, r4, r8
	adcs	r10, r5, r10
	adcs	r11, r11, #0			

	
	sub	r2, r2, #48
	ldm	r2, {r0, r3, r4, r5}	
	mov	lr, #0
	adds	r0, r0, r6
	adcs	r3, r3, r7
	adcs	r4, r4, r8
	adcs	r5, r5, r10
	adc	lr, lr, #0
	subs	r3, r3, r6
	sbcs	r4, r4, r7
	sbcs	r5, r5, r8
	sbc	lr, lr, #0
	adds	r5, r5, r6
	adc	lr, lr, #0
	
	stm	r2!, {r0,r3,r4,r5}	
	mov	r12, #2
.Loop:
	ldm	r2, {r0,r3,r4,r5}	

	
	adds	r0, r0, lr
	asr	lr, #31		
	adcs	r3, r3, lr
	adcs	r4, r4, lr
	adcs	r5, r5, lr
	adc	lr, lr, #0

	
	adds	r0, r0, r6
	adcs	r3, r3, r7
	adcs	r4, r4, r8
	adcs	r5, r5, r10
	adc	lr, lr, #0

	
	ldr	r6, [r2, #+48]		
	adds	r0, r0, r7
	adcs	r3, r3, r8
	adcs	r4, r4, r10
	adcs	r5, r5, r6
	adc	lr, lr, #0

	
	ldr	r7, [r2, #+52]		
	ldr	r8, [r2, #+56]
	subs	r0, r0, r10
	sbcs	r3, r3, r6
	sbcs	r4, r4, r7
	sbcs	r5, r5, r8
	sbcs	lr, lr, #0

	
	ldr	r10, [r2, #+60]		
	adds	r0, r0, r6
	adcs	r3, r3, r7
	adcs	r4, r4, r8
	adcs	r5, r5, r10
	adc	lr, lr, #0
	subs	r12, r12, #1
	stm	r2!, {r0,r3,r4,r5}
	bne	.Loop

	
	
	
	
	
	
	sub	r2, r2, #48

	ldm	r2, {r0,r3,r4,r5}	

	
	
	
	
	
	
	
	
	
	
	
	
	

	
	mov	r6, lr		
	asr	lr, #31
	subs	r7, lr, r6	
	sbc	r8, r8, r8	
	sbc	r10, r6, #0	

	adds	r0, r0, r6
	adcs	r3, r3, r7
	adcs	r4, r4, r8
	adcs	r5, r5, r10
	adc	lr, lr, r6	

	stm	r2!, {r0,r3,r4,r5}	
	ldm	r2, {r0,r3,r4,r5}	
	
	
	
	
	
	rsbs	r7, r11, #0
	sbc	r8, r8, r8
	sbc	r10, r11, #0

	
	adds	r6, r11, lr
	asr	lr, lr, #31	
	adcs	r7, r7, lr
	adcs	r8, r8, lr
	adcs	r10, r10, lr
	adcs	r11, r11, lr
	adc	lr, lr, #0
	
	adds	r0, r0, r6
	adcs	r3, r3, r7
	adcs	r4, r4, r8
	adcs	r5, r5, r10

	stm	r2!, {r0,r3,r4,r5}	
	ldm	r2, {r0,r3,r4,r5}	

	adcs	r0, r0, r11
	adcs	r3, r3, lr
	adcs	r4, r4, lr
	adcs	r5, r5, lr
	adc	lr, lr, #0
	
	stm	r2, {r0,r3,r4,r5}	

	
	sub	r2, r2, #32
	ldm	r2!, {r0,r3,r4,r5}	
	
	mov	r6, lr
	asr	lr, #31
	subs	r7, lr, r6
	sbc	r8, r8, r8
	sbc	r10, r6, #0
	add	r11, r6, lr

	adds	r0, r0, r6
	adcs	r3, r3, r7
	adcs	r4, r4, r8
	adcs	r5, r5, r10
	
	stm	r1!, {r0,r3,r4,r5}	
	ldm	r2!, {r0,r3,r4,r5}	
	adcs	r0, r0, r11
	adcs	r3, r3, lr
	adcs	r4, r4, lr
	adcs	r5, r5, lr
	stm	r1!, {r0,r3,r4,r5}	
	ldm	r2, {r0,r3,r4,r5}	
	adcs	r0, r0, lr
	adcs	r3, r3, lr
	adcs	r4, r4, lr
	adcs	r5, r5, lr
	stm	r1, {r0,r3,r4,r5}	
	pop	{r4,r5,r6,r7,r8,r10,r11,pc}
.size _nettle_ecc_secp384r1_modp, . - _nettle_ecc_secp384r1_modp


.section .note.GNU-stack,"",%progbits

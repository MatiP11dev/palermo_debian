







	.file "ecc-secp192r1-modp.asm"
	.arm

 











 




	
	.text
	.align 2

.globl _nettle_ecc_secp192r1_modp
.type _nettle_ecc_secp192r1_modp,%function
_nettle_ecc_secp192r1_modp: 
	push	{r4,r5,r6,r7,r8,r10,r11}
	
	add	r0, r2, #48
	add	r2, r2, #8
	ldmdb	r0!, {r3,r4}
	ldm	r2, {r5,r6,r7,r8,r10,r11}
	mov	r12, #0
	adds	r7, r7, r3
	adcs	r8, r8, r4
	adcs	r10, r10, r3
	adcs	r11, r11, r4
	
	adc	r12, r12, #0

	ldmdb	r0!, {r3,r4}
	mov	r0, #0
	adcs	r5, r5, r3
	adcs	r6, r6, r4
	adcs	r7, r7, r3
	adcs	r8, r8, r4
	
	adc	r0, r0, #0

	ldmdb	r2!, {r3, r4}
	adcs	r3, r3, r10
	adcs	r4, r4, r11
	adcs	r5, r5, r10
	adcs	r6, r6, r11
	adc	r12, r12, #0

	adds	r5, r5, r0
	adcs	r6, r6, #0
	adcs	r7, r7, r12
	adcs	r8, r8, #0
	mov	r0, #0
	adc	r0, r0, #0

	
	adcs	r3, r3, #0
	adcs	r4, r4, #0
	adcs	r5, r5, r0
	adcs	r6, r6, #0
	adcs	r7, r7, #0
	adc	r8, r8, #0

	stm	r1, {r3,r4,r5,r6,r7,r8}

	pop	{r4,r5,r6,r7,r8,r10,r11}
	bx	lr
.size _nettle_ecc_secp192r1_modp, . - _nettle_ecc_secp192r1_modp


.section .note.GNU-stack,"",%progbits

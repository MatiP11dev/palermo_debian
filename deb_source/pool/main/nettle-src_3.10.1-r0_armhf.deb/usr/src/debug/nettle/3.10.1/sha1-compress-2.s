














	.file "sha1-compress.asm"
	.arch armv6

























	
	
	.text
	.align 2
.LK1:
	.int	0x5A827999
.LK2:
	.int	0x6ED9EBA1
.LK3:
	.int	0x8F1BBCDC

.globl _nettle_sha1_compress_armv6
.type _nettle_sha1_compress_armv6,%function
_nettle_sha1_compress_armv6: 
	push	{r4,r5,r6,r7,r8,r10,lr}
	sub	sp, sp, #64

	
	
	
	
	ands	r8, r1, #3
	and	r1, r1, $-4
	ldr	r10, [r1]
	addne	r1, r1, #4	
	lsl	r8, r8, #3
	mov	r7, #0
	movne	r7, #-1
	lsl	r12, r7, r8

	uadd8	r7, r7, r12		
	
	

	
	ldr	lr, .LK1
	ldm	r0, {r2,r3,r4,r5,r6}
	
	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#0]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	eor	r7, r7, r5
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#4]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	eor	r7, r7, r4
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#8]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	eor	r7, r7, r3
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#12]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	eor	r7, r7, r2
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#16]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	eor	r7, r7, r6
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#20]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	eor	r7, r7, r5
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#24]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	eor	r7, r7, r4
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#28]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	eor	r7, r7, r3
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#32]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	eor	r7, r7, r2
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#36]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	eor	r7, r7, r6
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#40]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	eor	r7, r7, r5
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#44]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	eor	r7, r7, r4
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#48]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	eor	r7, r7, r3
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#52]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	eor	r7, r7, r2
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#56]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	eor	r7, r7, r6
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r7, [r1], #+4
	sel	r12, r10, r7
	ror	r12, r12, r8
	mov	r10, r7
	rev	r12, r12
	str	r12, [SP,#60]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	eor	r7, r7, r5
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+0]
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+0]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	eor	r7, r7, r4
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+4]
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+4]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	eor	r7, r7, r3
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+8]
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+8]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	eor	r7, r7, r2
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+12]
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+12]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	eor	r7, r7, r6
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	ldr	lr, .LK2
	
	ldr	r12, [sp, #+16]
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+16]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+20]
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+20]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+24]
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+24]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+28]
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+28]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+32]
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+32]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+36]
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+36]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+40]
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+40]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+44]
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+44]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+48]
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+48]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+52]
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+52]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+56]
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+56]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+60]
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+60]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+0]
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+0]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+4]
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+4]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+8]
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+8]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+12]
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+12]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+16]
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+16]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+20]
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+20]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+24]
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+24]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+28]
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+28]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	ldr	lr, .LK3
	
	ldr	r12, [sp, #+32]
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+32]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	add	r6, r6, r7
	add	r6, r6, r12
	and	r7, r4, r5
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+36]
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+36]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	add	r5, r5, r7
	add	r5, r5, r12
	and	r7, r3, r4
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+40]
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+40]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	add	r4, r4, r7
	add	r4, r4, r12
	and	r7, r2, r3
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+44]
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+44]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	add	r3, r3, r7
	add	r3, r3, r12
	and	r7, r6, r2
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+48]
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+48]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	add	r2, r2, r7
	add	r2, r2, r12
	and	r7, r5, r6
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+52]
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+52]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	add	r6, r6, r7
	add	r6, r6, r12
	and	r7, r4, r5
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+56]
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+56]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	add	r5, r5, r7
	add	r5, r5, r12
	and	r7, r3, r4
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+60]
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+60]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	add	r4, r4, r7
	add	r4, r4, r12
	and	r7, r2, r3
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+0]
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+0]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	add	r3, r3, r7
	add	r3, r3, r12
	and	r7, r6, r2
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+4]
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+4]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	add	r2, r2, r7
	add	r2, r2, r12
	and	r7, r5, r6
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+8]
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+8]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	add	r6, r6, r7
	add	r6, r6, r12
	and	r7, r4, r5
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+12]
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+12]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	add	r5, r5, r7
	add	r5, r5, r12
	and	r7, r3, r4
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+16]
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+16]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	add	r4, r4, r7
	add	r4, r4, r12
	and	r7, r2, r3
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+20]
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+20]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	add	r3, r3, r7
	add	r3, r3, r12
	and	r7, r6, r2
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+24]
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+24]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	add	r2, r2, r7
	add	r2, r2, r12
	and	r7, r5, r6
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+28]
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+28]
 
	eor	r7, r4, r5
	add	r6, r6, lr
	and	r7, r7, r3
	add	r6, r6, r2, ror	#27
	add	r6, r6, r7
	add	r6, r6, r12
	and	r7, r4, r5
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+32]
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+32]
 
	eor	r7, r3, r4
	add	r5, r5, lr
	and	r7, r7, r2
	add	r5, r5, r6, ror	#27
	add	r5, r5, r7
	add	r5, r5, r12
	and	r7, r3, r4
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+36]
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+36]
 
	eor	r7, r2, r3
	add	r4, r4, lr
	and	r7, r7, r6
	add	r4, r4, r5, ror	#27
	add	r4, r4, r7
	add	r4, r4, r12
	and	r7, r2, r3
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+40]
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+40]
 
	eor	r7, r6, r2
	add	r3, r3, lr
	and	r7, r7, r5
	add	r3, r3, r4, ror	#27
	add	r3, r3, r7
	add	r3, r3, r12
	and	r7, r6, r2
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+44]
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+44]
 
	eor	r7, r5, r6
	add	r2, r2, lr
	and	r7, r7, r4
	add	r2, r2, r3, ror	#27
	add	r2, r2, r7
	add	r2, r2, r12
	and	r7, r5, r6
	ror	r4, r4, #2
	add	r2, r2, r7


	ldr	lr, .LK4
	
	ldr	r12, [sp, #+48]
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+48]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+52]
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+52]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+56]
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+56]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+60]
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+60]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+0]
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+0]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+4]
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+4]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+8]
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+8]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+12]
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+12]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+16]
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+16]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+20]
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+20]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+24]
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+24]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+28]
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+28]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+32]
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+32]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+36]
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+36]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+40]
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ldr	r7, [sp, #+8]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+40]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldr	r12, [sp, #+44]
	ldr	r7, [sp, #+52]
	eor	r12, r12, r7
	ldr	r7, [sp, #+12]
	eor	r12, r12, r7
	ldr	r7, [sp, #+32]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+44]
 
	eor	r7, r3, r5
	add	r6, r6, lr
	eor	r7, r7, r4
	add	r6, r6, r2, ror	#27
	add	r6, r6, r12
	ror	r3, r3, #2
	add	r6, r6, r7

	
	ldr	r12, [sp, #+48]
	ldr	r7, [sp, #+56]
	eor	r12, r12, r7
	ldr	r7, [sp, #+16]
	eor	r12, r12, r7
	ldr	r7, [sp, #+36]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+48]
 
	eor	r7, r2, r4
	add	r5, r5, lr
	eor	r7, r7, r3
	add	r5, r5, r6, ror	#27
	add	r5, r5, r12
	ror	r2, r2, #2
	add	r5, r5, r7

	
	ldr	r12, [sp, #+52]
	ldr	r7, [sp, #+60]
	eor	r12, r12, r7
	ldr	r7, [sp, #+20]
	eor	r12, r12, r7
	ldr	r7, [sp, #+40]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+52]
 
	eor	r7, r6, r3
	add	r4, r4, lr
	eor	r7, r7, r2
	add	r4, r4, r5, ror	#27
	add	r4, r4, r12
	ror	r6, r6, #2
	add	r4, r4, r7

	
	ldr	r12, [sp, #+56]
	ldr	r7, [sp, #+0]
	eor	r12, r12, r7
	ldr	r7, [sp, #+24]
	eor	r12, r12, r7
	ldr	r7, [sp, #+44]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+56]
 
	eor	r7, r5, r2
	add	r3, r3, lr
	eor	r7, r7, r6
	add	r3, r3, r4, ror	#27
	add	r3, r3, r12
	ror	r5, r5, #2
	add	r3, r3, r7

	
	ldr	r12, [sp, #+60]
	ldr	r7, [sp, #+4]
	eor	r12, r12, r7
	ldr	r7, [sp, #+28]
	eor	r12, r12, r7
	ldr	r7, [sp, #+48]
	eor	r12, r12, r7
	ror	r12, r12, #31
	str	r12, [sp, #+60]
 
	eor	r7, r4, r6
	add	r2, r2, lr
	eor	r7, r7, r5
	add	r2, r2, r3, ror	#27
	add	r2, r2, r12
	ror	r4, r4, #2
	add	r2, r2, r7


	
	ldm	r0, {r1,r7,r8,r12,lr}
	add	r2, r2, r1
	add	r3, r3, r7
	add	r4, r4, r8
	add	r5, r5, r12
	add	r6, r6, lr
	add	sp, sp, #64
	stm	r0, {r2,r3,r4,r5,r6}
	pop	{r4,r5,r6,r7,r8,r10,pc}	
.size _nettle_sha1_compress_armv6, . - _nettle_sha1_compress_armv6

.LK4:
	.int	0xCA62C1D6



.section .note.GNU-stack,"",%progbits









	.file "ecc-secp521r1-modp.asm"
	.arm














	
	.text
.Lc511:
	.int 511

	.align 2

.globl _nettle_ecc_secp521r1_modp
.type _nettle_ecc_secp521r1_modp,%function
_nettle_ecc_secp521r1_modp: 
	push	{r4,r5,r6,r7,r8,r10,lr}

	
	ldr	r10, [r2, #+68]		
	add	r0, r2, #72		
	ldr	r3, [r2]		
	adds	r3, r3, r10, lsl	#23
	str	r3, [r2], #+4
	mov	lr, #5

	
	
.Loop:
	ldm	r2, {r3,r4,r5}		
	lsr	r6, r10, #9
	ldm	r0!, {r7,r8,r10}		
	orr	r6, r6, r7, lsl #23
	lsr	r7, r7, #9
	orr	r7, r7, r8, lsl #23
	lsr	r8, r8, #9
	orr	r8, r8, r10, lsl #23
	adcs	r3, r3, r6
	adcs	r4, r4, r7
	adcs	r5, r5, r8
	sub	lr, lr, #1
	stm	r2!,{r3,r4,r5}
	teq	lr, #0
	bne	.Loop

	ldr	r6, [r2], #-64		
	ldr	r7, [r0]		
	ldr	r3, .Lc511

	
	
	adcs	r6, r6, r10, lsr #9
	
	and	r12, r6, r3
	mov	r6, r6, rrx
	lsr	r6, r6, #8
	
	adds	r6, r6, r7, lsl #14
	lsr	r7, r7, #18
	adc	r7, r7, #0

	ldm	r2!, {r3, r4}		
	adds	r3, r3, r6
	adcs	r4, r4, r7
	stm	r1!, {r3, r4}

	ldm	r2!, {r3,r4,r5,r6,r7,r8,r10}	
	adcs	r3, r3, #0
	adcs	r4, r4, #0
	adcs	r5, r5, #0
	adcs	r6, r6, #0
	adcs	r7, r7, #0
	adcs	r8, r8, #0
	adcs	r10, r10, #0
	stm	r1!, {r3,r4,r5,r6,r7,r8,r10}	
	ldm	r2, {r3,r4,r5,r6,r7,r8,r10}	
	adcs	r3, r3, #0
	adcs	r4, r4, #0
	adcs	r5, r5, #0
	adcs	r6, r6, #0
	adcs	r7, r7, #0
	adcs	r8, r8, #0
	adcs	r10, r10, #0
	adcs	r12, r12, #0
	stm	r1, {r3,r4,r5,r6,r7,r8,r10,r12}	

	pop	{r4,r5,r6,r7,r8,r10,pc}
.size _nettle_ecc_secp521r1_modp, . - _nettle_ecc_secp521r1_modp


.section .note.GNU-stack,"",%progbits
















	.file "sha3-permute.asm"
	.fpu	neon



















































	.text
	.align	3
.Lrc:
	.quad	0x0000000000000001
	.quad	0x0000000000008082
	.quad	0x800000000000808A
	.quad	0x8000000080008000
	.quad	0x000000000000808B
	.quad	0x0000000080000001
	.quad	0x8000000080008081
	.quad	0x8000000000008009
	.quad	0x000000000000008A
	.quad	0x0000000000000088
	.quad	0x0000000080008009
	.quad	0x000000008000000A
	.quad	0x000000008000808B
	.quad	0x800000000000008B
	.quad	0x8000000000008089
	.quad	0x8000000000008003
	.quad	0x8000000000008002
	.quad	0x8000000000000080
	.quad	0x000000000000800A
	.quad	0x800000008000000A
	.quad	0x8000000080008081
	.quad	0x8000000000008080
	.quad	0x0000000080000001
	.quad	0x8000000080008008
	
.globl _nettle_sha3_permute_neon
.type _nettle_sha3_permute_neon,%function
_nettle_sha3_permute_neon: 
	vpush	{d8-d15}

	vld1.64	{d0}, [r0]!
	vldm	r0!, {d6,d7,d8,d9}
	vld1.64	{d2}, [r0]!
	vldm	r0!, {d16,d17,d18,d19}
	vld1.64	{d3}, [r0]!
	vldm	r0!, {d20,d21,d22,d23}
	vld1.64	{d4}, [r0]!
	vldm	r0!, {d24,d25,d26,d27}
	vld1.64	{d5}, [r0]!
	vldm	r0, {d28,d29,d30,d31}
	sub	r0, r0, #168

	mov	r1, #24
	adr	r2, .Lrc

	.align 3
.Loop:
	veor	q5, q1, q2
	veor	d1, d0, d10
	veor	d1, d1, d11
	veor	q6, q3, q8
	veor	q6, q6, q10
	veor	q6, q6, q12
	veor	q6, q6, q14

	veor	q7, q4, q9
	veor	q7, q7, q11
	veor	q7, q7, q13
	veor	q7, q7, q15

	
	
 	vshl.i64	d10, d12, #1
 	vshr.u64	d11, d12, #63
	veor	d10, d10, d15
	veor	d10, d10, d11
	vmov	d11, d10
	veor	d0, d0, d10
	veor	q1, q1, q5
	veor	q2, q2, q5
	
	
	
	
	vshr.u64	d10, d13, #63
	vsli.i64	d10, d13, #1
	
	
	vshr.u64	d11, d14, #63
	vsli.i64	d11, d14, #1
	
	veor	d10, d10, d1
	veor	d11, d11, d12
	veor	q3, q3, q5
	veor	q8, q8, q5
	veor	q10, q10, q5
	veor	q12, q12, q5
	veor	q14, q14, q5

	
	
	
	vshr.u64	d10, d15, #63
	vsli.i64	d10, d15, #1
	
	
	vshr.u64	d11, d1, #63
	vsli.i64	d11, d1, #1
	
	veor	d10, d10, d13
	veor	d11, d11, d14
	veor	q4, q4, q5
	veor	q9, q9, q5
	veor	q11, q11, q5
	veor	q13, q13, q5
	veor	q15, q15, q5

	
	vshr.u64	d10, d6, #63
	vsli.i64	d10, d6, #1
	
	
	vshr.u64	d6, d16, #20
	vsli.i64	d6, d16, #44
	
	
	vshr.u64	d16, d19, #44
	vsli.i64	d16, d19, #20
	
	
	vshr.u64	d19, d29, #3
	vsli.i64	d19, d29, #61
	
	
	vshr.u64	d29, d23, #25
	vsli.i64	d29, d23, #39
	
	
	vshr.u64	d23, d5, #46
	vsli.i64	d23, d5, #18
	
	
	vshr.u64	d5, d7, #2
	vsli.i64	d5, d7, #62
	
	
	vshr.u64	d7, d21, #21
	vsli.i64	d7, d21, #43
	
	
	vshr.u64	d21, d22, #39
	vsli.i64	d21, d22, #25
	
	
	vshr.u64	d22, d27, #56
	vsli.i64	d22, d27, #8
	
	
	vshr.u64	d27, d30, #8
	vsli.i64	d27, d30, #56
	
	
	vshr.u64	d30, d4, #23
	vsli.i64	d30, d4, #41
	
	
	vshr.u64	d4, d9, #37
	vsli.i64	d4, d9, #27
	
	
	vshr.u64	d9, d31, #50
	vsli.i64	d9, d31, #14
	
	
	vshr.u64	d31, d28, #62
	vsli.i64	d31, d28, #2
	
	
	vshr.u64	d28, d18, #9
	vsli.i64	d28, d18, #55
	
	
	vshr.u64	d18, d24, #19
	vsli.i64	d18, d24, #45
	
	
	vshr.u64	d24, d2, #28
	vsli.i64	d24, d2, #36
	
	
	vshr.u64	d2, d8, #36
	vsli.i64	d2, d8, #28
	
	
	vshr.u64	d8, d26, #43
	vsli.i64	d8, d26, #21
	
	
	vshr.u64	d26, d25, #49
	vsli.i64	d26, d25, #15
	
	
	vshr.u64	d25, d20, #54
	vsli.i64	d25, d20, #10
	
	
	vshr.u64	d20, d17, #58
	vsli.i64	d20, d17, #6
	
	
	vshr.u64	d17, d3, #61
	vsli.i64	d17, d3, #3
	
	

	vbic	d1, d7, d6
	vbic	d12, d8, d7
	vbic	d13, d9, d8
	vbic	d14, d0, d9
	vbic	d15, d6, d0

	veor	d0, d0, d1
	vld1.64	{d1}, [r2 :64]!
	veor	q3, q3, q6
	veor	q4, q4, q7
	veor	d0, d0, d1

	vbic	d1, d17, d16
	vbic	d12, d18, d17
	vbic	d13, d19, d18
	vbic	d14, d2, d19
	vbic	d15, d16, d2

	veor	d2, d2, d1
	veor	q8, q8, q6
	veor	q9, q9, q7

	vbic	d1, d21, d20
	vbic	d12, d22, d21
	vbic	d13, d23, d22
	vbic	d14, d10, d23
	vbic	d15, d20, d10

	veor	d3, d10, d1
	veor	q10, q10, q6
	veor	q11, q11, q7

	vbic	d1, d25, d24
	vbic	d12, d26, d25
	vbic	d13, d27, d26
	vbic	d14, d4, d27
	vbic	d15, d24, d4

	veor	d4, d4, d1
	veor	q12, q12, q6
	veor	q13, q13, q7

	vbic	d1, d29, d28
	vbic	d12, d30, d29
	vbic	d13, d31, d30
	vbic	d14, d5, d31
	vbic	d15, d28, d5

	subs	r1, r1, #1
	veor	d5, d5, d1
	veor	q14, q14, q6
	veor	q15, q15, q7

	bne	.Loop

	vst1.64	{d0}, [r0]!
	vstm	r0!, {d6,d7,d8,d9}
	vst1.64	{d2}, [r0]!
	vstm	r0!, {d16,d17,d18,d19}
	vst1.64	{d3}, [r0]!
	vstm	r0!, {d20,d21,d22,d23}
	vst1.64	{d4}, [r0]!
	vstm	r0!, {d24,d25,d26,d27}
	vst1.64	{d5}, [r0]!
	vstm	r0, {d28,d29,d30,d31}
	
	vpop	{d8-d15}
	bx	lr
.size _nettle_sha3_permute_neon, . - _nettle_sha3_permute_neon



.section .note.GNU-stack,"",%progbits

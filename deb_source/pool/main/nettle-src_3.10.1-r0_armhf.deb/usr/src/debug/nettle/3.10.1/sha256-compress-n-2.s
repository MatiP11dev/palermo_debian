














	.file "sha256-compress-n.asm"
	.arch armv6





	








	
	






























	.text
	.align 2








	
	
	

.globl _nettle_sha256_compress_n_armv6
.type _nettle_sha256_compress_n_armv6,%function
_nettle_sha256_compress_n_armv6: 
	cmp	r2, #0
	bne	.Lwork

	mov	r0, r3
	bx lr

.Lwork:
	
	push	{r0,r1,r2,r4,r5,r6,r7,r8,r10,r11,r12,r14}
	sub	sp, sp, #76

	
	
	ands	r10, r3, #3
	and	r3, r3, $-4
	ldr	r2, [r3]
	addne	r3, r3, #4
	lsl	r10, r10, #3
	mov	r12, #0
	movne	r12, #-1
	lsl	r4, r12, r10

	uadd8	r12, r12, r4		
	
	


	str	r10, [sp, #64]

.Loop_block:
	mov	r8, sp
	mov	r11, #4
.Lcopy:
	ldm	r3!, {r4,r5,r6,r7}
	sel	r2, r2, r4
	ror	r2, r2, r10
	rev	r2, r2
	sel	r4, r4, r5
	ror	r4, r4, r10
	rev	r4, r4
	sel	r5, r5, r6
	ror	r5, r5, r10
	rev	r5, r5
	sel	r6, r6, r7
	ror	r6, r6, r10
	rev	r6, r6
	subs	r11, r11, #1
	stm	r8!, {r2,r4,r5,r6}
	mov	r2, r7	
	bne	.Lcopy

	str	r3, [sp, #68]
	str	r2, [sp, #72]

	

	ldm	r0, {r2,r4,r5,r6,r7,r8,r10,r11}

	mov	r0,#0

.Loop1:
	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r7, #6
	eor	r12, r12, r7, ror #11
	eor	r12, r12, r7, ror #25
	add	r11, r11, r12
	eor	r12, r8, r10
	and	r12, r12, r7
	eor	r12, r12, r10
	add	r11,r11, r12
	ldr	r12, [r1], #+4
	add	r11, r11, r14
	add	r11, r11, r12
	add	r6, r6, r11
	ror	r12, r2, #2
	eor	r12, r12, r2, ror #13
	eor	r12, r12, r2, ror #22
	add	r11, r11, r12
	and	r12, r2, r4
	add	r11, r11, r12
	eor	r12, r2, r4
	and	r12, r12, r5
	add	r11, r11, r12

	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r6, #6
	eor	r12, r12, r6, ror #11
	eor	r12, r12, r6, ror #25
	add	r10, r10, r12
	eor	r12, r7, r8
	and	r12, r12, r6
	eor	r12, r12, r8
	add	r10,r10, r12
	ldr	r12, [r1], #+4
	add	r10, r10, r14
	add	r10, r10, r12
	add	r5, r5, r10
	ror	r12, r11, #2
	eor	r12, r12, r11, ror #13
	eor	r12, r12, r11, ror #22
	add	r10, r10, r12
	and	r12, r11, r2
	add	r10, r10, r12
	eor	r12, r11, r2
	and	r12, r12, r4
	add	r10, r10, r12

	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r5, #6
	eor	r12, r12, r5, ror #11
	eor	r12, r12, r5, ror #25
	add	r8, r8, r12
	eor	r12, r6, r7
	and	r12, r12, r5
	eor	r12, r12, r7
	add	r8,r8, r12
	ldr	r12, [r1], #+4
	add	r8, r8, r14
	add	r8, r8, r12
	add	r4, r4, r8
	ror	r12, r10, #2
	eor	r12, r12, r10, ror #13
	eor	r12, r12, r10, ror #22
	add	r8, r8, r12
	and	r12, r10, r11
	add	r8, r8, r12
	eor	r12, r10, r11
	and	r12, r12, r2
	add	r8, r8, r12

	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r4, #6
	eor	r12, r12, r4, ror #11
	eor	r12, r12, r4, ror #25
	add	r7, r7, r12
	eor	r12, r5, r6
	and	r12, r12, r4
	eor	r12, r12, r6
	add	r7,r7, r12
	ldr	r12, [r1], #+4
	add	r7, r7, r14
	add	r7, r7, r12
	add	r2, r2, r7
	ror	r12, r8, #2
	eor	r12, r12, r8, ror #13
	eor	r12, r12, r8, ror #22
	add	r7, r7, r12
	and	r12, r8, r10
	add	r7, r7, r12
	eor	r12, r8, r10
	and	r12, r12, r11
	add	r7, r7, r12

	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r2, #6
	eor	r12, r12, r2, ror #11
	eor	r12, r12, r2, ror #25
	add	r6, r6, r12
	eor	r12, r4, r5
	and	r12, r12, r2
	eor	r12, r12, r5
	add	r6,r6, r12
	ldr	r12, [r1], #+4
	add	r6, r6, r14
	add	r6, r6, r12
	add	r11, r11, r6
	ror	r12, r7, #2
	eor	r12, r12, r7, ror #13
	eor	r12, r12, r7, ror #22
	add	r6, r6, r12
	and	r12, r7, r8
	add	r6, r6, r12
	eor	r12, r7, r8
	and	r12, r12, r10
	add	r6, r6, r12

	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r11, #6
	eor	r12, r12, r11, ror #11
	eor	r12, r12, r11, ror #25
	add	r5, r5, r12
	eor	r12, r2, r4
	and	r12, r12, r11
	eor	r12, r12, r4
	add	r5,r5, r12
	ldr	r12, [r1], #+4
	add	r5, r5, r14
	add	r5, r5, r12
	add	r10, r10, r5
	ror	r12, r6, #2
	eor	r12, r12, r6, ror #13
	eor	r12, r12, r6, ror #22
	add	r5, r5, r12
	and	r12, r6, r7
	add	r5, r5, r12
	eor	r12, r6, r7
	and	r12, r12, r8
	add	r5, r5, r12

	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r10, #6
	eor	r12, r12, r10, ror #11
	eor	r12, r12, r10, ror #25
	add	r4, r4, r12
	eor	r12, r11, r2
	and	r12, r12, r10
	eor	r12, r12, r2
	add	r4,r4, r12
	ldr	r12, [r1], #+4
	add	r4, r4, r14
	add	r4, r4, r12
	add	r8, r8, r4
	ror	r12, r5, #2
	eor	r12, r12, r5, ror #13
	eor	r12, r12, r5, ror #22
	add	r4, r4, r12
	and	r12, r5, r6
	add	r4, r4, r12
	eor	r12, r5, r6
	and	r12, r12, r7
	add	r4, r4, r12

	
	ldr	r14, [sp, + r0]
	add	r0, r0, #4
 
	ror	r12, r8, #6
	eor	r12, r12, r8, ror #11
	eor	r12, r12, r8, ror #25
	add	r2, r2, r12
	eor	r12, r10, r11
	and	r12, r12, r8
	eor	r12, r12, r11
	add	r2,r2, r12
	ldr	r12, [r1], #+4
	add	r2, r2, r14
	add	r2, r2, r12
	add	r7, r7, r2
	ror	r12, r4, #2
	eor	r12, r12, r4, ror #13
	eor	r12, r12, r4, ror #22
	add	r2, r2, r12
	and	r12, r4, r5
	add	r2, r2, r12
	eor	r12, r4, r5
	and	r12, r12, r6
	add	r2, r2, r12

	cmp	r0,#64
	bne	.Loop1

	mov	r0, #3
.Loop2:
	
	
	ldr	r14, [sp, #+0]
	ldr	r12, [sp, #+56]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+36]
	add	r14, r14, r12
	ldr	r12, [sp, #+4]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+0]
 
	ror	r12, r7, #6
	eor	r12, r12, r7, ror #11
	eor	r12, r12, r7, ror #25
	add	r11, r11, r12
	eor	r12, r8, r10
	and	r12, r12, r7
	eor	r12, r12, r10
	add	r11,r11, r12
	ldr	r12, [r1], #+4
	add	r11, r11, r14
	add	r11, r11, r12
	add	r6, r6, r11
	ror	r12, r2, #2
	eor	r12, r12, r2, ror #13
	eor	r12, r12, r2, ror #22
	add	r11, r11, r12
	and	r12, r2, r4
	add	r11, r11, r12
	eor	r12, r2, r4
	and	r12, r12, r5
	add	r11, r11, r12

	
	ldr	r14, [sp, #+4]
	ldr	r12, [sp, #+60]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+40]
	add	r14, r14, r12
	ldr	r12, [sp, #+8]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+4]
 
	ror	r12, r6, #6
	eor	r12, r12, r6, ror #11
	eor	r12, r12, r6, ror #25
	add	r10, r10, r12
	eor	r12, r7, r8
	and	r12, r12, r6
	eor	r12, r12, r8
	add	r10,r10, r12
	ldr	r12, [r1], #+4
	add	r10, r10, r14
	add	r10, r10, r12
	add	r5, r5, r10
	ror	r12, r11, #2
	eor	r12, r12, r11, ror #13
	eor	r12, r12, r11, ror #22
	add	r10, r10, r12
	and	r12, r11, r2
	add	r10, r10, r12
	eor	r12, r11, r2
	and	r12, r12, r4
	add	r10, r10, r12

	
	ldr	r14, [sp, #+8]
	ldr	r12, [sp, #+0]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+44]
	add	r14, r14, r12
	ldr	r12, [sp, #+12]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+8]
 
	ror	r12, r5, #6
	eor	r12, r12, r5, ror #11
	eor	r12, r12, r5, ror #25
	add	r8, r8, r12
	eor	r12, r6, r7
	and	r12, r12, r5
	eor	r12, r12, r7
	add	r8,r8, r12
	ldr	r12, [r1], #+4
	add	r8, r8, r14
	add	r8, r8, r12
	add	r4, r4, r8
	ror	r12, r10, #2
	eor	r12, r12, r10, ror #13
	eor	r12, r12, r10, ror #22
	add	r8, r8, r12
	and	r12, r10, r11
	add	r8, r8, r12
	eor	r12, r10, r11
	and	r12, r12, r2
	add	r8, r8, r12

	
	ldr	r14, [sp, #+12]
	ldr	r12, [sp, #+4]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+48]
	add	r14, r14, r12
	ldr	r12, [sp, #+16]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+12]
 
	ror	r12, r4, #6
	eor	r12, r12, r4, ror #11
	eor	r12, r12, r4, ror #25
	add	r7, r7, r12
	eor	r12, r5, r6
	and	r12, r12, r4
	eor	r12, r12, r6
	add	r7,r7, r12
	ldr	r12, [r1], #+4
	add	r7, r7, r14
	add	r7, r7, r12
	add	r2, r2, r7
	ror	r12, r8, #2
	eor	r12, r12, r8, ror #13
	eor	r12, r12, r8, ror #22
	add	r7, r7, r12
	and	r12, r8, r10
	add	r7, r7, r12
	eor	r12, r8, r10
	and	r12, r12, r11
	add	r7, r7, r12

	
	ldr	r14, [sp, #+16]
	ldr	r12, [sp, #+8]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+52]
	add	r14, r14, r12
	ldr	r12, [sp, #+20]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+16]
 
	ror	r12, r2, #6
	eor	r12, r12, r2, ror #11
	eor	r12, r12, r2, ror #25
	add	r6, r6, r12
	eor	r12, r4, r5
	and	r12, r12, r2
	eor	r12, r12, r5
	add	r6,r6, r12
	ldr	r12, [r1], #+4
	add	r6, r6, r14
	add	r6, r6, r12
	add	r11, r11, r6
	ror	r12, r7, #2
	eor	r12, r12, r7, ror #13
	eor	r12, r12, r7, ror #22
	add	r6, r6, r12
	and	r12, r7, r8
	add	r6, r6, r12
	eor	r12, r7, r8
	and	r12, r12, r10
	add	r6, r6, r12

	
	ldr	r14, [sp, #+20]
	ldr	r12, [sp, #+12]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+56]
	add	r14, r14, r12
	ldr	r12, [sp, #+24]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+20]
 
	ror	r12, r11, #6
	eor	r12, r12, r11, ror #11
	eor	r12, r12, r11, ror #25
	add	r5, r5, r12
	eor	r12, r2, r4
	and	r12, r12, r11
	eor	r12, r12, r4
	add	r5,r5, r12
	ldr	r12, [r1], #+4
	add	r5, r5, r14
	add	r5, r5, r12
	add	r10, r10, r5
	ror	r12, r6, #2
	eor	r12, r12, r6, ror #13
	eor	r12, r12, r6, ror #22
	add	r5, r5, r12
	and	r12, r6, r7
	add	r5, r5, r12
	eor	r12, r6, r7
	and	r12, r12, r8
	add	r5, r5, r12

	
	ldr	r14, [sp, #+24]
	ldr	r12, [sp, #+16]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+60]
	add	r14, r14, r12
	ldr	r12, [sp, #+28]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+24]
 
	ror	r12, r10, #6
	eor	r12, r12, r10, ror #11
	eor	r12, r12, r10, ror #25
	add	r4, r4, r12
	eor	r12, r11, r2
	and	r12, r12, r10
	eor	r12, r12, r2
	add	r4,r4, r12
	ldr	r12, [r1], #+4
	add	r4, r4, r14
	add	r4, r4, r12
	add	r8, r8, r4
	ror	r12, r5, #2
	eor	r12, r12, r5, ror #13
	eor	r12, r12, r5, ror #22
	add	r4, r4, r12
	and	r12, r5, r6
	add	r4, r4, r12
	eor	r12, r5, r6
	and	r12, r12, r7
	add	r4, r4, r12

	
	ldr	r14, [sp, #+28]
	ldr	r12, [sp, #+20]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+0]
	add	r14, r14, r12
	ldr	r12, [sp, #+32]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+28]
 
	ror	r12, r8, #6
	eor	r12, r12, r8, ror #11
	eor	r12, r12, r8, ror #25
	add	r2, r2, r12
	eor	r12, r10, r11
	and	r12, r12, r8
	eor	r12, r12, r11
	add	r2,r2, r12
	ldr	r12, [r1], #+4
	add	r2, r2, r14
	add	r2, r2, r12
	add	r7, r7, r2
	ror	r12, r4, #2
	eor	r12, r12, r4, ror #13
	eor	r12, r12, r4, ror #22
	add	r2, r2, r12
	and	r12, r4, r5
	add	r2, r2, r12
	eor	r12, r4, r5
	and	r12, r12, r6
	add	r2, r2, r12

	
	ldr	r14, [sp, #+32]
	ldr	r12, [sp, #+24]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+4]
	add	r14, r14, r12
	ldr	r12, [sp, #+36]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+32]
 
	ror	r12, r7, #6
	eor	r12, r12, r7, ror #11
	eor	r12, r12, r7, ror #25
	add	r11, r11, r12
	eor	r12, r8, r10
	and	r12, r12, r7
	eor	r12, r12, r10
	add	r11,r11, r12
	ldr	r12, [r1], #+4
	add	r11, r11, r14
	add	r11, r11, r12
	add	r6, r6, r11
	ror	r12, r2, #2
	eor	r12, r12, r2, ror #13
	eor	r12, r12, r2, ror #22
	add	r11, r11, r12
	and	r12, r2, r4
	add	r11, r11, r12
	eor	r12, r2, r4
	and	r12, r12, r5
	add	r11, r11, r12

	
	ldr	r14, [sp, #+36]
	ldr	r12, [sp, #+28]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+8]
	add	r14, r14, r12
	ldr	r12, [sp, #+40]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+36]
 
	ror	r12, r6, #6
	eor	r12, r12, r6, ror #11
	eor	r12, r12, r6, ror #25
	add	r10, r10, r12
	eor	r12, r7, r8
	and	r12, r12, r6
	eor	r12, r12, r8
	add	r10,r10, r12
	ldr	r12, [r1], #+4
	add	r10, r10, r14
	add	r10, r10, r12
	add	r5, r5, r10
	ror	r12, r11, #2
	eor	r12, r12, r11, ror #13
	eor	r12, r12, r11, ror #22
	add	r10, r10, r12
	and	r12, r11, r2
	add	r10, r10, r12
	eor	r12, r11, r2
	and	r12, r12, r4
	add	r10, r10, r12

	
	ldr	r14, [sp, #+40]
	ldr	r12, [sp, #+32]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+12]
	add	r14, r14, r12
	ldr	r12, [sp, #+44]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+40]
 
	ror	r12, r5, #6
	eor	r12, r12, r5, ror #11
	eor	r12, r12, r5, ror #25
	add	r8, r8, r12
	eor	r12, r6, r7
	and	r12, r12, r5
	eor	r12, r12, r7
	add	r8,r8, r12
	ldr	r12, [r1], #+4
	add	r8, r8, r14
	add	r8, r8, r12
	add	r4, r4, r8
	ror	r12, r10, #2
	eor	r12, r12, r10, ror #13
	eor	r12, r12, r10, ror #22
	add	r8, r8, r12
	and	r12, r10, r11
	add	r8, r8, r12
	eor	r12, r10, r11
	and	r12, r12, r2
	add	r8, r8, r12

	
	ldr	r14, [sp, #+44]
	ldr	r12, [sp, #+36]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+16]
	add	r14, r14, r12
	ldr	r12, [sp, #+48]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+44]
 
	ror	r12, r4, #6
	eor	r12, r12, r4, ror #11
	eor	r12, r12, r4, ror #25
	add	r7, r7, r12
	eor	r12, r5, r6
	and	r12, r12, r4
	eor	r12, r12, r6
	add	r7,r7, r12
	ldr	r12, [r1], #+4
	add	r7, r7, r14
	add	r7, r7, r12
	add	r2, r2, r7
	ror	r12, r8, #2
	eor	r12, r12, r8, ror #13
	eor	r12, r12, r8, ror #22
	add	r7, r7, r12
	and	r12, r8, r10
	add	r7, r7, r12
	eor	r12, r8, r10
	and	r12, r12, r11
	add	r7, r7, r12

	
	ldr	r14, [sp, #+48]
	ldr	r12, [sp, #+40]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+20]
	add	r14, r14, r12
	ldr	r12, [sp, #+52]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+48]
 
	ror	r12, r2, #6
	eor	r12, r12, r2, ror #11
	eor	r12, r12, r2, ror #25
	add	r6, r6, r12
	eor	r12, r4, r5
	and	r12, r12, r2
	eor	r12, r12, r5
	add	r6,r6, r12
	ldr	r12, [r1], #+4
	add	r6, r6, r14
	add	r6, r6, r12
	add	r11, r11, r6
	ror	r12, r7, #2
	eor	r12, r12, r7, ror #13
	eor	r12, r12, r7, ror #22
	add	r6, r6, r12
	and	r12, r7, r8
	add	r6, r6, r12
	eor	r12, r7, r8
	and	r12, r12, r10
	add	r6, r6, r12

	
	ldr	r14, [sp, #+52]
	ldr	r12, [sp, #+44]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+24]
	add	r14, r14, r12
	ldr	r12, [sp, #+56]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+52]
 
	ror	r12, r11, #6
	eor	r12, r12, r11, ror #11
	eor	r12, r12, r11, ror #25
	add	r5, r5, r12
	eor	r12, r2, r4
	and	r12, r12, r11
	eor	r12, r12, r4
	add	r5,r5, r12
	ldr	r12, [r1], #+4
	add	r5, r5, r14
	add	r5, r5, r12
	add	r10, r10, r5
	ror	r12, r6, #2
	eor	r12, r12, r6, ror #13
	eor	r12, r12, r6, ror #22
	add	r5, r5, r12
	and	r12, r6, r7
	add	r5, r5, r12
	eor	r12, r6, r7
	and	r12, r12, r8
	add	r5, r5, r12

	
	ldr	r14, [sp, #+56]
	ldr	r12, [sp, #+48]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+28]
	add	r14, r14, r12
	ldr	r12, [sp, #+60]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+56]
 
	ror	r12, r10, #6
	eor	r12, r12, r10, ror #11
	eor	r12, r12, r10, ror #25
	add	r4, r4, r12
	eor	r12, r11, r2
	and	r12, r12, r10
	eor	r12, r12, r2
	add	r4,r4, r12
	ldr	r12, [r1], #+4
	add	r4, r4, r14
	add	r4, r4, r12
	add	r8, r8, r4
	ror	r12, r5, #2
	eor	r12, r12, r5, ror #13
	eor	r12, r12, r5, ror #22
	add	r4, r4, r12
	and	r12, r5, r6
	add	r4, r4, r12
	eor	r12, r5, r6
	and	r12, r12, r7
	add	r4, r4, r12

	subs	r0, r0, #1
	
	ldr	r14, [sp, #+60]
	ldr	r12, [sp, #+52]
	ror	r3, r12, #17
	eor	r3, r3, r12, ror #19
	eor	r3, r3, r12, lsr #10
	add	r14, r14, r3
	ldr	r12, [sp, #+32]
	add	r14, r14, r12
	ldr	r12, [sp, #+0]
	ror	r3, r12, #7
	eor	r3, r3, r12, ror #18
	eor	r3, r3, r12, lsr #3
	add	r14, r14, r3
	str	r14, [sp, #+60]
 
	ror	r12, r8, #6
	eor	r12, r12, r8, ror #11
	eor	r12, r12, r8, ror #25
	add	r2, r2, r12
	eor	r12, r10, r11
	and	r12, r12, r8
	eor	r12, r12, r11
	add	r2,r2, r12
	ldr	r12, [r1], #+4
	add	r2, r2, r14
	add	r2, r2, r12
	add	r7, r7, r2
	ror	r12, r4, #2
	eor	r12, r12, r4, ror #13
	eor	r12, r12, r4, ror #22
	add	r2, r2, r12
	and	r12, r4, r5
	add	r2, r2, r12
	eor	r12, r4, r5
	and	r12, r12, r6
	add	r2, r2, r12

	bne	.Loop2

	ldr	r0, [sp, #76]
	
	ldm	r0, {r1, r3, r12, r14}
	add	r2, r2, r1
	add	r4, r4, r3
	add	r5, r5, r12
	add	r6, r6, r14
	stm	r0!, {r2,r4,r5,r6}
	ldm	r0, {r1, r3, r12, r14}
	add	r7, r7, r1
	add	r8, r8, r3
	add	r10, r10, r12
	add	r11, r11, r14
	stm	r0, {r7,r8,r10,r11}
	sub	r0, r0, #16

	ldr	r2, [sp, #84]
	subs	r2, r2, #1
	str	r2, [sp, #84]

	ldr	r10, [sp, #64]
	ldr	r1, [sp, #80]
	ldr	r3, [sp, #68]
	ldr	r2, [sp, #72]

	bne	.Loop_block

	

 cmp	r10, #0
	subne	r3, r3, #4
	orr	r0, r3, r10, lsr #3

	
	add	sp, sp, #76 + 12
	pop	{r4,r5,r6,r7,r8,r10,r11,r12,pc}
.size _nettle_sha256_compress_n_armv6, . - _nettle_sha256_compress_n_armv6



.section .note.GNU-stack,"",%progbits

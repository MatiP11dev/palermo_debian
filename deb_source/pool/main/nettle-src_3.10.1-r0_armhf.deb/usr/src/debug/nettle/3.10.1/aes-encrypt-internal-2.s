













	.arch armv6









































	


	







	







	.file "aes-encrypt-internal.asm"
	
	
	
	
	
	.text
	.align 2

.globl _nettle_aes_encrypt_armv6
.type _nettle_aes_encrypt_armv6,%function
_nettle_aes_encrypt_armv6: 
	teq	r3, #0
	beq	.Lend

	ldr	r12, [sp, #+4]

	push	{r0,r1, r4,r5,r6,r7,r8,r10,r11,lr}

	.align 4

.Lblock_loop:
	ldm	sp, {r10, r11}

	add	r2, r2, #256

	
	ldrb	r4, [r12], #+1
	ldrb	r8, [r12], #+1
	orr	r4, r8, lsl #8
	ldrb	r8, [r12], #+1
	orr	r4, r8, lsl #16
	ldrb	r8, [r12], #+1
	orr	r4, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r4, r8

	
	ldrb	r5, [r12], #+1
	ldrb	r8, [r12], #+1
	orr	r5, r8, lsl #8
	ldrb	r8, [r12], #+1
	orr	r5, r8, lsl #16
	ldrb	r8, [r12], #+1
	orr	r5, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r5, r8

	
	ldrb	r6, [r12], #+1
	ldrb	r8, [r12], #+1
	orr	r6, r8, lsl #8
	ldrb	r8, [r12], #+1
	orr	r6, r8, lsl #16
	ldrb	r8, [r12], #+1
	orr	r6, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r6, r8

	
	ldrb	r7, [r12], #+1
	ldrb	r8, [r12], #+1
	orr	r7, r8, lsl #8
	ldrb	r8, [r12], #+1
	orr	r7, r8, lsl #16
	ldrb	r8, [r12], #+1
	orr	r7, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r7, r8


	str	r12, [sp, #+44]

	b	.Lentry
	.align 4

.Lround_loop:
	
	
	uxtb	r8, r0 
	ldr	r4, [r2, r8, lsl #2]
	uxtb	r8, r1
	ldr	r5, [r2, r8, lsl #2]
	uxtb	r8, r12
	ldr	r6, [r2, r8, lsl #2]
	uxtb	r8, r14
	ldr	r7, [r2, r8, lsl #2]

	uxtb	r8, r1, ror #8
	add	r2, r2, #1024
	ldr	r8, [r2, r8, lsl #2]
	eor	r4, r4, r8
	uxtb	r8, r12, ror #8
	ldr	r8, [r2, r8, lsl #2]
	eor	r5, r5, r8
	uxtb	r8, r14, ror #8
	ldr	r8, [r2, r8, lsl #2]
	eor	r6, r6, r8
	uxtb	r8, r0, ror #8
	ldr	r8, [r2, r8, lsl #2]
	eor	r7, r7, r8

	uxtb	r8, r12, ror #16
	add	r2, r2, #1024
	ldr	r8, [r2, r8, lsl #2]
	eor	r4, r4, r8
	uxtb	r8, r14, ror #16
	ldr	r8, [r2, r8, lsl #2]
	eor	r5, r5, r8
	uxtb	r8, r0, ror #16
	ldr	r8, [r2, r8, lsl #2]
	eor	r6, r6, r8
	uxtb	r8, r1, ror #16
	ldr	r8, [r2, r8, lsl #2]
	eor	r7, r7, r8

	uxtb	r8, r14, ror #24
	add	r2, r2, #1024
	ldr	r8, [r2, r8, lsl #2]
	eor	r4, r4, r8
	uxtb	r8, r0, ror #24
	ldr	r8, [r2, r8, lsl #2]
	eor	r5, r5, r8
	uxtb	r8, r1, ror #24
	ldr	r8, [r2, r8, lsl #2]
	eor	r6, r6, r8
	uxtb	r8, r12, ror #24
	ldr	r8, [r2, r8, lsl #2]

	ldm	r11!, {r0,r1,r12,r14}
	eor	r7, r7, r8
	sub	r2, r2, #3072
	eor	r4, r4, r0
	eor	r5, r5, r1
	eor	r6, r6, r12
	eor	r7, r7, r14

	
.Lentry:
	subs	r10, r10,#2
	
	
	uxtb	r8, r4 
	ldr	r0, [r2, r8, lsl #2]
	uxtb	r8, r5
	ldr	r1, [r2, r8, lsl #2]
	uxtb	r8, r6
	ldr	r12, [r2, r8, lsl #2]
	uxtb	r8, r7
	ldr	r14, [r2, r8, lsl #2]

	uxtb	r8, r5, ror #8
	add	r2, r2, #1024
	ldr	r8, [r2, r8, lsl #2]
	eor	r0, r0, r8
	uxtb	r8, r6, ror #8
	ldr	r8, [r2, r8, lsl #2]
	eor	r1, r1, r8
	uxtb	r8, r7, ror #8
	ldr	r8, [r2, r8, lsl #2]
	eor	r12, r12, r8
	uxtb	r8, r4, ror #8
	ldr	r8, [r2, r8, lsl #2]
	eor	r14, r14, r8

	uxtb	r8, r6, ror #16
	add	r2, r2, #1024
	ldr	r8, [r2, r8, lsl #2]
	eor	r0, r0, r8
	uxtb	r8, r7, ror #16
	ldr	r8, [r2, r8, lsl #2]
	eor	r1, r1, r8
	uxtb	r8, r4, ror #16
	ldr	r8, [r2, r8, lsl #2]
	eor	r12, r12, r8
	uxtb	r8, r5, ror #16
	ldr	r8, [r2, r8, lsl #2]
	eor	r14, r14, r8

	uxtb	r8, r7, ror #24
	add	r2, r2, #1024
	ldr	r8, [r2, r8, lsl #2]
	eor	r0, r0, r8
	uxtb	r8, r4, ror #24
	ldr	r8, [r2, r8, lsl #2]
	eor	r1, r1, r8
	uxtb	r8, r5, ror #24
	ldr	r8, [r2, r8, lsl #2]
	eor	r12, r12, r8
	uxtb	r8, r6, ror #24
	ldr	r8, [r2, r8, lsl #2]

	ldm	r11!, {r4,r5,r6,r7}
	eor	r14, r14, r8
	sub	r2, r2, #3072
	eor	r0, r0, r4
	eor	r1, r1, r5
	eor	r12, r12, r6
	eor	r14, r14, r7


	bne	.Lround_loop

	sub	r2, r2, #256

	
	ldr	r10, [sp, #+40]

	
	uxtb	r8, r0
	ldrb	r4, [r2, r8]
	uxtb	r8, r1, ror #8
	ldrb	r8, [r2, r8]
	eor	r4, r4, r8, lsl #8
	uxtb	r8, r12, ror #16
	ldrb	r8, [r2, r8]
	eor	r4, r4, r8, lsl #16
	ldrb	r8, [r2, r14, lsr #24]
	eor	r4, r4, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r4, r4, r8

	
	uxtb	r8, r1
	ldrb	r5, [r2, r8]
	uxtb	r8, r12, ror #8
	ldrb	r8, [r2, r8]
	eor	r5, r5, r8, lsl #8
	uxtb	r8, r14, ror #16
	ldrb	r8, [r2, r8]
	eor	r5, r5, r8, lsl #16
	ldrb	r8, [r2, r0, lsr #24]
	eor	r5, r5, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r5, r5, r8

	
	uxtb	r8, r12
	ldrb	r6, [r2, r8]
	uxtb	r8, r14, ror #8
	ldrb	r8, [r2, r8]
	eor	r6, r6, r8, lsl #8
	uxtb	r8, r0, ror #16
	ldrb	r8, [r2, r8]
	eor	r6, r6, r8, lsl #16
	ldrb	r8, [r2, r1, lsr #24]
	eor	r6, r6, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r6, r6, r8

	
	uxtb	r8, r14
	ldrb	r7, [r2, r8]
	uxtb	r8, r0, ror #8
	ldrb	r8, [r2, r8]
	eor	r7, r7, r8, lsl #8
	uxtb	r8, r1, ror #16
	ldrb	r8, [r2, r8]
	eor	r7, r7, r8, lsl #16
	ldrb	r8, [r2, r12, lsr #24]
	eor	r7, r7, r8, lsl #24
	ldr	r8, [r11], #+4
	eor	r7, r7, r8


	ldr	r12, [sp, #+44]
	
	
	strb	r4, [r10], #+1
	ror	r4, r4, #8
	strb	r4, [r10], #+1
	ror	r4, r4, #8
	strb	r4, [r10], #+1
	ror	r4, r4, #8
	strb	r4, [r10], #+1

	
	strb	r5, [r10], #+1
	ror	r5, r5, #8
	strb	r5, [r10], #+1
	ror	r5, r5, #8
	strb	r5, [r10], #+1
	ror	r5, r5, #8
	strb	r5, [r10], #+1

	
	strb	r6, [r10], #+1
	ror	r6, r6, #8
	strb	r6, [r10], #+1
	ror	r6, r6, #8
	strb	r6, [r10], #+1
	ror	r6, r6, #8
	strb	r6, [r10], #+1

	
	strb	r7, [r10], #+1
	ror	r7, r7, #8
	strb	r7, [r10], #+1
	ror	r7, r7, #8
	strb	r7, [r10], #+1
	ror	r7, r7, #8
	strb	r7, [r10], #+1


	str	r10, [sp, #+40]
	subs	r3, r3, #16
	bhi	.Lblock_loop

	add	sp, sp, #8	
	pop	{r4,r5,r6,r7,r8,r10,r11,pc}
	
.Lend:
	bx	lr
.size _nettle_aes_encrypt_armv6, . - _nettle_aes_encrypt_armv6



.section .note.GNU-stack,"",%progbits

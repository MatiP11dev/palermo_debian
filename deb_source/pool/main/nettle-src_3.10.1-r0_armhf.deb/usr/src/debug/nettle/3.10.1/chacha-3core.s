













	.file "chacha-3core.asm"
	.fpu	neon

























	.text
	.align 4
.Lcount1:
	.int 1,0,0,0

	

.globl _nettle_chacha_3core
.type _nettle_chacha_3core,%function
_nettle_chacha_3core: 
	
	add	r3, r1, #32
	vld1.32	{q0,q1}, [r1]
	vld1.32	{q2,q3}, [r3]
	vpush	{q4,q5,q6,q7}
	adr	r12, .Lcount1
	vld1.32 {q15}, [r12]

	vadd.i64	q11, q3, q15	
	vadd.i64	q15, q11, q15

.Lshared_entry:
	vmov	q8, q0
	vmov	q12, q0
	vmov	q9, q1
	vmov	q13, q1
	vmov	q10, q2
	vmov	q14, q2

	
	vmov	q6, q11
	vmov	q7, q15

.Loop:
	
	
	vadd.i32	q0, q0, q1
	veor		q3, q3, q0
	 vadd.i32	q8, q8, q9
	vrev32.16	q3, q3		
	 veor		q11, q11, q8
	  vadd.i32	q12, q12, q13

	vadd.i32	q2, q2, q3
	 vrev32.16	q11, q11		
	  veor		q15, q15, q12
	veor		q4, q1, q2
	 vadd.i32	q10, q10, q11
	  vrev32.16	q15, q15		
	vshl.i32	q1, q4, #12
	 veor		q5, q9, q10
	  vadd.i32	q14, q14, q15
	vsri.u32	q1, q4, #20
	 vshl.i32	q9, q5, #12
	  veor		q4, q13, q14

	vadd.i32	q0, q0, q1
	 vsri.u32	q9, q5, #20
	  vshl.i32	q13, q4, #12
	veor		q5, q3, q0
	 vadd.i32	q8, q8, q9
	  vsri.u32	q13, q4, #20
	vshl.i32	q3, q5, #8
	 veor		q4, q11, q8
	  vadd.i32	q12, q12, q13
	vsri.u32	q3, q5, #24
	 vshl.i32	q11, q4, #8
	  veor		q5, q15, q12

	vadd.i32	q2, q2, q3
	 vsri.u32	q11, q4, #24
	  vext.32	q3, q3, q3, #3
	  vshl.i32	q15, q5, #8
	veor		q4, q1, q2
	 vadd.i32	q10, q10, q11
	  vsri.u32	q15, q5, #24
	   vext.32	q11, q11, q11, #3
	vshl.i32	q1, q4, #7
	 veor		q5, q9, q10
	  vadd.i32	q14, q14, q15
	vsri.u32	q1, q4, #25
	 vshl.i32	q9, q5, #7
	  veor		q4, q13, q14
	   vext.32	q1, q1, q1, #1
	 vsri.u32	q9, q5, #25
	  vshl.i32	q13, q4, #7
	   vext.32	q10, q10, q10, #2
	   vext.32	q9, q9, q9, #1
	  vsri.u32	q13, q4, #25
	   vext.32	q2, q2, q2, #2

	
	vadd.i32	q0, q0, q1
	   vext.32	q14, q14, q14, #2
	   vext.32	q13, q13, q13, #1
	veor		q3, q3, q0
	 vadd.i32	q8, q8, q9
	   vext.32	q15, q15, q15, #3
	vrev32.16	q3, q3		
	 veor		q11, q11, q8
	  vadd.i32	q12, q12, q13

	vadd.i32	q2, q2, q3
	 vrev32.16	q11, q11		
	  veor		q15, q15, q12
	veor		q4, q1, q2
	 vadd.i32	q10, q10, q11
	  vrev32.16	q15, q15		
	vshl.i32	q1, q4, #12
	 veor		q5, q9, q10
	  vadd.i32	q14, q14, q15
	vsri.u32	q1, q4, #20
	 vshl.i32	q9, q5, #12
	  veor		q4, q13, q14

	vadd.i32	q0, q0, q1
	 vsri.u32	q9, q5, #20
	  vshl.i32	q13, q4, #12
	veor		q5, q3, q0
	 vadd.i32	q8, q8, q9
	  vsri.u32	q13, q4, #20
	vshl.i32	q3, q5, #8
	 veor		q4, q11, q8
	  vadd.i32	q12, q12, q13
	vsri.u32	q3, q5, #24
	 vshl.i32	q11, q4, #8
	  veor		q5, q15, q12

	vadd.i32	q2, q2, q3
	 vsri.u32	q11, q4, #24
	   vext.32	q3, q3, q3, #1
	  vshl.i32	q15, q5, #8
	veor		q4, q1, q2
	   vext.32	q2, q2, q2, #2
	 vadd.i32	q10, q10, q11
	   vext.32	q11, q11, q11, #1
	  vsri.u32	q15, q5, #24
	vshl.i32	q1, q4, #7
	 veor		q5, q9, q10
	   vext.32	q10, q10, q10, #2
	  vadd.i32	q14, q14, q15
	   vext.32	q15, q15, q15, #1
	vsri.u32	q1, q4, #25
	 vshl.i32	q9, q5, #7
	  veor		q4, q13, q14
	   vext.32	q14, q14, q14, #2
	   vext.32	q1, q1, q1, #3
	 vsri.u32	q9, q5, #25
	  vshl.i32	q13, q4, #7
	   vext.32	q9, q9, q9, #3
	  vsri.u32	q13, q4, #25

	subs	r2, r2, #2

	   vext.32	q13, q13, q13, #3

	bhi	.Loop

	
	vadd.i32	q11, q11, q6
	vadd.i32	q15, q15, q7

	vld1.32	{q4,q5}, [r1]
	vadd.i32	q0, q0, q4
	vadd.i32	q1, q1, q5

	
	
	


	vld1.32	{q6,q7}, [r3]
	vadd.i32	q2, q2, q6
	vadd.i32	q3, q3, q7

	vstmia	r0!, {q0,q1,q2,q3}

	vadd.i32	q8, q8, q4
	vadd.i32	q9, q9, q5


	vadd.i32	q10, q10, q6

	vstmia	r0!, {q8,q9,q10,q11}

	vadd.i32	q12, q12, q4
	vadd.i32	q13, q13, q5


	vadd.i32	q14, q14, q6

	vpop	{q4,q5,q6,q7}


	vstm	r0, {q12,q13,q14,q15}
	bx	lr
.size _nettle_chacha_3core, . - _nettle_chacha_3core

.globl _nettle_chacha_3core32
.type _nettle_chacha_3core32,%function
_nettle_chacha_3core32: 
	add	r3, r1, #32
	vld1.32	{q0,q1}, [r1]
	vld1.32	{q2,q3}, [r3]
	vpush	{q4,q5,q6,q7}
	adr	r12, .Lcount1
	vld1.32 {q15}, [r12]

	vadd.i32	q11, q3, q15	
	vadd.i32	q15, q11, q15
	b .Lshared_entry
.size _nettle_chacha_3core32, . - _nettle_chacha_3core32



.section .note.GNU-stack,"",%progbits















	.file "salsa20-2core.asm"
	.fpu	neon




















	.text
	.align 4
.Lcount1:
	.int 1,0,0,0

	
.globl _nettle_salsa20_2core
.type _nettle_salsa20_2core,%function
_nettle_salsa20_2core: 
	
	add	r3, r1, #32
	vld1.32	{q0,q1}, [r1]
	vld1.32	{q2,q3}, [r3]
	adr	r12, .Lcount1

	vmov	q11, q0
	vld1.32 {q9}, [r12]
	vmov	q8, q1
	vadd.i64 q9, q9, q2	
	vmov	q10, q3

	vtrn.32	q0, q11		
	vtrn.32	q1, q8		
	vtrn.32	q2, q9		
	vtrn.32	q3, q10		

	
	
	
	
	
	vswp	d1, d5
	vswp	d3, d7
	vswp	d17, d21
	vswp	d19, d23

.Loop:







	vadd.i32	q12, q0, q3
	vshl.i32	q13, q12, #7
	 vadd.i32	q14, q8, q11
	vsri.u32	q13, q12, #25
	 vshl.i32	q15, q14, #7
	veor		q1, q1, q13
	 vsri.u32	q15, q14, #25
	vadd.i32	q12, q1, q0
	 veor		q9, q9, q15
	vshl.i32	q13, q12, #9
	 vadd.i32	q14, q9, q8
	vsri.u32	q13, q12, #23
	 vshl.i32	q15, q14, #9
	veor		q2, q2, q13
	 vsri.u32	q15, q14, #23
	vadd.i32	q12, q2, q1
	 veor		q10, q10, q15
	vshl.i32	q13, q12, #13
	 vadd.i32	q14, q10, q9
	vsri.u32	q13, q12, #19
	 vshl.i32	q15, q14, #13
	veor		q3, q3, q13
	 vsri.u32	q15, q14, #19
	vadd.i32	q12, q3, q2
	 veor		q11, q11, q15
	vshl.i32	q13, q12, #18
	 vadd.i32	q14, q11, q10
	  vext.32	q9, q9, q9, #2
	vsri.u32	q13, q12, #14
	 vshl.i32	q15, q14, #18
	  vext.32	q10, q10, q10, #2
	veor		q0, q0, q13
	 vsri.u32	q15, q14, #14
	  vext.32	q3, q3, q3, #2
	 veor		q8, q8, q15







	vadd.i32	q12, q0, q9
	  vext.32	q2, q2, q2, #2
	vshl.i32	q13, q12, #7
	 vadd.i32	q14, q8, q1
	vsri.u32	q13, q12, #25
	 vshl.i32	q15, q14, #7
	veor		q11, q11, q13
	 vsri.u32	q15, q14, #25
	vadd.i32	q12, q11, q0
	 veor		q3, q3, q15
	vshl.i32	q13, q12, #9
	 vadd.i32	q14, q3, q8
	vsri.u32	q13, q12, #23
	 vshl.i32	q15, q14, #9
	veor		q2, q2, q13
	 vsri.u32	q15, q14, #23
	vadd.i32	q12, q2, q11
	 veor		q10, q10, q15
	vshl.i32	q13, q12, #13
	 vadd.i32	q14, q10, q3
	vsri.u32	q13, q12, #19
	 vshl.i32	q15, q14, #13
	veor		q9, q9, q13
	 vsri.u32	q15, q14, #19
	vadd.i32	q12, q9, q2
	 veor		q1, q1, q15
	  vext.32	q2, q2, q2, #2
	vshl.i32	q13, q12, #18
	 vadd.i32	q14, q1, q10
	  vext.32	q9, q9, q9, #2
	vsri.u32	q13, q12, #14
	   subs		r2, r2, #2
	 vshl.i32	q15, q14, #18
	  vext.32	q3, q3, q3, #2
	veor		q0, q0, q13
	 vsri.u32	q15, q14, #14
	  vext.32	q10, q10, q10, #2
	 veor		q8, q8, q15

	bhi		.Loop



	vswp	d1, d5
	vswp	d3, d7
	vswp	d17, d21
	vswp	d19, d23

	vld1.32	{q12,q13}, [r1]
	vld1.32	{q14,q15}, [r3]

	vtrn.32	q0, q11
	vtrn.32	q1, q8
	vtrn.32	q2, q9
	vtrn.32	q3, q10


	vadd.i32	q0, q0, q12
	vadd.i32	q1, q1, q13






	vadd.i32	q2, q2, q14
	vadd.i32	q3, q3, q15

	vstmia	r0!, {q0,q1,q2,q3}

	vld1.32 {q0}, [r12]
	vadd.i32	q12, q12, q11
	vadd.i64	q14, q14, q0
	vadd.i32	q13, q13, q8


	vadd.i32	q14, q14, q9
	vadd.i32	q15, q15, q10

	vstm	r0, {q12,q13,q14,q15}
	bx	lr
.size _nettle_salsa20_2core, . - _nettle_salsa20_2core



.section .note.GNU-stack,"",%progbits

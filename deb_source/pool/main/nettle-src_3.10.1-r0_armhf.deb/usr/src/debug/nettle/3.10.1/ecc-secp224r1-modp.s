







	.file "ecc-secp224r1-modp.asm"
	.arm

	

	













	
	.text
	.align 2

.globl _nettle_ecc_secp224r1_modp
.type _nettle_ecc_secp224r1_modp,%function
_nettle_ecc_secp224r1_modp: 
	
	push	{r1,r4,r5,r6,r7,r8,r10,r11,lr}

	add	lr, r2, #28
	ldm	lr, {r1,r3,r4,r5,r6,r7,r8}
	mov	r0, #0

	adds	r1, r1, r6
	adcs	r3, r3, r7
	adcs	r4, r4, r8
	adc	r0, r0, #0

	
	
	
	
	

	sbcs	r10, r5, r1
	sbcs	r6, r6, r3
	sbcs	r7, r7, r4
	sbcs	r8, r8, r0
	mov	r0, #1		
	sbc	r0, #0
	subs	r8, r8, r5
	sbc	r0, #0

	
	ldm	r2!, {r11,r12,lr}

	
	adds	r2, #0

	sbcs	r1, r11, r1
	sbcs	r3, r12, r3
	sbcs	r4, lr, r4
	ldm	r2!, {r5,r11,r12,lr}
	sbcs	r5, r5, r10
	sbcs	r6, r11, r6
	sbcs	r7, r12, r7
	sbcs	r8, lr, r8
	rsc	r0, r0, #0

	
	
	
	subs	r1, r1, r0
	asr	r12, r0, #1
	sbcs	r3, r3, r12
	eor	r0, r0, r12
	sbcs	r4, r4, r12
	sbcs	r5, r5, r0
	sbcs	r6, r6, #0
	sbcs	r7, r7, #0
	sbcs	r8, r8, #0
	sbcs	r0, r0, r0

	pop	{r2}	

	
	subs	r1, r1, r0
	sbcs	r3, r3, r0
	sbcs	r4, r4, r0
	sbcs	r5, r5, #0
	sbcs	r6, r6, #0
	sbcs	r7, r7, #0
	sbcs	r8, r8, #0

	stm	r2, {r1,r3,r4,r5,r6,r7,r8}

	pop	{r4,r5,r6,r7,r8,r10,r11,pc}
.size _nettle_ecc_secp224r1_modp, . - _nettle_ecc_secp224r1_modp


.section .note.GNU-stack,"",%progbits

BEGIN { print isarray(a) }

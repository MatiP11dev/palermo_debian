/\{/
# should be no warning

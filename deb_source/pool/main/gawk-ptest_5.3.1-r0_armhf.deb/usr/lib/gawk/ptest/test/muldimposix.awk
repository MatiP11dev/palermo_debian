BEGIN { a[1][2] = 3 }

BEGIN {
	delete FUNCTAB 
}

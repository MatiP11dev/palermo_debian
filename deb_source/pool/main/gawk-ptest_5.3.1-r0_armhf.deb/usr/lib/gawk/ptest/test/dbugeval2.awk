BEGIN {
	a = 2
	b = 3
}

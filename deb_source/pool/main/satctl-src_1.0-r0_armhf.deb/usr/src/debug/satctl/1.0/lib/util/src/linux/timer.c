/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#include <stdio.h>
#include <time.h>

#include <util/timer.h>

uint64_t timer_getmonotonic(void)
{
	struct timespec tp;

	clock_gettime(CLOCK_MONOTONIC, &tp);

	return (uint64_t)tp.tv_sec * NSEC_PER_SEC + tp.tv_nsec;
}

void timer_setrealtime(uint64_t now)
{
	struct timespec tp;

	tp.tv_sec = now / NSEC_PER_SEC;
	tp.tv_nsec = now % NSEC_PER_SEC;

	clock_settime(CLOCK_REALTIME, &tp);
}

uint64_t timer_getrealtime(void)
{
	struct timespec tp;

	clock_gettime(CLOCK_REALTIME, &tp);

	return (uint64_t)tp.tv_sec * NSEC_PER_SEC + tp.tv_nsec;
}

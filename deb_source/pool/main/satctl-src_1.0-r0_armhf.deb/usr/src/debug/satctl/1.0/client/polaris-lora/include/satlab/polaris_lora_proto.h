/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

/**
 * @file polaris_lora_proto.h
 *
 * This file specifies the available CSP services and ports on the Polaris
 * receiver. It should not be necessary for clients to use these definitions
 * directly. Instead, use the wrapper functions from this library which handles
 * the protocol and performs necessary byte order conversion.
 */

#ifndef _SL_POLARIS_LORA_CLIENT_PROTO_H_
#define _SL_POLARIS_LORA_CLIENT_PROTO_H_

#include <stdint.h>

/** Default CSP address */
#define SL_POLARIS_LORA_DEFAULT_ADDRESS		19

/** CSP ports */
#define SL_POLARIS_LORA_PORT_SAMPLEBUF		20
#define SL_POLARIS_LORA_PORT_STORE		21
#define SL_POLARIS_LORA_PORT_BOOTLOADER		25
#define SL_POLARIS_LORA_PORT_SHELL		26

/** Default mirror frame receive port */
#define SL_POLARIS_LORA_PORT_STORE_MIRROR_RECV	30

/** Error codes */
#define SL_POLARIS_LORA_ERR_NONE		0
#define SL_POLARIS_LORA_ERR_INVAL		1
#define SL_POLARIS_LORA_ERR_IO			2
#define SL_POLARIS_LORA_ERR_NOMEM		3
#define SL_POLARIS_LORA_ERR_BUSY		4

/* Generic packet types */
typedef struct {
	uint8_t type;
} __attribute__ ((packed)) sl_polaris_lora_req_t;

typedef struct {
	uint8_t type;
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_rep_t;

/*
 * SL_POLARIS_LORA_PORT_SAMPLEBUF
 */

/* Types */
#define SL_POLARIS_LORA_SAMPLEBUF_READ_REQ	1
#define SL_POLARIS_LORA_SAMPLEBUF_READ_REP	2
#define SL_POLARIS_LORA_SAMPLEBUF_READ_CHUNK	3
#define SL_POLARIS_LORA_SAMPLEBUF_FREE		4
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_REQ	5
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_REP	6

/* Sources */
#define SL_POLARIS_LORA_SAMPLEBUF_SOURCE_RAW	0
#define SL_POLARIS_LORA_SAMPLEBUF_SOURCE_CHAN	1

/* Destinations */
#define SL_POLARIS_LORA_SAMPLEBUF_DEST_CSP	0
#define SL_POLARIS_LORA_SAMPLEBUF_DEST_SDCARD	1

/* Flags */
#define SL_POLARIS_LORA_SAMPLEBUF_FL_FORCE_INTRAM	(1 << 0)

typedef struct {
	uint8_t type;
	uint8_t source;
	uint8_t dest;
	uint8_t flags;
	uint32_t id;
	uint32_t samples;
} __attribute__ ((packed)) sl_polaris_lora_samplebuf_read_req_t;

typedef struct {
	uint8_t type;
	uint8_t error;
	uint32_t id;
	uint32_t addr;
} __attribute__ ((packed)) sl_polaris_lora_samplebuf_read_rep_t;

#define SL_POLARIS_LORA_SAMPLEBUF_READ_CHUNK_SAMPLES	32
typedef struct {
	uint8_t type;
	uint8_t error;
	uint16_t seq;
	uint16_t total;
	uint32_t data[SL_POLARIS_LORA_SAMPLEBUF_READ_CHUNK_SAMPLES];
} __attribute__ ((packed)) sl_polaris_lora_samplebuf_read_chunk_t;

typedef struct {
	uint8_t type;
	uint8_t flags;
	uint32_t addr;
} __attribute__ ((packed)) sl_polaris_lora_samplebuf_free_req_t;

typedef struct {
	uint8_t type;
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_samplebuf_free_rep_t;

/* Flags */
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_FLOWCTRL	(1 << 0) /**< Wait for 1-byte ACK for each frame */
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_OTHERHOST	(1 << 1) /**< Reply to rephost:repport */
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_SEQ		(1 << 2) /**< Add reply frame sequence number */
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_ID		(1 << 3) /**< Add trigger ID to reply frames */
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_FASTXMIT	(1 << 4) /**< Allow 2 frames in flight */
#define SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_RAWSPEC	(1 << 5) /**< Sample raw spectrum (count MUST be 8192) */

typedef struct {
	/** Must be SL_POLARIS_LORA_SAMPLEBUF_TRIG_REQ */
	uint8_t type;
	/** Flags */
	uint8_t flags;
	/** Reply to host if SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_OTHERHOST */
	uint8_t host;
	/** Reply to port if SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_OTHERHOST */
	uint8_t port;
	/** Reply packet size */
	uint16_t repsiz;
	/** Trigger ID to add if SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_ID */
	uint32_t id;
	/** Channel frequency in Hz. Set to 0 to keep current */
	uint32_t freq;
	/** Number of samples */
	uint32_t count;
} __attribute__ ((packed)) sl_polaris_lora_samplebuf_trig_req_t;

typedef struct {
	/** Must be SL_POLARIS_LORA_SAMPLEBUF_TRIG_REP */
	uint8_t type;
	/** Error code */
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_samplebuf_trig_rep_t;

/*
 * SL_POLARIS_LORA_PORT_STORE
 */

/* Types */
#define SL_POLARIS_LORA_STORE_FRAME			1
#define SL_POLARIS_LORA_STORE_MIRROR_REQ		2
#define SL_POLARIS_LORA_STORE_MIRROR_REP		3
#define SL_POLARIS_LORA_STORE_READ_REQ			4
#define SL_POLARIS_LORA_STORE_READ_REP			5

#define SL_POLARIS_LORA_STORE_MAX_DATALEN		255
typedef struct {
	/** Must be SL_POLARIS_LORA_STORE_FRAME */
	uint8_t type;
	/** Error code */
	uint8_t error;
	/** Sequence number of this frame */
	uint32_t seq;
	/** Frequency offset in Hz */
	int32_t frequency_offset;
	/** Symbol power dB */
	int16_t symbol_power;
	/** Signal  power dB */
	int16_t noise_power;
	/** spreading factor, SF */
	uint8_t spreading_factor;
	/** code rate */
	uint8_t code_rate;
	/** Payload crc enabled */
	uint8_t payload_crc_enabled;
	/** Time of reception (nanoseconds since 1/1/1970) */
	uint64_t time;
	/** Number of bytes in data field */
	uint8_t length;
	/** LoRA payload data */
	uint8_t data[SL_POLARIS_LORA_STORE_MAX_DATALEN];
} __attribute__ ((packed)) sl_polaris_lora_store_frame_t;
#define SL_POLARIS_LORA_STORE_FRAME_OVERHEAD		(sizeof(sl_polaris_lora_store_frame_t) - SL_POLARIS_LORA_STORE_MAX_DATALEN)

typedef struct {
	uint8_t type;
	uint8_t dest_node;
	uint8_t dest_port;
	uint32_t timeout_ms;
} __attribute__ ((packed)) sl_polaris_lora_store_mirror_req_t;

typedef struct {
	uint8_t type;
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_store_mirror_rep_t;

/* Bitmap size */
#define SL_POLARIS_LORA_STORE_BITMAP_SIZE		32 /* bytes */

typedef struct {
	uint8_t type;
	uint32_t start;
	uint8_t bitmap[SL_POLARIS_LORA_STORE_BITMAP_SIZE];
} __attribute__ ((packed)) sl_polaris_lora_store_read_req_t;

typedef struct {
	uint8_t type;
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_store_read_rep_t;

/*
 * SL_POLARIS_LORA_PORT_BOOTLOADER
 */

/* Types */
#define SL_POLARIS_LORA_BOOTLOADER_SET_REQ		1
#define SL_POLARIS_LORA_BOOTLOADER_SET_REP		2
#define SL_POLARIS_LORA_BOOTLOADER_FLASH_REQ		5
#define SL_POLARIS_LORA_BOOTLOADER_FLASH_REP		6
#define SL_POLARIS_LORA_BOOTLOADER_ERASE_REQ		7
#define SL_POLARIS_LORA_BOOTLOADER_ERASE_REP		8
#define SL_POLARIS_LORA_BOOTLOADER_CHECKSUM_REQ		9
#define SL_POLARIS_LORA_BOOTLOADER_CHECKSUM_REP		10
#define SL_POLARIS_LORA_BOOTLOADER_VERIFY_REQ		11
#define SL_POLARIS_LORA_BOOTLOADER_VERIFY_REP		12

/* Keys */
#define SL_POLARIS_LORA_BOOTLOADER_SET_KEY		0x9cb54ab5
#define SL_POLARIS_LORA_BOOTLOADER_FLASH_KEY		0xebdb4821
#define SL_POLARIS_LORA_BOOTLOADER_ERASE_KEY		0xde7eea07

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_SET_REQ */
	uint8_t type;
	/* Flags, currently unused - set to zero */
	uint8_t flags;
	/* Number of boots to boot alternate image, 0 = boot factory */
	uint8_t boots;
	/* Must be SL_POLARIS_LORA_BOOTLOADER_SET_KEY */
	uint32_t key;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_set_req_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_SET_REP */
	uint8_t type;
	/* Error code */
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_set_rep_t;

#define SL_POLARIS_LORA_BOOTLOADER_FILENAME_MAX	40
typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_FLASH_REQ */
	uint8_t type;
	/* Flags, currently unused - set to zero */
	uint8_t flags;
	/* Must be SL_POLARIS_LORA_BOOTLOADER_FLASH_KEY */
	uint32_t key;
	/* Filename to flash to the alternate partition */
	uint8_t filename[SL_POLARIS_LORA_BOOTLOADER_FILENAME_MAX];
} __attribute__ ((packed)) sl_polaris_lora_bootloader_flash_req_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_FLASH_REP */
	uint8_t type;
	/* Error code */
	uint8_t error;
	/* CRC32C of flash image */
	uint32_t checksum;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_flash_rep_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_ERASE_REQ */
	uint8_t type;
	/* Flags, currently unused - set to zero */
	uint8_t flags;
	/* Must be SL_POLARIS_LORA_BOOTLOADER_ERASE_KEY */
	uint32_t key;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_erase_req_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_ERASE_REP */
	uint8_t type;
	/* Error code */
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_erase_rep_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_CHECKSUM_REQ */
	uint8_t type;
	/* Flags, currently unused - set to zero */
	uint8_t flags;
	/* Number of bytes to checksum from beginning of alternate partition */
	uint32_t size;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_checksum_req_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_CHECKSUM_REP */
	uint8_t type;
	/* Error code */
	uint8_t error;
	/* CRC32C of flash image */
	uint32_t checksum;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_checksum_rep_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_VERIFY_REQ */
	uint8_t type;
	/* Flags, currently unused - set to zero */
	uint8_t flags;
	/* Partition to verify (0 = primary, 1 = alternate) */
	uint8_t partition;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_verify_req_t;

typedef struct {
	/* Must be SL_POLARIS_LORA_BOOTLOADER_VERIFY_REP */
	uint8_t type;
	/* Error code */
	uint8_t error;
	/* Read size of image */
	uint32_t size;
	/* Calculated checksum of image */
	uint32_t checksum;
} __attribute__ ((packed)) sl_polaris_lora_bootloader_verify_rep_t;

/*
 * SL_POLARIS_LORA_PORT_SHELL
 */

/* Types */
#define SL_POLARIS_LORA_SHELL_RUN_REQ		1
#define SL_POLARIS_LORA_SHELL_RUN_REP		2

/* Keys */
#define SL_POLARIS_LORA_SHELL_RUN_KEY		0x786f0fd7

#define SL_POLARIS_LORA_SHELL_RUN_MAX		100
typedef struct {
	/** Must be SL_POLARIS_LORA_SHELL_RUN_REQ */
	uint8_t type;
	/** Flags, currently unused - set to zero */
	uint8_t flags;
	/** Must be SL_POLARIS_LORA_SHELL_RUN_KEY */
	uint32_t key;
	/** Command to execute */
	uint8_t cmd[SL_POLARIS_LORA_SHELL_RUN_MAX];
} __attribute__ ((packed)) sl_polaris_lora_shell_run_req_t;

typedef struct {
	/** Must be SL_POLARIS_LORA_SHELL_RUN_REP */
	uint8_t type;
	/** Error code */
	uint8_t error;
} __attribute__ ((packed)) sl_polaris_lora_shell_run_rep_t;

/* Convert error code to string */
static inline const char *sl_polaris_lora_strerror(uint8_t error)
{
	switch (error) {
	case SL_POLARIS_LORA_ERR_NONE:
		return "Success";
	case SL_POLARIS_LORA_ERR_INVAL:
		return "Invalid argument";
	case SL_POLARIS_LORA_ERR_IO:
		return "I/O error";
	case SL_POLARIS_LORA_ERR_NOMEM:
		return "Not enough memory";
	case SL_POLARIS_LORA_ERR_BUSY:
		return "Device is busy";
	default:
		return "Unknown error"; 
	}
}

#endif /* _SL_POLARIS_LORA_CLIENT_PROTO_H_ */

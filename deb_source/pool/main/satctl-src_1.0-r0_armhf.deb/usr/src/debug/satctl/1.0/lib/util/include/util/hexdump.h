/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#ifndef _SL_HEXDUMP_H_
#define _SL_HEXDUMP_H_

#include <stddef.h>
#include <stdint.h>

typedef void (*hexdump_printfunc_t)(const char *str, void *arg);

int hexdump_printfunc(const void *data, size_t size, hexdump_printfunc_t func, void *arg);

int hexdump(const void *data, size_t len);

#endif /* _SL_HEXDUMP_H_ */

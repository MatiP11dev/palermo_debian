/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#include <util/util.h>

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

size_t array_weight(const uint8_t *array, size_t length)
{
	size_t i, weight = 0;

	for (i = 0; i < length; i++)
		weight += __builtin_popcount(array[i]);

	return weight;
}

bool array_bit_is_set(const uint8_t *array, size_t n)
{
	/* Return the n'th bit in array */
	return (array[n/8] >> (7 - n % 8)) & 0x01;
}

/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#include <util/list.h>
#include <stdlib.h>

void sl_list_init(struct sl_list *list)
{
	list->prev = list;
	list->next = list;
}

void sl_list_insert(struct sl_list *list, struct sl_list *elm)
{
	elm->prev = list;
	elm->next = list->next;
	list->next = elm;
	elm->next->prev = elm;
}

void sl_list_insert_tail(struct sl_list *list, struct sl_list *elm)
{
	elm->next = list;
	elm->prev = list->prev;
	list->prev = elm;
	elm->prev->next = elm;
}

void sl_list_remove(struct sl_list *elm)
{
	elm->prev->next = elm->next;
	elm->next->prev = elm->prev;
	elm->next = NULL;
	elm->prev = NULL;
}

int sl_list_length(struct sl_list *list)
{
	struct sl_list *l;
	int count;

	count = 0;
	l = list->next;
	while (l != list) {
		l = l->next;
		count++;
	}

	return count;
}

int sl_list_empty(struct sl_list *list)
{
	return list->next == list;
}

int sl_list_head(struct sl_list *list, struct sl_list *cur)
{
	return list == cur;
}

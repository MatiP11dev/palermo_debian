/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>

#include <slash/slash.h>

#include <util/timer.h>

int cmd_time(struct slash *slash)
{
	int i, ret;
	uint64_t start, stop;
	char command[100] = "";

	if (slash->argc < 2)
		return SLASH_EUSAGE;

	for (i = 1; i < slash->argc; i++) {
		strncat(command, slash->argv[i], sizeof(command) - 1);
		if (i != slash->argc - 1)
			strncat(command, " ", sizeof(command) - 1);
		command[sizeof(command) - 1] = '\0';
	}

	start = timer_getmonotonic();
	ret = slash_execute(slash, command);
	stop = timer_getmonotonic();

	printf("Command completed in %.3fs\n", (stop - start) / (float)NSEC_PER_SEC);

	return ret;
}
slash_command(time, cmd_time, "<command>", "Time command execution");

int cmd_uptime(struct slash *slash)
{
	unsigned int hour, min, sec;
	uint64_t now;

	now = timer_getmonotonic();
	sec = NSEC_TO_SEC(now);

	hour = sec / 3600;
	sec -= hour * 3600;
	min  = sec / 60;
	sec -= min * 60;
	printf(" %02u:%02u:%02u up\n", hour, min, sec);

	return 0;
}
slash_command(uptime, cmd_uptime, NULL, "Show system uptime");

/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#include <satlab/polaris_lora_sample.h>

#include <errno.h>

#include <csp/csp.h>
#include <csp/csp_endian.h>

#include <satlab/polaris_lora.h>

int sl_polaris_lora_sample_read(uint8_t node, uint32_t timeout, uint8_t source, uint32_t *out, size_t outlen)
{
	int expected, i;

	sl_polaris_lora_samplebuf_read_req_t *request;
	sl_polaris_lora_samplebuf_read_rep_t *reply;
	sl_polaris_lora_samplebuf_read_chunk_t *chunk;
	csp_packet_t *packet;
	csp_conn_t *conn;

	packet = csp_buffer_get(sizeof(*request));
	if (!packet)
		return -ENOMEM;

	request = (void *)packet->data;
	request->type = SL_POLARIS_LORA_SAMPLEBUF_READ_REQ;
	request->source = source;
	request->dest = SL_POLARIS_LORA_SAMPLEBUF_DEST_CSP;
	request->flags = 0;
	request->id = csp_hton32(0);
	request->samples = csp_hton32(outlen / sizeof(uint32_t));
	packet->length = sizeof(*request);

	conn = csp_connect(CSP_PRIO_NORM, node, SL_POLARIS_LORA_PORT_SAMPLEBUF, timeout, CSP_O_NONE);
	if (!conn) {
		csp_buffer_free(packet);
		return -ECONNREFUSED;
	}

	if (!csp_send(conn, packet, timeout)) {
		csp_buffer_free(packet);
		csp_close(conn);
		return -EIO;
	}

	/* Wait for reply packet */
	packet = csp_read(conn, timeout);
	if (!packet) {
		csp_close(conn);
		return -ETIMEDOUT;
	}

	reply = (void *)packet->data;
	if (reply->type != SL_POLARIS_LORA_SAMPLEBUF_READ_REP) {
		csp_buffer_free(packet);
		csp_close(conn);
		return -EINVAL;
	}

	if (reply->error != SL_POLARIS_LORA_ERR_NONE) {
		csp_buffer_free(packet);
		csp_close(conn);
		return -reply->error;
	}

	csp_buffer_free(packet);
	reply = NULL;

	/* Expected number of frames */
	expected = outlen / sizeof(uint32_t) / SL_POLARIS_LORA_SAMPLEBUF_READ_CHUNK_SAMPLES;

	for (i = 0; i < expected; i++) {
		packet = csp_read(conn, timeout);
		if (!packet) {
			csp_close(conn);
			return -ETIMEDOUT;
		}

		chunk = (void *)packet->data;
		if (chunk->type != SL_POLARIS_LORA_SAMPLEBUF_READ_CHUNK) {
			csp_buffer_free(packet);
			csp_close(conn);
			return -EINVAL;
		}

		chunk->seq = csp_ntoh16(chunk->seq);
		chunk->total = csp_ntoh16(chunk->total);
		if (chunk->total != expected || chunk->seq != i) {
			csp_buffer_free(packet);
			csp_close(conn);
			return -EINVAL; 
		}

		memcpy(out, chunk->data, sizeof(chunk->data));
		out += sizeof(chunk->data) / sizeof(uint32_t);
		
		csp_buffer_free(packet);
	}

	csp_close(conn);

	return 0;
}

int sl_polaris_lora_sample_store(uint8_t node, uint32_t timeout, uint8_t source, uint8_t dest, size_t samples, uint32_t id)
{
	int ret;
	sl_polaris_lora_samplebuf_read_req_t request;
	sl_polaris_lora_samplebuf_read_rep_t reply;

	request.type = SL_POLARIS_LORA_SAMPLEBUF_READ_REQ;
	request.source = source;
	request.dest = dest;
	request.flags = 0;
	request.id = csp_hton32(id);
	request.samples = csp_hton32(samples);

	ret = csp_transaction(CSP_PRIO_NORM, node, SL_POLARIS_LORA_PORT_SAMPLEBUF, timeout,
			      &request, sizeof(request), &reply, sizeof(reply));
	if (ret != sizeof(reply))
		return -ECONNREFUSED;

	if (reply.type != SL_POLARIS_LORA_SAMPLEBUF_READ_REP)
		return -EINVAL;

	if (reply.error != SL_POLARIS_LORA_ERR_NONE)
		return -reply.error;

	return 0;
}

int sl_polaris_lora_sample_trigger_host(uint8_t node, uint32_t timeout, uint8_t flags, uint16_t repsiz, uint32_t samples, uint32_t freq, uint32_t id, uint8_t host, uint8_t port)
{
	int ret;
	sl_polaris_lora_samplebuf_trig_req_t request;
	sl_polaris_lora_samplebuf_trig_rep_t reply;

	request.type = SL_POLARIS_LORA_SAMPLEBUF_TRIG_REQ;
	request.flags = flags | SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_OTHERHOST | SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_FLOWCTRL;
	request.host = host;
	request.port = port;
	request.repsiz = csp_hton16(repsiz);
	request.id = csp_hton32(id);
	request.freq = csp_hton32(freq);
	request.count = csp_hton32(samples);

	ret = csp_transaction(CSP_PRIO_NORM, node, SL_POLARIS_LORA_PORT_SAMPLEBUF, timeout,
			      &request, sizeof(request), &reply, sizeof(reply));
	if (ret != sizeof(reply))
		return -ECONNREFUSED;

	if (reply.type != SL_POLARIS_LORA_SAMPLEBUF_TRIG_REP)
		return -EINVAL;

	if (reply.error != SL_POLARIS_LORA_ERR_NONE)
		return -reply.error;

	return 0;
}

int sl_polaris_lora_sample_trigger_buffer(uint8_t node, uint32_t timeout, uint8_t flags, uint16_t repsiz, uint32_t samples, uint32_t freq, uint32_t id, uint32_t *out, size_t outlen)
{
	int expected, i;
	csp_conn_t *conn;
	csp_packet_t *packet;
	sl_polaris_lora_samplebuf_trig_req_t *request;
	sl_polaris_lora_samplebuf_trig_rep_t *reply;

	/* Verify that output buffer can contain the samples */
	if (outlen < samples * sizeof(*out))
		return -ENOBUFS;

	/* ID and sequence number can not be used */
	if (flags & (SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_SEQ | SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_ID))
		return -EINVAL;

	packet = csp_buffer_get(sizeof(*request));
	if (!packet)
		return -ENOMEM;

	request = (sl_polaris_lora_samplebuf_trig_req_t *)packet->data;
	request->type = SL_POLARIS_LORA_SAMPLEBUF_TRIG_REQ;
	request->flags = flags | SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_FLOWCTRL;
	request->host = 0;
	request->port = 0;
	request->repsiz = csp_hton16(repsiz);
	request->id = csp_hton32(id);
	request->freq = csp_hton32(freq);
	request->count = csp_hton32(samples);
	packet->length = sizeof(*request);

	conn = csp_connect(CSP_PRIO_NORM, node, SL_POLARIS_LORA_PORT_SAMPLEBUF, timeout, CSP_O_NONE);
	if (!conn) {
		csp_buffer_free(packet);
		return -ECONNREFUSED;
	}

	if (!csp_send(conn, packet, timeout)) {
		csp_buffer_free(packet);
		csp_close(conn);
		return -EIO;
	}

	/* Wait for reply packet */
	packet = csp_read(conn, timeout);
	if (!packet) {
		csp_close(conn);
		return -ETIMEDOUT;
	}

	reply = (sl_polaris_lora_samplebuf_trig_rep_t *)packet->data;
	if (reply->type != SL_POLARIS_LORA_SAMPLEBUF_TRIG_REP) {
		csp_buffer_free(packet);
		csp_close(conn);
		return -EINVAL;
	}

	if (reply->error != SL_POLARIS_LORA_ERR_NONE) {
		csp_buffer_free(packet);
		csp_close(conn);
		return -reply->error;
	}

	csp_buffer_free(packet);
	reply = NULL;

	/* Expected number of frames */
	expected = (samples * sizeof(*out) + repsiz - 1) / repsiz;

	for (i = 0; i < expected; i++) {
		packet = csp_read(conn, timeout);
		if (!packet) {
			csp_close(conn);
			return -ETIMEDOUT;
		}

		memcpy(out, packet->data, packet->length);
		out += packet->length / sizeof(*out);

		/* Send ACK */
		packet->data[0] = 0;
		packet->length = 1;

		csp_send_free(conn, packet, timeout);
	}

	csp_close(conn);

	return 0;
}

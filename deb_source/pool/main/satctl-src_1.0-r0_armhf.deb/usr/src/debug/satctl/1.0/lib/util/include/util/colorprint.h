/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#ifndef _SL_COLORPRINT_H_
#define _SL_COLORPRINT_H_

#define COLOR_MASK_COLOR	0x1F
#define COLOR_MASK_MODIFIER	0xE0

typedef enum {
	COLOR_RESET		= 0x00,
	/* Colors */
	COLOR_BLACK		= 0x01,
	COLOR_RED		= 0x02,
	COLOR_GREEN		= 0x03,
	COLOR_YELLOW		= 0x04,
	COLOR_BLUE		= 0x05,
	COLOR_MAGENTA		= 0x06,
	COLOR_CYAN		= 0x07,
	COLOR_LIGHT_GRAY	= 0x08,
	COLOR_DARK_GRAY		= 0x09,
	COLOR_LIGHT_RED		= 0x0a,
	COLOR_LIGHT_GREEN	= 0x0b,
	COLOR_LIGHT_YELLOW	= 0x0c,
	COLOR_LIGHT_BLUE	= 0x0d,
	COLOR_LIGHT_MAGENTA	= 0x0e,
	COLOR_LIGHT_CYAN	= 0x0f,
	COLOR_WHITE		= 0x10,
	/* Modifiers */
	COLOR_BOLD		= 0x20,
	COLOR_BRIGHT		= 0x40,
	COLOR_DIM		= 0x60,
	COLOR_UNDERLINE		= 0x80,
	COLOR_BLINK		= 0xa0,
	COLOR_REVERSE		= 0xc0,
	COLOR_HIDDEN		= 0xe0,
} sl_color_t;

int __attribute__ ((format (printf, 2, 3)))
cprintf(sl_color_t color, const char *format, ...);

int color_set(char *buf, sl_color_t color);

#endif /* _SL_COLORPRINT_H_ */

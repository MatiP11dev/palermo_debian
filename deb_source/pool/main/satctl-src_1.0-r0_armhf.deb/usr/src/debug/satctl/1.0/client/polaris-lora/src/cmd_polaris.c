/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <inttypes.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <util/csp_client_commands.h>
#include <csp/csp_endian.h>

#include <slash/slash.h>

#include <satlab/polaris_lora.h>
#include <prop-client/prop_client_commands.h>

#include <btp/types.h>
#include <btp/cmd_btp.h>

/* Default node and timeout */
static uint8_t polaris_lora_node = SL_POLARIS_LORA_DEFAULT_ADDRESS;
static uint32_t polaris_lora_timeout = 1000;

static void print_hex(const uint8_t *data, size_t length)
{
	size_t i;

	for (i = 0; i < length; i++)
		printf("%02hhx", data[i]);
	printf("\n");
}

static int frameprint_cb(sl_polaris_lora_store_frame_t *frame, void *arg)
{
	int ret = 0;
	struct slash *slash = arg;

	if (frame) {
		printf("Frame %u time: %.9f\n",
			(unsigned)frame->seq,
			frame->time / 1e9);
		print_hex(frame->data, frame->length);
	}

	/* Check for ^C */
	if (slash_wait_interruptible(slash, 0) == '\x03') {
		printf("\nInterrupted by user\n");
		ret = -EINTR;
	}

	return ret;
}

/* Main commands */
slash_command_group(lora, "Polaris LoRa subsystem commands");

static int cmd_lora_node(struct slash *slash)
{
	uint8_t node;
	char *endptr;

	if (slash->argc < 2) {
		printf("Current node address: %hhu\n", polaris_lora_node);
		return 0;
	}

	node = (uint8_t)strtoul(slash->argv[1], &endptr, 10);
	if (*endptr != '\0')
		return SLASH_EUSAGE;

	polaris_lora_node = node;

	return 0;
}
slash_command_sub(lora, node, cmd_lora_node, "[address]",
		  "Set/read node address");

static int cmd_lora_timeout(struct slash *slash)
{
	uint32_t timeout;
	char *endptr;

	if (slash->argc < 2) {
		printf("Current timeout: %"PRIu32" ms\n", polaris_lora_timeout);
		return 0;
	}

	timeout = (uint32_t)strtoul(slash->argv[1], &endptr, 10);
	if (*endptr != '\0')
		return SLASH_EUSAGE;

	polaris_lora_timeout = timeout;

	return 0;
}
slash_command_sub(lora, timeout, cmd_lora_timeout, "[ms]",
		  "Set/read communication timeout");


/* CSP commands */
SL_CSP_CLIENT_COMMANDS_GENERATE(lora, &polaris_lora_node, &polaris_lora_timeout);

/* Properties commands */
SL_PROP_CLIENT_COMMANDS_GENERATE(lora, &polaris_lora_node, SL_PROP_DEFAULT_PORT, &polaris_lora_timeout, &polaris_lora_props);

/* BTP commands */
SL_BTP_CLIENT_COMMANDS_GENERATE(lora, &polaris_lora_node, BTP_DEFAULT_PORT);

/* Bootloader commands */
slash_command_subgroup(lora, boot, "Bootloader commands");

static int cmd_lora_boot_flash(struct slash *slash)
{
	int ret;
	const char *filename;
	uint32_t crc;

	if (slash->argc < 2)
		return SLASH_EUSAGE;

	filename = slash->argv[1];

	printf("Flashing \"%s\" to alternate boot partition\n", filename);

	ret = sl_polaris_lora_bootloader_flash_alternate(polaris_lora_node, polaris_lora_timeout, filename, &crc);
	if (ret < 0) {
		printf("Failed to flash image: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	printf("Flashed image, checksum = %08"PRIx32"\n", crc);

	return 0;
}
slash_command_subsub(lora, boot, flash, cmd_lora_boot_flash, "<filename>",
		     "Flash image from polaris SD-card to alternate partition");

static int cmd_lora_boot_erase(struct slash *slash)
{
	int ret;

	ret = sl_polaris_lora_bootloader_erase_alternate(polaris_lora_node, polaris_lora_timeout);
	if (ret < 0) {
		printf("Failed to erase image: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	printf("Success - alternate image was erased\n");

	return 0;
}
slash_command_subsub(lora, boot, erase, cmd_lora_boot_erase,
		     NULL, "Erase alternate partition");

static int cmd_lora_boot_checksum(struct slash *slash)
{
	int ret;
	uint32_t size, crc;
	char *endptr;

	if (slash->argc < 2)
		return SLASH_EUSAGE;

	size = (uint32_t)strtoul(slash->argv[1], &endptr, 10);
	if (*endptr != '\0')
		return SLASH_EUSAGE;

	ret = sl_polaris_lora_bootloader_checksum_alternate(polaris_lora_node, polaris_lora_timeout, size, &crc);
	if (ret < 0) {
		printf("Failed to checksum image: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	printf("Image checksum = %08"PRIx32"\n", crc);

	return 0;
}
slash_command_subsub(lora, boot, checksum, cmd_lora_boot_checksum,
		     "<size>", "Calculate checksum of alternate partition");

static int cmd_lora_boot_verify(struct slash *slash)
{
	int ret;
	uint8_t partition = 1;
	uint32_t size, checksum;

	if (slash->argc > 1) {
		if (!strcmp(slash->argv[1], "primary")) {
			partition = 0;
		} else if (!strcmp(slash->argv[1], "alternate")) {
			partition = 1;
		} else {
			return SLASH_EUSAGE;
		}
	}

	ret = sl_polaris_lora_bootloader_verify(polaris_lora_node, polaris_lora_timeout, partition, &size, &checksum);
	if (ret < 0) {
		printf("Failed to verify image: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	printf("%s image is %s! (size %u, checksum %08X)\n",
	       partition == 0 ? "Primary" : "Alternate",
	       ret == 0 ? "OK" : "corrupt",
	       size, checksum);

	return ret == 0 ? 0 : SLASH_EIO;
}
slash_command_subsub(lora, boot, verify, cmd_lora_boot_verify,
		     "[partition]", "Verify image in partition");

static int cmd_lora_boot_set(struct slash *slash)
{
	int ret;
	uint8_t boots = 1;
	unsigned long boots_parsed;
	char *endptr;

	if (slash->argc > 1) {
		boots_parsed = strtoul(slash->argv[1], &endptr, 10);
		if (*endptr != '\0')
			return SLASH_EUSAGE;

		if (boots_parsed > 255) {
			fprintf(stderr, "Maximum number of boots is 255\n");
			return SLASH_EUSAGE;
		}

		boots = boots_parsed;
	}

	printf("Setting alternate firmware boot for %hhu boots\n", boots);

	ret = sl_polaris_lora_bootloader_set_alternate(polaris_lora_node, polaris_lora_timeout, boots);
	if (ret < 0) {
		fprintf(stderr, "Failed to set boot image: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	printf("Success - Reboot to boot alternate image\n");

	return 0;
}
slash_command_subsub(lora, boot, set, cmd_lora_boot_set,
		     "[boots]", "Set number of boots on alternate partition");


/* Sample commands */
slash_command_subgroup(lora, sample, "Sample buffer commands");

static int cmd_lora_sample_read(struct slash *slash)
{
	int c, ret, fd, nbytes;
	size_t samples = 8192;
	uint8_t source = SL_POLARIS_LORA_SAMPLEBUF_SOURCE_RAW;
	uint32_t *sample_mem;

	while ((c = slash_getopt(slash, "s:n:")) != -1) {
		switch (c) {
		case 's':
			if (!strcmp(slash->optarg, "raw")) {
				source = SL_POLARIS_LORA_SAMPLEBUF_SOURCE_RAW;
			} else if (!strcmp(slash->optarg, "chan")) {
				source = SL_POLARIS_LORA_SAMPLEBUF_SOURCE_CHAN;
			} else {
				source = atoi(slash->optarg);
			}
			break;
		case 'n':
			samples = atoi(slash->optarg);
			break;
		case '?':
		default:
			return SLASH_EUSAGE;
		}
	}

	if (slash->argc - slash->optind != 1)
		return SLASH_EUSAGE;

	fd = open(slash->argv[slash->optind], O_WRONLY | O_CREAT | O_TRUNC,
		  S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	if (fd < 0) {
		printf("Failed to open output file\n");
		return SLASH_EIO;
	}

	sample_mem = calloc(samples, sizeof(*sample_mem));
	if (!sample_mem) {
		printf("Failed to allocate memory\n");
		return SLASH_EIO;
	}

	ret = sl_polaris_lora_sample_read(polaris_lora_node, polaris_lora_timeout, source, sample_mem, samples * sizeof(*sample_mem));
	if (ret < 0) {
		free(sample_mem);
		printf("Failed to read sample: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	nbytes = write(fd, sample_mem, samples * sizeof(*sample_mem));
	if (nbytes != samples * sizeof(*sample_mem)) {
		free(sample_mem);
		printf("Failed to write sample to output file\n");
	}

	free(sample_mem);

	return 0;
}
slash_command_subsub(lora, sample, read, cmd_lora_sample_read,
		     "[-s <source>] [-n <samples>] <filename>",
		     "Read sample buffer and write to file");

static int cmd_lora_sample_store(struct slash *slash)
{
	int c, ret;
	size_t samples = 8192;
	uint8_t source = SL_POLARIS_LORA_SAMPLEBUF_SOURCE_RAW;
	uint8_t dest = SL_POLARIS_LORA_SAMPLEBUF_DEST_SDCARD;
	uint32_t id;
	char *endptr;

	while ((c = slash_getopt(slash, "s:d:n:")) != -1) {
		switch (c) {
		case 's':
			if (!strcmp(slash->optarg, "raw")) {
				source = SL_POLARIS_LORA_SAMPLEBUF_SOURCE_RAW;
			} else if (!strcmp(slash->optarg, "chan")) {
				source = SL_POLARIS_LORA_SAMPLEBUF_SOURCE_CHAN;
			} else {
				source = atoi(slash->optarg);
			}
			break;
		case 'd':
			if (!strcmp(slash->optarg, "sd")) {
				dest = SL_POLARIS_LORA_SAMPLEBUF_DEST_SDCARD;
			} else {
				dest = atoi(slash->optarg);
			}
			break;
		case 'n':
			samples = atoi(slash->optarg);
			break;
		case '?':
		default:
			return SLASH_EUSAGE;
		}
	}

	if (slash->argc - slash->optind != 1)
		return SLASH_EUSAGE;

	id = (uint32_t)strtoul(slash->argv[slash->optind], &endptr, 10);

	ret = sl_polaris_lora_sample_store(polaris_lora_node, polaris_lora_timeout, source, dest, samples, id);
	if (ret < 0) {
		printf("Failed to store sample: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	return 0;
}
slash_command_subsub(lora, sample, store, cmd_lora_sample_store,
		     "[-s <source>] [-d <dest>] [-n <samples>] <id>",
		     "Save sample buffer on host");

static int cmd_lora_sample_host(struct slash *slash)
{
	int c, ret;
	uint8_t host, port, flags = 0;
	uint16_t repsiz = 256;
	uint32_t samples = 8192;
	uint32_t freq = 0;
	uint32_t id = 0;
	uint32_t timeout = polaris_lora_timeout;
	uint32_t *sample_mem;
	char *endptr;

	while ((c = slash_getopt(slash, "f:i:n:qrst:z:")) != -1) {
		switch (c) {
		case 'f':
			freq = atoi(slash->optarg);
			break;
		case 'i':
			id = atoi(slash->optarg);
			flags |= SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_ID;
			break;
		case 'n':
			samples = atoi(slash->optarg);
			break;
		case 'q':
			flags |= SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_FASTXMIT;
			break;
		case 'r':
			flags |= SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_RAWSPEC;
			break;
		case 's':
			flags |= SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_SEQ;
			break;
		case 't':
			timeout = atoi(slash->optarg);
			break;
		case 'z':
			repsiz = atoi(slash->optarg);
			break;
		case '?':
		default:
			return SLASH_EUSAGE;
		}
	}

	if (slash->argc - slash->optind != 2)
		return SLASH_EUSAGE;

	host = (uint8_t)strtoul(slash->argv[slash->optind], &endptr, 10);
	if (*endptr != '\0')
		return SLASH_EUSAGE;

	port = (uint8_t)strtoul(slash->argv[slash->optind + 1], &endptr, 10);
	if (*endptr != '\0')
		return SLASH_EUSAGE;

	ret = sl_polaris_lora_sample_trigger_host(polaris_lora_node,
						  timeout,
						  flags,
						  repsiz,
						  samples,
						  freq,
						  id,
						  host,
						  port);
	if (ret < 0) {
		free(sample_mem);
		printf("Failed to trigger sample: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	return 0;
}
slash_command_subsub(lora, sample, host, cmd_lora_sample_host,
		     "[-f <freq>] [-i <id>] [-n <samples>] [-t <timeout>] [-z <repsiz>] [-qrs] <host> <port>",
		     "Trigger sample to other CSP host");

static int cmd_lora_sample_file(struct slash *slash)
{
	int c, ret, fd, nbytes;
	uint8_t flags = 0;
	uint16_t repsiz = 256;
	uint32_t samples = 8192;
	uint32_t freq = 0;
	uint32_t id = 0;
	uint32_t timeout = polaris_lora_timeout;
	uint32_t *sample_mem;

	while ((c = slash_getopt(slash, "f:i:n:qrst:z:")) != -1) {
		switch (c) {
		case 'f':
			freq = atoi(slash->optarg);
			break;
		case 'n':
			samples = atoi(slash->optarg);
			break;
		case 'q':
			flags |= SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_FASTXMIT;
			break;
		case 'r':
			flags |= SL_POLARIS_LORA_SAMPLEBUF_TRIG_FL_RAWSPEC;
			break;
		case 't':
			timeout = atoi(slash->optarg);
			break;
		case 'z':
			repsiz = atoi(slash->optarg);
			break;
		case '?':
		default:
			return SLASH_EUSAGE;
		}
	}

	if (slash->argc - slash->optind != 1)
		return SLASH_EUSAGE;

	fd = open(slash->argv[slash->optind], O_WRONLY | O_CREAT | O_TRUNC,
		  S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	if (fd < 0) {
		printf("Failed to open output file\n");
		return SLASH_EIO;
	}

	sample_mem = calloc(samples, sizeof(*sample_mem));
	if (!sample_mem) {
		printf("Failed to allocate memory\n");
		return SLASH_EIO;
	}

	ret = sl_polaris_lora_sample_trigger_buffer(polaris_lora_node,
					     timeout,
					     flags,
					     repsiz,
					     samples,
					     freq,
					     id,
					     sample_mem,
					     samples * sizeof(*sample_mem));
	if (ret < 0) {
		free(sample_mem);
		printf("Failed to trigger sample: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	nbytes = write(fd, sample_mem, samples * sizeof(*sample_mem));
	if (nbytes != samples * sizeof(*sample_mem)) {
		free(sample_mem);
		printf("Failed to write sample to output file\n");
	}

	free(sample_mem);

	return 0;
}
slash_command_subsub(lora, sample, file, cmd_lora_sample_file,
		     "[-f <freq>] [-n <samples>] [-t <timeout>] [-z <repsiz>] [-qr] <filename>",
		     "Trigger sample to file");


/* Store commands */
slash_command_subgroup(lora, store, "Store commands");

static int cmd_lora_store_mirror(struct slash *slash)
{
	int ret;

	ret = sl_polaris_lora_store_mirror_recv(polaris_lora_node, polaris_lora_timeout, frameprint_cb, slash);
	if (ret < 0) {
		printf("Failed to request frames: %s\n", strerror(-ret));
		return SLASH_EIO;
	}

	return 0;
}
slash_command_subsub(lora, store, mirror, cmd_lora_store_mirror,
		     NULL, "Request mirror of received frames");

static int cmd_lora_store_read(struct slash *slash)
{
	int c, ret, num = 1, bytes;
	uint8_t bitmap[SL_POLARIS_LORA_STORE_BITMAP_SIZE] = {0};
	uint32_t start = 0;
	char *endptr, *bitmapstr = NULL;
	size_t i, bitmapstrlen;

	while ((c = slash_getopt(slash, "b:n:s:")) != -1) {
		switch (c) {
		case 'b':
			bitmapstr = slash->optarg;
			break;
		case 's':
			start = (uint32_t)strtoul(slash->optarg, &endptr, 10);
			if (*endptr != '\0')
				return SLASH_EUSAGE;
			break;
		case 'n':
			num = (int)strtoul(slash->optarg, &endptr, 10);
			if (*endptr != '\0' || num < 1 || num > 8 * sizeof(bitmap))
				return SLASH_EUSAGE;
			break;
		case '?':
		default:
			return SLASH_EUSAGE;
		}
	}

	if (bitmapstr) {
		bitmapstrlen = strlen(bitmapstr);
		if (bitmapstrlen % 2 || bitmapstrlen / 2 > sizeof(bitmap))
			return SLASH_EUSAGE;

		bitmapstrlen = bitmapstrlen / 2;

		for (i = 0; i < bitmapstrlen; i++) {
			ret = sscanf(&bitmapstr[i * 2], "%2hhx", &bitmap[i]);
			if (ret != 1)
				return SLASH_EUSAGE;
		}
	}

	if (num > 0) {
		bytes = num / 8;
		memset(bitmap, 0xff, bytes);
		num -= bytes * 8;
		if (num > 0)
			bitmap[bytes] = ~((1 << (8 - num)) - 1);
	}

	ret = sl_polaris_lora_store_read(polaris_lora_node, polaris_lora_timeout, start, bitmap, frameprint_cb, NULL);
	if (ret < 0) {
		printf("Failed to read frames: %s\n", strerror(-ret));
		return SLASH_EIO;
	}

	return 0;
}
slash_command_subsub(lora, store, read, cmd_lora_store_read,
		     "[-s start] [-n num] [-b bitmap]",
		     "Request frames from store");

static int cmd_lora_run(struct slash *slash)
{
	int ret;
	const char *cmd;

	if (slash->argc != 2)
		return SLASH_EUSAGE;

	cmd = slash->argv[1];

	ret = sl_polaris_lora_shell_run(polaris_lora_node, polaris_lora_timeout, cmd);
	if (ret < 0) {
		printf("Failed to run command: %s\n", sl_polaris_lora_strerror(-ret));
		return SLASH_EIO;
	}

	return 0;
}
slash_command_sub(lora, run, cmd_lora_run, "<command>",
		  "Run command on remote system");

/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#ifndef _SL_CSP_CLIENT_COMMANDS_H_
#define _SL_CSP_CLIENT_COMMANDS_H_

#include <slash/slash.h>

#include <stdint.h>

int cmd_csp_reboot(struct slash *slash);

int cmd_csp_shutdown(struct slash *slash);

int cmd_csp_ping(struct slash *slash);

int cmd_csp_ident(struct slash *slash);

int cmd_csp_ifstats(struct slash *slash);

int cmd_csp_clock(struct slash *slash);

int cmd_csp_buffree(struct slash *slash);

int cmd_csp_memfree(struct slash *slash);

int cmd_csp_uptime(struct slash *slash);

struct sl_csp_client_command_context {
	uint8_t *node;
	uint32_t *timeout;
};

#define SL_CSP_CLIENT_COMMANDS_GENERATE_GENERIC(_cmdgroup, _ctx, _nodearg, _optnodearg) \
	slash_command_sub_ex(_cmdgroup, reboot, cmd_csp_reboot, _nodearg, "Reboot node via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, shutdown, cmd_csp_shutdown, _nodearg, "Shutdown node via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, ping, cmd_csp_ping, "[-c count] [-t timeout] [-s bytes] [-o options] [-i interval] [-p prio] [-qregf] " _nodearg, "Ping node via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, ident, cmd_csp_ident, "[-t timeout] " _optnodearg, "Show system information via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, ifstats, cmd_csp_ifstats, "[-t timeout] " _optnodearg " <ifname>", "Show CSP interface stats via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, clock, cmd_csp_clock, _optnodearg " [sec] [nsec]", "Set/get system time via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, buffree, cmd_csp_buffree, _optnodearg, "Show number of free CSP buffers via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, memfree, cmd_csp_memfree, _optnodearg, "Show amount of free memory via CSP", 0, _ctx); \
	slash_command_sub_ex(_cmdgroup, uptime, cmd_csp_uptime, _optnodearg, "Show uptime via CSP", 0, _ctx);

#define SL_CSP_CLIENT_COMMANDS_GENERATE(_cmdgroup, _node, _timeout) \
	static struct sl_csp_client_command_context sl_cmdcctx_ ## _cmdgroup = { \
		.node = _node, \
		.timeout = _timeout, \
	}; \
	SL_CSP_CLIENT_COMMANDS_GENERATE_GENERIC(_cmdgroup, &sl_cmdcctx_ ## _cmdgroup, "", "");

#endif /* _SL_CSP_CLIENT_COMMANDS_H_ */

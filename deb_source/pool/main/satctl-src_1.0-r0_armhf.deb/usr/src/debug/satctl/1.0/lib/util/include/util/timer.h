/*
 * Copyright (c) 2016-2021 Satlab A/S <satlab@satlab.com>
 * All rights reserved. Do not distribute without permission.
 */

#ifndef _SL_UTIL_TIMER_H_
#define _SL_UTIL_TIMER_H_

#include <stdint.h>
#include <time.h>

#define MSEC_PER_SEC	1000U
#define USEC_PER_SEC	1000000UL
#define NSEC_PER_SEC	1000000000ULL

#define MSEC_TO_SEC(_ms) (_ms/MSEC_PER_SEC)
#define USEC_TO_SEC(_ms) (_ms/USEC_PER_SEC)
#define NSEC_TO_SEC(_ms) (_ms/NSEC_PER_SEC)

void timer_delay_us(unsigned int us);

void timer_delay_ms(unsigned int ms);

uint64_t timer_getmonotonic(void);

void timer_init(void);

void timer_setrealtime(uint64_t now);

uint64_t timer_getrealtime(void);

static inline time_t timer_getunix(void)
{
	return timer_getrealtime() / NSEC_PER_SEC;
}

#endif /* _SL_UTIL_TIMER_H_ */

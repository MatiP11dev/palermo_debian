extern struct ofono_plugin_desc __ofono_builtin_udevng;
extern struct ofono_plugin_desc __ofono_builtin_rildev;
extern struct ofono_plugin_desc __ofono_builtin_phonesim;
extern struct ofono_plugin_desc __ofono_builtin_stemgr;
extern struct ofono_plugin_desc __ofono_builtin_connman;
extern struct ofono_plugin_desc __ofono_builtin_hfp_bluez5;
extern struct ofono_plugin_desc __ofono_builtin_dun_gw_bluez5;
extern struct ofono_plugin_desc __ofono_builtin_bluez5;
extern struct ofono_plugin_desc __ofono_builtin_hfp_ag_bluez5;
extern struct ofono_plugin_desc __ofono_builtin_upower;
extern struct ofono_plugin_desc __ofono_builtin_smart_messaging;
extern struct ofono_plugin_desc __ofono_builtin_push_notification;
extern struct ofono_plugin_desc __ofono_builtin_allowed_apns;

static struct ofono_plugin_desc *__ofono_builtin[] = {
  &__ofono_builtin_udevng,
  &__ofono_builtin_rildev,
  &__ofono_builtin_phonesim,
  &__ofono_builtin_stemgr,
  &__ofono_builtin_connman,
  &__ofono_builtin_hfp_bluez5,
  &__ofono_builtin_dun_gw_bluez5,
  &__ofono_builtin_bluez5,
  &__ofono_builtin_hfp_ag_bluez5,
  &__ofono_builtin_upower,
  &__ofono_builtin_smart_messaging,
  &__ofono_builtin_push_notification,
  &__ofono_builtin_allowed_apns,
  NULL
};

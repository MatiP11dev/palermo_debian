/*
 * oFono - Open Source Telephony
 * Copyright (C) 2008-2011  Intel Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>

#include <glib.h>
#include <gatchat.h>
#include <gattty.h>

#define OFONO_API_SUBJECT_TO_CHANGE
#include <ofono/plugin.h>
#include <ofono/modem.h>
#include <ofono/devinfo.h>
#include <ofono/netreg.h>
#include <ofono/phonebook.h>
#include <ofono/sim.h>
#include <ofono/cbs.h>
#include <ofono/sms.h>
#include <ofono/ussd.h>
#include <ofono/gprs.h>
#include <ofono/gprs-context.h>
#include <ofono/radio-settings.h>
#include <ofono/voicecall.h>
#include <ofono/log.h>

#include <drivers/atmodem/atutil.h>
#include <drivers/atmodem/vendor.h>

static const char *none_prefix[] = { NULL };
static const char *opmn_prefix[] = { "_OPMN:", NULL };
static const char *obls_prefix[] = { "_OBLS:", NULL };
static const char *opcm_prefix[] = { "_OPCMENABLE:", NULL };

struct hso_data {
	GAtChat *app;
	GAtChat *control;
	GAtChat *modem;
	guint sim_poll_source;
	guint sim_poll_count;
	ofono_bool_t have_sim;
	ofono_bool_t have_voice;
};

static int hso_probe(struct ofono_modem *modem)
{
	struct hso_data *data;

	DBG("%p", modem);

	data = g_try_new0(struct hso_data, 1);
	if (data == NULL)
		return -ENOMEM;

	ofono_modem_set_data(modem, data);

	return 0;
}

static void hso_remove(struct ofono_modem *modem)
{
	struct hso_data *data = ofono_modem_get_data(modem);

	DBG("%p", modem);

	ofono_modem_set_data(modem, NULL);

	g_at_chat_unref(data->control);

	if (data->sim_poll_source > 0)
		g_source_remove(data->sim_poll_source);

	g_free(data);
}

static void hso_debug(const char *str, void *user_data)
{
	const char *prefix = user_data;

	ofono_info("%s%s", prefix, str);
}

static void opcm_query(gboolean ok, GAtResult *result, gpointer user_data)
{
	struct ofono_modem *modem = user_data;
	struct hso_data *data = ofono_modem_get_data(modem);
	GAtResultIter iter;

	DBG("");

	if (!ok)
		return;

	g_at_result_iter_init(&iter, result);

	if (!g_at_result_iter_next(&iter, "_OPCMENABLE:"))
		return;

	g_at_chat_send(data->app, "AT_OPCMENABLE=1", none_prefix,
						NULL, NULL, NULL);
}

static void opcm_support(gboolean ok, GAtResult *result, gpointer user_data)
{
	struct ofono_modem *modem = user_data;
	struct hso_data *data = ofono_modem_get_data(modem);
	GAtResultIter iter;

	DBG("");

	if (!ok)
		return;

	g_at_result_iter_init(&iter, result);

	if (!g_at_result_iter_next(&iter, "_OPCMENABLE:"))
		return;

	data->have_voice = TRUE;

	g_at_chat_send(data->app, "AT_OPCMENABLE?", opcm_prefix,
					opcm_query, modem, NULL);
}

static gboolean init_sim_check(gpointer user_data);

static void sim_status(gboolean ok, GAtResult *result, gpointer user_data)
{
	struct ofono_modem *modem = user_data;
	struct hso_data *data = ofono_modem_get_data(modem);
	GAtResultIter iter;
	int sim, pb, sms;

	DBG("");

	if (data->sim_poll_source > 0) {
		g_source_remove(data->sim_poll_source);
		data->sim_poll_source = 0;
	}

	if (!ok) {
		ofono_modem_set_powered(modem, FALSE);
		return;
	}

	g_at_result_iter_init(&iter, result);

	if (!g_at_result_iter_next(&iter, "_OBLS:")) {
		ofono_modem_set_powered(modem, FALSE);
		return;
	}

	if (!g_at_result_iter_next_number(&iter, &sim)) {
		ofono_modem_set_powered(modem, FALSE);
		return;
	}

	if (!g_at_result_iter_next_number(&iter, &pb)) {
		ofono_modem_set_powered(modem, FALSE);
		return;
	}

	if (!g_at_result_iter_next_number(&iter, &sms)) {
		ofono_modem_set_powered(modem, FALSE);
		return;
	}

	DBG("status sim %d pb %d sms %d", sim, pb, sms);

	switch (sim) {
	case 0:		/* not ready */
		data->have_sim = FALSE;

		if (data->sim_poll_count++ < 5) {
			data->sim_poll_source = g_timeout_add_seconds(1,
							init_sim_check, modem);
			return;
		}
		break;
	case 1:		/* SIM card ready */
		data->have_sim = TRUE;
		break;
	case 2:		/* no SIM card */
		data->have_sim = FALSE;
		break;
	default:
		data->have_sim = FALSE;
		break;
	}

	data->sim_poll_count = 0;

	ofono_modem_set_powered(modem, data->have_sim);

	if (data->have_sim == FALSE)
		return;

	/*
	 * Ensure that the modem is using GSM character set and not IRA,
	 * otherwise weirdness with umlauts and other non-ASCII characters
	 * can result
	 */
	g_at_chat_send(data->control, "AT+CSCS=\"GSM\"", none_prefix,
							NULL, NULL, NULL);
	g_at_chat_send(data->app, "AT+CSCS=\"GSM\"", none_prefix,
							NULL, NULL, NULL);

	/*
	 * Option has the concept of Speech Service versus
	 * Data Service. Problem is that in Data Service mode
	 * the card will reject all voice calls. This is a
	 * problem for Multi-SIM cards where one of the SIM
	 * cards is used in a mobile phone and thus incoming
	 * calls would be not signalled on the phone.
	 *
	 *   0 = Speech Service enabled
	 *   1 = Data Service only mode
	 */
	g_at_chat_send(data->app, "AT_ODO?", none_prefix, NULL, NULL, NULL);
	g_at_chat_send(data->app, "AT_ODO=0", none_prefix, NULL, NULL, NULL);

	g_at_chat_send(data->app, "AT_OPCMENABLE=?", opcm_prefix,
					opcm_support, modem, NULL);
}

static gboolean init_sim_check(gpointer user_data)
{
	struct ofono_modem *modem = user_data;
	struct hso_data *data = ofono_modem_get_data(modem);

	data->sim_poll_source = 0;

	g_at_chat_send(data->control, "AT_OBLS", obls_prefix,
					sim_status, modem, NULL);

	return FALSE;
}

static void check_model(gboolean ok, GAtResult *result, gpointer user_data)
{
	struct ofono_modem *modem = user_data;
	GAtResultIter iter;
	char const *model;

	DBG("");

	if (!ok)
		goto done;

	g_at_result_iter_init(&iter, result);

	if (!g_at_result_iter_next(&iter, "_OPMN:"))
		goto done;

	if (g_at_result_iter_next_unquoted_string(&iter, &model))
		ofono_info("Model is %s", model);

done:
	init_sim_check(modem);
}

static void cfun_enable(gboolean ok, GAtResult *result, gpointer user_data)
{
	struct ofono_modem *modem = user_data;
	struct hso_data *data = ofono_modem_get_data(modem);

	DBG("");

	if (!ok) {
		ofono_modem_set_powered(modem, FALSE);
		return;
	}

	g_at_chat_send(data->control, "AT_OPMN", opmn_prefix,
					check_model, modem, NULL);
}

static GAtChat *open_device(struct ofono_modem *modem,
				const char *key, char *debug)
{
	return at_util_open_device(modem, key, hso_debug, debug, NULL);
}

static int hso_enable(struct ofono_modem *modem)
{
	struct hso_data *data = ofono_modem_get_data(modem);

	DBG("%p", modem);

	data->control = open_device(modem, "Control", "Control: ");
	if (data->control == NULL)
		return -EINVAL;

	data->app = open_device(modem, "Application", "App: ");
	if (data->app == NULL) {
		g_at_chat_unref(data->control);
		data->control = NULL;
		return -EIO;
	}

	data->modem = open_device(modem, "Modem", "Modem: ");

	g_at_chat_send(data->control, "ATE0 +CMEE=1", NULL, NULL, NULL, NULL);
	g_at_chat_send(data->app, "ATE0 +CMEE=1", NULL, NULL, NULL, NULL);

	g_at_chat_send(data->control, "AT+CFUN=4", none_prefix,
					cfun_enable, modem, NULL);

	return -EINPROGRESS;
}

static void cfun_disable(gboolean ok, GAtResult *result, gpointer user_data)
{
	struct ofono_modem *modem = user_data;
	struct hso_data *data = ofono_modem_get_data(modem);

	DBG("");

	g_at_chat_unref(data->control);
	data->control = NULL;

	if (ok)
		ofono_modem_set_powered(modem, FALSE);
}

static int hso_disable(struct ofono_modem *modem)
{
	struct hso_data *data = ofono_modem_get_data(modem);

	DBG("%p", modem);

	if (data->control == NULL)
		return 0;

	g_at_chat_cancel_all(data->control);
	g_at_chat_unregister_all(data->control);

	g_at_chat_unref(data->modem);
	data->modem = NULL;

	g_at_chat_unref(data->app);
	data->app = NULL;

	g_at_chat_send(data->control, "AT+CFUN=0", none_prefix,
					cfun_disable, modem, NULL);

	return -EINPROGRESS;
}

static void set_online_cb(gboolean ok, GAtResult *result, gpointer user_data)
{
	struct cb_data *cbd = user_data;
	ofono_modem_online_cb_t cb = cbd->cb;

	if (ok)
		CALLBACK_WITH_SUCCESS(cb, cbd->data);
	else
		CALLBACK_WITH_FAILURE(cb, cbd->data);
}

static void hso_set_online(struct ofono_modem *modem, ofono_bool_t online,
				ofono_modem_online_cb_t cb, void *user_data)
{
	struct hso_data *data = ofono_modem_get_data(modem);
	GAtChat *chat = data->control;
	struct cb_data *cbd = cb_data_new(cb, user_data);
	char const *command = online ? "AT+CFUN=1" : "AT+CFUN=4";

	DBG("modem %p %s", modem, online ? "online" : "offline");

	if (g_at_chat_send(chat, command, NULL, set_online_cb, cbd, g_free))
		return;

	CALLBACK_WITH_FAILURE(cb, cbd->data);

	g_free(cbd);
}

static void hso_pre_sim(struct ofono_modem *modem)
{
	struct hso_data *data = ofono_modem_get_data(modem);
	struct ofono_sim *sim;

	DBG("%p", modem);

	ofono_devinfo_create(modem, 0, "atmodem", data->control);
	sim = ofono_sim_create(modem, OFONO_VENDOR_OPTION_HSO,
					"atmodem", data->control);

	if (sim && data->have_sim == TRUE)
		ofono_sim_inserted_notify(sim, TRUE);
}

static void hso_post_sim(struct ofono_modem *modem)
{
	struct hso_data *data = ofono_modem_get_data(modem);

	DBG("%p", modem);

	if (data->have_voice == TRUE) {
		ofono_voicecall_create(modem, OFONO_VENDOR_QUALCOMM_MSM,
						"atmodem", data->app);
	}

	ofono_phonebook_create(modem, 0, "atmodem", data->app);
	ofono_radio_settings_create(modem, 0, "hsomodem", data->app);

	ofono_sms_create(modem, OFONO_VENDOR_OPTION_HSO, "atmodem", data->app);
}

static void hso_post_online(struct ofono_modem *modem)
{
	struct hso_data *data = ofono_modem_get_data(modem);
	struct ofono_gprs *gprs;
	struct ofono_gprs_context *gc;

	DBG("%p", modem);

	ofono_netreg_create(modem, OFONO_VENDOR_OPTION_HSO,
					"atmodem", data->app);

	ofono_cbs_create(modem, OFONO_VENDOR_QUALCOMM_MSM,
					"atmodem", data->app);
	ofono_ussd_create(modem, OFONO_VENDOR_QUALCOMM_MSM,
					"atmodem", data->app);

	gprs = ofono_gprs_create(modem, 0, "atmodem", data->app);
	gc = ofono_gprs_context_create(modem, 0, "hsomodem", data->control);

	if (gprs && gc)
		ofono_gprs_add_context(gprs, gc);
}

static struct ofono_modem_driver hso_driver = {
	.probe		= hso_probe,
	.remove		= hso_remove,
	.enable		= hso_enable,
	.disable	= hso_disable,
	.set_online	= hso_set_online,
	.pre_sim	= hso_pre_sim,
	.post_sim	= hso_post_sim,
	.post_online	= hso_post_online,
};

OFONO_MODEM_DRIVER_BUILTIN(hso, &hso_driver)

/* This is a generated file, see Makefile.am for its inputs. */
static const char x86_64_syscall_strings[] = "_sysctl\0accept\0accept4\0access\0acct\0add_key\0adjtimex\0afs_syscall\0alarm\0arch_prctl\0"
	"bind\0bpf\0brk\0cachestat\0capget\0capset\0chdir\0chmod\0chown\0chroot\0"
	"clock_adjtime\0clock_getres\0clock_gettime\0clock_nanosleep\0clock_settime\0clone\0clone3\0close\0close_range\0connect\0"
	"copy_file_range\0creat\0create_module\0delete_module\0dup\0dup2\0dup3\0epoll_create\0epoll_create1\0epoll_ctl\0"
	"epoll_ctl_old\0epoll_pwait\0epoll_pwait2\0epoll_wait\0epoll_wait_old\0eventfd\0eventfd2\0execve\0execveat\0exit\0"
	"exit_group\0faccessat\0faccessat2\0fadvise64\0fallocate\0fanotify_init\0fanotify_mark\0fchdir\0fchmod\0fchmodat\0"
	"fchmodat2\0fchown\0fchownat\0fcntl\0fdatasync\0fgetxattr\0finit_module\0flistxattr\0flock\0fork\0"
	"fremovexattr\0fsconfig\0fsetxattr\0fsmount\0fsopen\0fspick\0fstat\0fstatfs\0fsync\0ftruncate\0"
	"futex\0futex_requeue\0futex_wait\0futex_waitv\0futex_wake\0futimesat\0get_kernel_syms\0get_mempolicy\0get_robust_list\0get_thread_area\0"
	"getcpu\0getcwd\0getdents\0getdents64\0getegid\0geteuid\0getgid\0getgroups\0getitimer\0getpeername\0"
	"getpgid\0getpgrp\0getpid\0getpmsg\0getppid\0getpriority\0getrandom\0getresgid\0getresuid\0getrlimit\0"
	"getrusage\0getsid\0getsockname\0getsockopt\0gettid\0gettimeofday\0getuid\0getxattr\0init_module\0inotify_add_watch\0"
	"inotify_init\0inotify_init1\0inotify_rm_watch\0io_cancel\0io_destroy\0io_getevents\0io_pgetevents\0io_setup\0io_submit\0io_uring_enter\0"
	"io_uring_register\0io_uring_setup\0ioctl\0ioperm\0iopl\0ioprio_get\0ioprio_set\0kcmp\0kexec_file_load\0kexec_load\0"
	"keyctl\0kill\0landlock_add_rule\0landlock_create_ruleset\0landlock_restrict_self\0lchown\0lgetxattr\0link\0linkat\0listen\0"
	"listmount\0listxattr\0llistxattr\0lookup_dcookie\0lremovexattr\0lseek\0lsetxattr\0lsm_get_self_attr\0lsm_list_modules\0lsm_set_self_attr\0"
	"lstat\0madvise\0map_shadow_stack\0mbind\0membarrier\0memfd_create\0memfd_secret\0migrate_pages\0mincore\0mkdir\0"
	"mkdirat\0mknod\0mknodat\0mlock\0mlock2\0mlockall\0mmap\0modify_ldt\0mount\0mount_setattr\0"
	"move_mount\0move_pages\0mprotect\0mq_getsetattr\0mq_notify\0mq_open\0mq_timedreceive\0mq_timedsend\0mq_unlink\0mremap\0"
	"mseal\0msgctl\0msgget\0msgrcv\0msgsnd\0msync\0munlock\0munlockall\0munmap\0name_to_handle_at\0"
	"nanosleep\0newfstatat\0nfsservctl\0open\0open_by_handle_at\0open_tree\0openat\0openat2\0pause\0perf_event_open\0"
	"personality\0pidfd_getfd\0pidfd_open\0pidfd_send_signal\0pipe\0pipe2\0pivot_root\0pkey_alloc\0pkey_free\0pkey_mprotect\0"
	"poll\0ppoll\0prctl\0pread\0preadv\0preadv2\0prlimit64\0process_madvise\0process_mrelease\0process_vm_readv\0"
	"process_vm_writev\0pselect6\0ptrace\0putpmsg\0pwrite\0pwritev\0pwritev2\0query_module\0quotactl\0quotactl_fd\0"
	"read\0readahead\0readlink\0readlinkat\0readv\0reboot\0recvfrom\0recvmmsg\0recvmsg\0remap_file_pages\0"
	"removexattr\0rename\0renameat\0renameat2\0request_key\0restart_syscall\0rmdir\0rseq\0rt_sigaction\0rt_sigpending\0"
	"rt_sigprocmask\0rt_sigqueueinfo\0rt_sigreturn\0rt_sigsuspend\0rt_sigtimedwait\0rt_tgsigqueueinfo\0sched_get_priority_max\0sched_get_priority_min\0sched_getaffinity\0sched_getattr\0"
	"sched_getparam\0sched_getscheduler\0sched_rr_get_interval\0sched_setaffinity\0sched_setattr\0sched_setparam\0sched_setscheduler\0sched_yield\0seccomp\0security\0"
	"select\0semctl\0semget\0semop\0semtimedop\0sendfile\0sendmmsg\0sendmsg\0sendto\0set_mempolicy\0"
	"set_mempolicy_home_node\0set_robust_list\0set_thread_area\0set_tid_address\0setdomainname\0setfsgid\0setfsuid\0setgid\0setgroups\0sethostname\0"
	"setitimer\0setns\0setpgid\0setpriority\0setregid\0setresgid\0setresuid\0setreuid\0setrlimit\0setsid\0"
	"setsockopt\0settimeofday\0setuid\0setxattr\0shmat\0shmctl\0shmdt\0shmget\0shutdown\0sigaltstack\0"
	"signalfd\0signalfd4\0socket\0socketpair\0splice\0stat\0statfs\0statmount\0statx\0swapoff\0"
	"swapon\0symlink\0symlinkat\0sync\0sync_file_range\0syncfs\0sysfs\0sysinfo\0syslog\0tee\0"
	"tgkill\0time\0timer_create\0timer_delete\0timer_getoverrun\0timer_gettime\0timer_settime\0timerfd_create\0timerfd_gettime\0timerfd_settime\0"
	"times\0tkill\0truncate\0tuxcall\0umask\0umount2\0uname\0unlink\0unlinkat\0unshare\0"
	"uselib\0userfaultfd\0ustat\0utime\0utimensat\0utimes\0vfork\0vhangup\0vmsplice\0vserver\0"
	"wait4\0waitid\0write\0writev";
static const unsigned x86_64_syscall_s2i_s[] = {
	0,8,15,23,30,35,43,52,64,70,
	81,86,90,94,104,111,118,124,130,136,
	143,157,170,184,200,214,220,227,233,245,
	253,269,275,289,303,307,312,317,330,344,
	354,368,380,393,404,419,427,436,443,452,
	457,468,478,489,499,509,523,537,544,551,
	560,570,577,586,592,602,612,625,636,642,
	647,660,669,679,687,694,701,707,715,721,
	731,737,751,762,774,785,795,811,825,841,
	857,864,871,880,891,899,907,914,924,934,
	946,954,962,969,977,985,997,1007,1017,1027,
	1037,1047,1054,1066,1077,1084,1097,1104,1113,1125,
	1143,1156,1170,1187,1197,1208,1221,1235,1244,1254,
	1269,1287,1302,1308,1315,1320,1331,1342,1347,1363,
	1374,1381,1386,1404,1428,1451,1458,1468,1473,1480,
	1487,1497,1507,1518,1533,1546,1552,1562,1580,1597,
	1615,1621,1629,1646,1652,1663,1676,1689,1703,1711,
	1717,1725,1731,1739,1745,1752,1761,1766,1777,1783,
	1797,1808,1819,1828,1842,1852,1860,1876,1889,1899,
	1906,1912,1919,1926,1933,1940,1946,1954,1965,1972,
	1990,2000,2011,2022,2027,2045,2055,2062,2070,2076,
	2092,2104,2116,2127,2145,2150,2156,2167,2178,2188,
	2202,2207,2213,2219,2225,2232,2240,2250,2266,2283,
	2300,2318,2327,2334,2342,2349,2357,2366,2379,2388,
	2400,2405,2415,2424,2435,2441,2448,2457,2466,2474,
	2491,2503,2510,2519,2529,2541,2557,2563,2568,2581,
	2595,2610,2626,2639,2653,2669,2687,2710,2733,2751,
	2765,2780,2799,2821,2839,2853,2868,2887,2899,2907,
	2916,2923,2930,2937,2943,2954,2963,2972,2980,2987,
	3001,3025,3041,3057,3073,3087,3096,3105,3112,3122,
	3134,3144,3150,3158,3170,3179,3189,3199,3208,3218,
	3225,3236,3249,3256,3265,3271,3278,3284,3291,3300,
	3312,3321,3331,3338,3349,3356,3361,3368,3378,3384,
	3392,3399,3407,3417,3422,3438,3445,3451,3459,3466,
	3470,3477,3482,3495,3508,3525,3539,3553,3568,3584,
	3600,3606,3612,3621,3629,3635,3643,3649,3656,3665,
	3673,3680,3692,3698,3704,3714,3721,3727,3735,3744,
	3752,3758,3765,3771,
};
static const int x86_64_syscall_s2i_i[] = {
	156,43,288,21,163,248,159,183,37,158,
	49,321,12,451,125,126,80,90,92,161,
	305,229,228,230,227,56,435,3,436,42,
	326,85,174,176,32,33,292,213,291,233,
	214,281,441,232,215,284,290,59,322,60,
	231,269,439,221,285,300,301,81,91,268,
	452,93,260,72,75,193,313,196,73,57,
	199,431,190,432,430,433,5,138,74,77,
	202,456,455,449,454,261,177,239,274,211,
	309,79,78,217,108,107,104,115,36,52,
	121,111,39,181,110,140,318,120,118,97,
	98,124,51,55,186,96,102,191,175,254,
	253,294,255,210,207,208,333,206,209,426,
	427,425,16,173,172,252,251,312,320,246,
	250,62,445,444,446,94,192,86,265,50,
	458,194,195,212,198,8,189,459,461,460,
	6,28,453,237,324,319,447,256,27,83,
	258,133,259,149,325,151,9,154,165,442,
	429,279,10,245,244,240,243,242,241,25,
	462,71,68,70,69,26,150,152,11,303,
	35,262,180,2,304,428,257,437,34,298,
	135,438,434,424,22,293,155,330,331,329,
	7,271,157,17,295,327,302,440,448,310,
	311,270,101,182,18,296,328,178,179,443,
	0,187,89,267,19,169,45,299,47,216,
	197,82,264,316,249,219,84,334,13,127,
	14,129,15,130,128,297,146,147,204,315,
	143,145,148,203,314,142,144,24,317,185,
	23,66,64,65,220,40,307,46,44,238,
	450,273,205,218,171,123,122,106,116,170,
	38,308,109,141,114,119,117,113,160,112,
	54,164,105,188,30,31,67,29,48,131,
	282,289,41,53,275,4,137,457,332,168,
	167,88,266,162,277,306,139,99,103,276,
	234,201,222,226,225,224,223,283,287,286,
	100,200,76,184,95,166,63,87,263,272,
	134,323,136,132,280,235,58,153,278,236,
	61,247,1,20,
};
static int x86_64_syscall_s2i(const char *s, int *value) {
	size_t len, i;
	 if (s == NULL || value == NULL)
		return 0;
	len = strlen(s);
	{ char copy[len + 1];
	for (i = 0; i < len; i++) {
		char c = s[i];
		copy[i] = GT_ISUPPER(c) ? c - 'A' + 'a' : c;
	}
	copy[i] = 0;
	return s2i__(x86_64_syscall_strings, x86_64_syscall_s2i_s, x86_64_syscall_s2i_i, 374, copy, value);
	}
}
static const unsigned x86_64_syscall_i2s_direct[] = {
	2400,3765,2022,227,3356,701,1615,2202,1546,1761,
	1819,1965,90,2568,2595,2626,1302,2219,2342,2435,
	3771,23,2145,2916,2887,1899,1940,1703,1621,3284,
	3265,3271,303,307,2070,1990,924,64,3134,962,
	2954,3331,245,8,2980,2448,2972,2466,3291,81,
	1480,1054,934,3338,3225,1066,214,642,3721,436,
	452,3752,1381,3643,2930,2937,2923,3278,1919,1933,
	1926,1912,586,636,715,592,3612,721,871,864,
	118,537,2503,1711,2557,269,1468,3649,3399,2415,
	124,544,130,570,1451,3629,1084,1027,1037,3451,
	3600,2327,1097,3459,907,3249,3105,899,891,3150,
	977,954,3218,3199,3170,914,3112,3189,1017,3179,
	1007,946,3096,3087,1047,104,111,2581,2653,2610,
	2639,3300,3698,1725,3673,2092,3692,3361,707,3445,
	985,3158,2853,2765,2868,2780,2687,2710,2799,1739,
	1946,1752,1954,3727,1766,2156,0,2213,70,43,
	3208,136,3417,30,3236,1777,3635,3392,3384,2441,
	3122,3073,1315,1308,275,1113,289,795,2366,2379,
	2011,969,2334,52,3621,2907,1077,2405,3256,1552,
	669,1104,1458,602,1497,1507,625,2491,1533,647,
	3606,3477,731,2821,2733,3041,1235,1197,1208,1244,
	1187,841,1518,317,354,404,2474,880,3057,2541,
	2943,489,3482,3539,3525,3508,3495,200,170,157,
	184,457,393,344,3470,3714,3744,1646,2987,811,
	1852,1889,1876,1860,1842,1828,1363,3758,35,2529,
	1374,1331,1320,1143,1125,1170,1689,2055,1717,1731,
	577,785,2000,3656,2510,1473,3407,2424,551,468,
	2318,2207,3665,3025,825,3349,3466,3422,3735,1808,
	3704,368,3312,3553,419,499,3584,3568,15,3321,
	427,330,312,2150,1156,2225,2349,2669,2076,2457,
	509,523,2240,1972,2027,143,3438,2963,3144,857,
	2283,2300,1342,612,2839,2751,2519,2899,997,1663,
	1347,86,443,3680,1652,1745,253,2232,2357,2188,
	2167,2178,3378,1221,2563,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,2127,1287,1254,1269,2045,1797,
	687,660,679,694,2116,220,233,2062,2104,478,
	2250,380,1783,2388,1404,1386,1428,1676,2266,762,
	3001,94,560,1629,774,751,737,3368,1487,1562,
	1597,1580,1906,
};
static const char *x86_64_syscall_i2s(int v) {
	return i2s_direct__(x86_64_syscall_strings, x86_64_syscall_i2s_direct, 0, 462, v);
}

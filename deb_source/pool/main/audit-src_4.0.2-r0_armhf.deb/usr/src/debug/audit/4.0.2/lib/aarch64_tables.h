/* This is a generated file, see Makefile.am for its inputs. */
static const char aarch64_syscall_strings[] = "accept\0accept4\0acct\0add_key\0adjtimex\0bind\0bpf\0brk\0cachestat\0capget\0"
	"capset\0chdir\0chroot\0clock_adjtime\0clock_getres\0clock_gettime\0clock_nanosleep\0clock_settime\0clone\0clone3\0"
	"close\0close_range\0connect\0copy_file_range\0delete_module\0dup\0dup3\0epoll_create1\0epoll_ctl\0epoll_pwait\0"
	"epoll_pwait2\0eventfd2\0execve\0execveat\0exit\0exit_group\0faccessat\0faccessat2\0fadvise64\0fallocate\0"
	"fanotify_init\0fanotify_mark\0fchdir\0fchmod\0fchmodat\0fchmodat2\0fchown\0fchownat\0fcntl\0fdatasync\0"
	"fgetxattr\0finit_module\0flistxattr\0flock\0fremovexattr\0fsconfig\0fsetxattr\0fsmount\0fsopen\0fspick\0"
	"fstatfs\0fsync\0ftruncate\0futex\0futex_requeue\0futex_wait\0futex_waitv\0futex_wake\0get_mempolicy\0get_robust_list\0"
	"getcpu\0getcwd\0getdents\0getegid\0geteuid\0getgid\0getgroups\0getitimer\0getpeername\0getpgid\0"
	"getpid\0getppid\0getpriority\0getrandom\0getresgid\0getresuid\0getrlimit\0getrusage\0getsid\0getsockname\0"
	"getsockopt\0gettid\0gettimeofday\0getuid\0getxattr\0init_module\0inotify_add_watch\0inotify_init1\0inotify_rm_watch\0io_cancel\0"
	"io_destroy\0io_getevents\0io_pgetevents\0io_setup\0io_submit\0io_uring_enter\0io_uring_register\0io_uring_setup\0ioctl\0ioprio_get\0"
	"ioprio_set\0kcmp\0kexec_file_load\0kexec_load\0keyctl\0kill\0landlock_add_rule\0landlock_create_ruleset\0landlock_restrict_self\0lgetxattr\0"
	"linkat\0listen\0listmount\0listxattr\0llistxattr\0lookup_dcookie\0lremovexattr\0lseek\0lsetxattr\0lsm_get_self_attr\0"
	"lsm_list_modules\0lsm_set_self_attr\0madvise\0map_shadow_stack\0mbind\0membarrier\0memfd_create\0memfd_secret\0migrate_pages\0mincore\0"
	"mkdirat\0mknodat\0mlock\0mlock2\0mlockall\0mmap\0mount\0mount_setattr\0move_mount\0move_pages\0"
	"mprotect\0mq_getsetattr\0mq_notify\0mq_open\0mq_timedreceive\0mq_timedsend\0mq_unlink\0mremap\0mseal\0msgctl\0"
	"msgget\0msgrcv\0msgsnd\0msync\0munlock\0munlockall\0munmap\0name_to_handle_at\0nanosleep\0newfstat\0"
	"newfstatat\0nfsservctl\0open_by_handle_at\0open_tree\0openat\0openat2\0perf_event_open\0personality\0pidfd_getfd\0pidfd_open\0"
	"pidfd_send_signal\0pipe2\0pivot_root\0pkey_alloc\0pkey_free\0pkey_mprotect\0ppoll\0prctl\0pread\0preadv\0"
	"preadv2\0prlimit64\0process_madvise\0process_mrelease\0process_vm_readv\0process_vm_writev\0pselect6\0ptrace\0pwrite\0pwritev\0"
	"pwritev2\0quotactl\0quotactl_fd\0read\0readahead\0readlinkat\0readv\0reboot\0recvfrom\0recvmmsg\0"
	"recvmsg\0remap_file_pages\0removexattr\0renameat\0renameat2\0request_key\0restart_syscall\0rseq\0rt_sigaction\0rt_sigpending\0"
	"rt_sigprocmask\0rt_sigqueueinfo\0rt_sigreturn\0rt_sigsuspend\0rt_sigtimedwait\0rt_tgsigqueueinfo\0sched_get_priority_max\0sched_get_priority_min\0sched_getaffinity\0sched_getattr\0"
	"sched_getparam\0sched_getscheduler\0sched_rr_get_interval\0sched_setaffinity\0sched_setattr\0sched_setparam\0sched_setscheduler\0sched_yield\0seccomp\0semctl\0"
	"semget\0semop\0semtimedop\0sendfile\0sendmmsg\0sendmsg\0sendto\0set_mempolicy\0set_mempolicy_home_node\0set_robust_list\0"
	"set_tid_address\0setdomainname\0setfsgid\0setfsuid\0setgid\0setgroups\0sethostname\0setitimer\0setns\0setpgid\0"
	"setpriority\0setregid\0setresgid\0setresuid\0setreuid\0setrlimit\0setsid\0setsockopt\0settimeofday\0setuid\0"
	"setxattr\0shmat\0shmctl\0shmdt\0shmget\0shutdown\0sigaltstack\0signalfd4\0socket\0socketpair\0"
	"splice\0statfs\0statmount\0statx\0swapoff\0swapon\0symlinkat\0sync\0sync_file_range\0syncfs\0"
	"sysinfo\0syslog\0tee\0tgkill\0timer_create\0timer_delete\0timer_getoverrun\0timer_gettime\0timer_settime\0timerfd_create\0"
	"timerfd_gettime\0timerfd_settime\0times\0tkill\0truncate\0umask\0umount2\0uname\0unlinkat\0unshare\0"
	"userfaultfd\0utimensat\0vhangup\0vmsplice\0wait4\0waitid\0write\0writev";
static const unsigned aarch64_syscall_s2i_s[] = {
	0,7,15,20,28,37,42,46,50,60,
	67,74,80,87,101,114,128,144,158,164,
	171,177,189,197,213,227,231,236,250,260,
	272,285,294,301,310,315,326,336,347,357,
	367,381,395,402,409,418,428,435,444,450,
	460,470,483,494,500,513,522,532,540,547,
	554,562,568,578,584,598,609,621,632,646,
	662,669,676,685,693,701,708,718,728,740,
	748,755,763,775,785,795,805,815,825,832,
	844,855,862,875,882,891,903,921,935,952,
	962,973,986,1000,1009,1019,1034,1052,1067,1073,
	1084,1095,1100,1116,1127,1134,1139,1157,1181,1204,
	1214,1221,1228,1238,1248,1259,1274,1287,1293,1303,
	1321,1338,1356,1364,1381,1387,1398,1411,1424,1438,
	1446,1454,1462,1468,1475,1484,1489,1495,1509,1520,
	1531,1540,1554,1564,1572,1588,1601,1611,1618,1624,
	1631,1638,1645,1652,1658,1666,1677,1684,1702,1712,
	1721,1732,1743,1761,1771,1778,1786,1802,1814,1826,
	1837,1855,1861,1872,1883,1893,1907,1913,1919,1925,
	1932,1940,1950,1966,1983,2000,2018,2027,2034,2041,
	2049,2058,2067,2079,2084,2094,2105,2111,2118,2127,
	2136,2144,2161,2173,2182,2192,2204,2220,2225,2238,
	2252,2267,2283,2296,2310,2326,2344,2367,2390,2408,
	2422,2437,2456,2478,2496,2510,2525,2544,2556,2564,
	2571,2578,2584,2595,2604,2613,2621,2628,2642,2666,
	2682,2698,2712,2721,2730,2737,2747,2759,2769,2775,
	2783,2795,2804,2814,2824,2833,2843,2850,2861,2874,
	2881,2890,2896,2903,2909,2916,2925,2937,2947,2954,
	2965,2972,2979,2989,2995,3003,3010,3020,3025,3041,
	3048,3056,3063,3067,3074,3087,3100,3117,3131,3145,
	3160,3176,3192,3198,3204,3213,3219,3227,3233,3242,
	3250,3262,3272,3280,3289,3295,3302,3308,
};
static const int aarch64_syscall_s2i_i[] = {
	202,242,89,217,171,200,280,214,451,90,
	91,49,51,266,114,113,115,112,220,435,
	57,436,203,285,106,23,24,20,21,22,
	441,19,221,281,93,94,48,439,223,47,
	262,263,50,52,53,452,55,54,25,83,
	10,273,13,32,16,431,7,432,430,433,
	44,82,46,98,456,455,449,454,236,100,
	168,17,61,177,175,176,158,102,205,155,
	172,173,141,278,150,148,163,165,156,204,
	209,178,169,174,8,105,27,26,28,3,
	1,4,292,0,2,426,427,425,29,31,
	30,272,294,104,219,129,445,444,446,9,
	37,201,458,11,12,18,15,62,6,459,
	461,460,233,453,235,283,279,447,238,232,
	34,33,228,284,230,222,40,442,429,239,
	226,185,184,180,183,182,181,216,462,187,
	186,188,189,227,229,231,215,264,101,80,
	79,42,265,428,56,437,241,92,438,434,
	424,59,41,289,290,288,73,167,67,69,
	286,261,440,448,270,271,72,117,68,70,
	287,60,443,63,213,78,65,142,207,243,
	212,234,14,38,276,218,128,293,134,136,
	135,138,139,133,137,240,125,126,123,275,
	121,120,127,122,274,118,119,124,277,191,
	190,193,192,71,269,211,206,237,450,99,
	96,162,152,151,144,159,161,103,268,154,
	140,143,149,147,145,164,157,208,170,146,
	5,196,195,197,194,210,132,74,198,199,
	76,43,457,291,225,224,36,81,84,267,
	179,116,77,131,107,111,109,108,110,85,
	87,86,153,130,45,166,39,160,35,97,
	282,88,58,75,260,95,64,66,
};
static int aarch64_syscall_s2i(const char *s, int *value) {
	size_t len, i;
	 if (s == NULL || value == NULL)
		return 0;
	len = strlen(s);
	{ char copy[len + 1];
	for (i = 0; i < len; i++) {
		char c = s[i];
		copy[i] = GT_ISUPPER(c) ? c - 'A' + 'a' : c;
	}
	copy[i] = 0;
	return s2i__(aarch64_syscall_strings, aarch64_syscall_s2i_s, aarch64_syscall_s2i_i, 318, copy, value);
	}
}
static const unsigned aarch64_syscall_i2s_direct[] = {
	1000,962,1009,952,973,2881,1293,522,882,1204,
	460,1238,1248,483,2161,1274,500,669,1259,285,
	236,250,260,227,231,444,921,903,935,1067,
	1084,1073,494,1454,1446,3233,3010,1214,2173,3219,
	1489,1861,1732,2972,554,3204,568,357,326,74,
	395,80,402,409,435,428,1771,171,3272,1855,
	2058,676,1287,2079,3302,2105,3308,1919,2034,1925,
	2041,2595,2018,1907,2937,3280,2965,3063,2094,1721,
	1712,3020,562,450,3025,3145,3176,3160,3262,15,
	60,67,1802,310,315,3295,2682,3242,578,2666,
	646,1702,718,2759,1116,891,213,3074,3117,3100,
	3131,3087,144,114,101,128,3056,2027,2510,2525,
	2437,2422,2478,2390,2544,2344,2367,2456,2204,1134,
	3198,3067,2925,2296,2225,2252,2238,2310,2267,2283,
	2783,763,2111,2795,2730,2824,2874,2814,795,2804,
	785,2721,2712,3192,2775,740,825,2843,708,2737,
	3227,2747,2698,805,2833,815,3213,1913,662,862,
	2861,28,748,755,875,693,701,685,855,3048,
	1564,1601,1588,1572,1554,1540,1631,1624,1638,1645,
	2571,2564,2584,2578,2909,2896,2890,2903,2947,2954,
	37,1221,0,189,832,728,2621,2118,2850,844,
	2916,2613,2136,2084,46,1677,1611,20,2192,1127,
	158,294,1484,347,3003,2995,1531,1652,1462,1658,
	1475,1666,1438,1356,2144,1381,632,2628,1424,1520,
	2326,1786,7,2127,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	3289,1940,367,381,1684,1743,87,3041,2769,2604,
	1983,2000,1095,470,2496,2408,2182,2556,775,1398,
	42,301,3250,1387,1468,197,1932,2049,1893,1872,
	1883,2989,986,2220,1100,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,1837,1052,1019,1034,1761,1509,
	540,513,532,547,1826,164,177,1778,1814,336,
	1950,272,1495,2067,1157,1139,1181,1411,1966,609,
	2642,50,418,1364,621,598,584,2979,1228,1303,
	1338,1321,1618,
};
static const char *aarch64_syscall_i2s(int v) {
	return i2s_direct__(aarch64_syscall_strings, aarch64_syscall_i2s_direct, 0, 462, v);
}

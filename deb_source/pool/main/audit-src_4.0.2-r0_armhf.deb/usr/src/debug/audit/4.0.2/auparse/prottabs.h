/* This is a generated file, see Makefile.am for its inputs. */
static const char prot_strings[] = "PROT_EXEC\0PROT_GROWSDOWN\0PROT_GROWSUP\0PROT_READ\0PROT_SEM\0PROT_WRITE";
static const struct transtab prot_table[] = {
	{1,38},{2,57},{4,0},{8,48},{16777216,10},{33554432,25},
};
#define PROT_NUM_ENTRIES (sizeof(prot_table) / sizeof(*prot_table))

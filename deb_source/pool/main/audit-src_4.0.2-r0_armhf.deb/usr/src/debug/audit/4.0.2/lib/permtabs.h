/* This is a generated file, see Makefile.am for its inputs. */
static const char perm_strings[] = "chmod,fchmod,chown,lchown,fchown,setxattr,lsetxattr,fsetxattr,removexattr,lremovexattr,fremovexattr,fchownat,fchmodat,link,linkat\0execve\0readlink,quotactl,listxattr,llistxattr,flistxattr,getxattr,lgetxattr,fgetxattr,readlinkat,open,openat,openat2\0rename,mkdir,rmdir,creat,link,unlink,symlink,mknod,mkdirat,mknodat,unlinkat,renameat,linkat,symlinkat,renameat2,acct,swapon,quotactl,truncate,ftruncate,bind,fallocate,open,openat,openat2";
static const unsigned perm_s2i_s[] = {
	0,130,137,247,
};
static const int perm_s2i_i[] = {
	8,1,4,2,
};
static int perm_s2i(const char *s, int *value) {
	size_t len, i;
	 if (s == NULL || value == NULL)
		return 0;
	len = strlen(s);
	{ char copy[len + 1];
	for (i = 0; i < len; i++) {
		char c = s[i];
		copy[i] = GT_ISUPPER(c) ? c - 'A' + 'a' : c;
	}
	copy[i] = 0;
	return s2i__(perm_strings, perm_s2i_s, perm_s2i_i, 4, copy, value);
	}
}
static const unsigned perm_i2s_direct[] = {
	130,247,-1u,137,-1u,-1u,-1u,0,
};
static const char *perm_i2s(int v) {
	return i2s_direct__(perm_strings, perm_i2s_direct, 1, 8, v);
}

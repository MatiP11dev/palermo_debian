/* This is a generated file, see Makefile.am for its inputs. */
static const char flag_strings[] = "access\0atomic\0continue\0create\0directory\0follow\0noalt\0open\0parent";
static const unsigned flag_s2i_s[] = {
	0,7,14,23,30,40,47,53,58,
};
static const int flag_s2i_i[] = {
	1024,64,4,512,2,1,32,256,16,
};
static int flag_s2i(const char *s, int *value) {
	size_t len, i;
	 if (s == NULL || value == NULL)
		return 0;
	len = strlen(s);
	{ char copy[len + 1];
	for (i = 0; i < len; i++) {
		char c = s[i];
		copy[i] = GT_ISUPPER(c) ? c - 'A' + 'a' : c;
	}
	copy[i] = 0;
	return s2i__(flag_strings, flag_s2i_s, flag_s2i_i, 9, copy, value);
	}
}
static const int flag_i2s_i[] = {
	1,2,4,16,32,64,256,512,1024,
};
static const unsigned flag_i2s_s[] = {
	40,30,14,58,47,7,53,23,0,
};
static const char *flag_i2s(int v) {
	return i2s_bsearch__(flag_strings, flag_i2s_i, flag_i2s_s, 9, v);
}

/* This is a generated file, see Makefile.am for its inputs. */
static const char fsconfig_strings[] = "FSCONFIG_CMD_CREATE\0FSCONFIG_CMD_CREATE_EXCL\0FSCONFIG_CMD_RECONFIGURE\0FSCONFIG_SET_BINARY\0FSCONFIG_SET_FD\0FSCONFIG_SET_FLAG\0FSCONFIG_SET_PATH\0FSCONFIG_SET_PATH_EMPTY\0FSCONFIG_SET_STRING";
static const unsigned fsconfig_i2s_direct[] = {
	106,166,70,124,142,90,0,45,20,
};
static const char *fsconfig_i2s(int v) {
	return i2s_direct__(fsconfig_strings, fsconfig_i2s_direct, 0, 8, v);
}

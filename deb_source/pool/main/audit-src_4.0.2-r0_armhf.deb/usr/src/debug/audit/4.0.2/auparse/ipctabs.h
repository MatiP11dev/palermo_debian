/* This is a generated file, see Makefile.am for its inputs. */
static const char ipc_strings[] = "dipc\0msgctl\0msgget\0msgrcv\0msgsnd\0semctl\0semget\0semop\0semtimedop\0shmat\0"
	"shmctl\0shmdt\0shmget";
static const unsigned ipc_i2s_direct[] = {
	47,40,33,53,-1u,-1u,-1u,-1u,-1u,-1u,
	26,19,12,5,-1u,-1u,-1u,-1u,-1u,-1u,
	64,77,83,70,0,
};
static const char *ipc_i2s(int v) {
	return i2s_direct__(ipc_strings, ipc_i2s_direct, 1, 25, v);
}

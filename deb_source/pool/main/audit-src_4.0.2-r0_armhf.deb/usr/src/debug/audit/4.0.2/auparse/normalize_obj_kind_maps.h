/* This is a generated file, see Makefile.am for its inputs. */
static const char normalize_obj_kind_map_strings[] = "account\0admin-defined-rule\0audit-config\0block-device\0character-device\0device\0directory\0fifo\0file\0file-system\0"
	"firewall\0integrity-policy\0keystrokes\0memory\0printer\0process\0security-policy\0service\0socket\0software\0"
	"symlink\0system\0unknown\0user-session\0virtual-machine";
static const unsigned normalize_obj_kind_map_i2s_direct[] = {
	224,87,53,77,40,92,209,193,161,109,
	185,0,232,245,153,217,8,27,169,97,
	146,135,70,200,118,
};
static const char *normalize_obj_kind_map_i2s(int v) {
	return i2s_direct__(normalize_obj_kind_map_strings, normalize_obj_kind_map_i2s_direct, 0, 24, v);
}

/* This is a generated file, see Makefile.am for its inputs. */
static const char s390x_syscall_strings[] = "_sysctl\0accept4\0access\0acct\0add_key\0adjtimex\0afs_syscall\0alarm\0bdflush\0bind\0"
	"bpf\0brk\0cachestat\0capget\0capset\0chdir\0chmod\0chown\0chroot\0clock_adjtime\0"
	"clock_getres\0clock_gettime\0clock_nanosleep\0clock_settime\0clone\0clone3\0close\0close_range\0connect\0copy_file_range\0"
	"creat\0create_module\0delete_module\0dup\0dup2\0dup3\0epoll_create\0epoll_create1\0epoll_ctl\0epoll_pwait\0"
	"epoll_pwait2\0epoll_wait\0eventfd\0eventfd2\0execve\0execveat\0exit\0exit_group\0faccessat\0faccessat2\0"
	"fadvise64\0fallocate\0fanotify_init\0fanotify_mark\0fchdir\0fchmod\0fchmodat\0fchmodat2\0fchown\0fchownat\0"
	"fcntl\0fdatasync\0fgetxattr\0finit_module\0flistxattr\0flock\0fork\0fremovexattr\0fsconfig\0fsetxattr\0"
	"fsmount\0fsopen\0fspick\0fstat\0fstatfs\0fstatfs64\0fsync\0ftruncate\0futex\0futex_requeue\0"
	"futex_wait\0futex_waitv\0futex_wake\0futimesat\0get_kernel_syms\0get_robust_list\0getcpu\0getcwd\0getdents\0getegid\0"
	"geteuid\0getgid\0getgroups\0getitimer\0getpeername\0getpgid\0getpgrp\0getpid\0getpmsg\0getppid\0"
	"getpriority\0getrandom\0getresgid\0getresuid\0getrlimit\0getrusage\0getsid\0getsockname\0getsockopt\0gettid\0"
	"gettimeofday\0getuid\0getxattr\0idle\0init_module\0inotify_add_watch\0inotify_init\0inotify_init1\0inotify_rm_watch\0io_cancel\0"
	"io_destroy\0io_getevents\0io_pgetevents\0io_setup\0io_submit\0io_uring_enter\0io_uring_register\0io_uring_setup\0ioctl\0ioprio_get\0"
	"ioprio_set\0ipc\0kcmp\0kexec_file_load\0kexec_load\0keyctl\0kill\0landlock_add_rule\0landlock_create_ruleset\0landlock_restrict_self\0"
	"lchown\0lgetxattr\0link\0linkat\0listen\0listmount\0listxattr\0llistxattr\0lremovexattr\0lseek\0"
	"lsetxattr\0lsm_get_self_attr\0lsm_list_modules\0lsm_set_self_attr\0lstat\0madvise\0map_shadow_stack\0membarrier\0memfd_create\0mincore\0"
	"mkdir\0mkdirat\0mknod\0mknodat\0mlock\0mlock2\0mlockall\0mmap\0mount\0mount_setattr\0"
	"move_mount\0mprotect\0mq_getsetattr\0mq_notify\0mq_open\0mq_timedreceive\0mq_timedsend\0mq_unlink\0mremap\0mseal\0"
	"msync\0munlock\0munlockall\0munmap\0name_to_handle_at\0nanosleep\0newfstatat\0nfsservctl\0nice\0open\0"
	"open_by_handle_at\0open_tree\0openat\0openat2\0pause\0perf_event_open\0personality\0pidfd_getfd\0pidfd_open\0pidfd_send_signal\0"
	"pipe\0pipe2\0pivot_root\0pkey_alloc\0pkey_free\0pkey_mprotect\0poll\0ppoll\0prctl\0pread\0"
	"preadv\0preadv2\0prlimit64\0process_madvise\0process_mrelease\0process_vm_readv\0process_vm_writev\0pselect6\0ptrace\0putpmsg\0"
	"pwrite\0pwritev\0pwritev2\0query_module\0quotactl\0quotactl_fd\0read\0readahead\0readdir\0readlink\0"
	"readlinkat\0readv\0reboot\0recvfrom\0recvmmsg\0recvmsg\0remap_file_pages\0removexattr\0rename\0renameat\0"
	"renameat2\0request_key\0rmdir\0rseq\0rt_sigaction\0rt_sigpending\0rt_sigprocmask\0rt_sigqueueinfo\0rt_sigreturn\0rt_sigsuspend\0"
	"rt_sigtimedwait\0rt_tgsigqueueinfo\0s390_pci_mmio_read\0s390_pci_mmio_write\0s390_runtime_instr\0s390_sthyi\0sched_get_priority_max\0sched_get_priority_min\0sched_getaffinity\0sched_getattr\0"
	"sched_getparam\0sched_getscheduler\0sched_rr_get_interval\0sched_setaffinity\0sched_setattr\0sched_setparam\0sched_setscheduler\0sched_yield\0seccomp\0select\0"
	"sendfile\0sendmmsg\0sendmsg\0sendto\0set_mempolicy_home_node\0set_robust_list\0set_tid_address\0setdomainname\0setfsgid\0setfsuid\0"
	"setgid\0setgroups\0sethostname\0setitimer\0setns\0setpgid\0setpriority\0setregid\0setresgid\0setresuid\0"
	"setreuid\0setrlimit\0setsid\0setsockopt\0settimeofday\0setuid\0setxattr\0shutdown\0sigaction\0sigaltstack\0"
	"signal\0signalfd\0signalfd4\0sigpending\0sigprocmask\0sigreturn\0sigsuspend\0socket\0socketcall\0socketpair\0"
	"splice\0stat\0statfs\0statfs64\0statmount\0statx\0swapoff\0swapon\0symlink\0symlinkat\0"
	"sync\0sync_file_range\0syncfs\0sysfs\0sysinfo\0syslog\0tee\0tgkill\0timer_create\0timer_delete\0"
	"timer_getoverrun\0timer_gettime\0timer_settime\0timerfd\0timerfd_create\0timerfd_gettime\0timerfd_settime\0times\0tkill\0truncate\0"
	"umask\0umount\0umount2\0uname\0unlink\0unlinkat\0unshare\0uselib\0userfaultfd\0ustat\0"
	"utime\0utimensat\0utimes\0vfork\0vhangup\0vmsplice\0wait4\0waitid\0write\0writev";
static const unsigned s390x_syscall_s2i_s[] = {
	0,8,16,23,28,36,45,57,63,71,
	76,80,84,94,101,108,114,120,126,133,
	147,160,174,190,204,210,217,223,235,243,
	259,265,279,293,297,302,307,320,334,344,
	356,369,380,388,397,404,413,418,429,439,
	450,460,470,484,498,505,512,521,531,538,
	547,553,563,573,586,597,603,608,621,630,
	640,648,655,662,668,676,686,692,702,708,
	722,733,745,756,766,782,798,805,812,821,
	829,837,844,854,864,876,884,892,899,907,
	915,927,937,947,957,967,977,984,996,1007,
	1014,1027,1034,1043,1048,1060,1078,1091,1105,1122,
	1132,1143,1156,1170,1179,1189,1204,1222,1237,1243,
	1254,1265,1269,1274,1290,1301,1308,1313,1331,1355,
	1378,1385,1395,1400,1407,1414,1424,1434,1445,1458,
	1464,1474,1492,1509,1527,1533,1541,1558,1569,1582,
	1590,1596,1604,1610,1618,1624,1631,1640,1645,1651,
	1665,1676,1685,1699,1709,1717,1733,1746,1756,1763,
	1769,1775,1783,1794,1801,1819,1829,1840,1851,1856,
	1861,1879,1889,1896,1904,1910,1926,1938,1950,1961,
	1979,1984,1990,2001,2012,2022,2036,2041,2047,2053,
	2059,2066,2074,2084,2100,2117,2134,2152,2161,2168,
	2176,2183,2191,2200,2213,2222,2234,2239,2249,2257,
	2266,2277,2283,2290,2299,2308,2316,2333,2345,2352,
	2361,2371,2383,2389,2394,2407,2421,2436,2452,2465,
	2479,2495,2513,2532,2552,2571,2582,2605,2628,2646,
	2660,2675,2694,2716,2734,2748,2763,2782,2794,2802,
	2809,2818,2827,2835,2842,2866,2882,2898,2912,2921,
	2930,2937,2947,2959,2969,2975,2983,2995,3004,3014,
	3024,3033,3043,3050,3061,3074,3081,3090,3099,3109,
	3121,3128,3137,3147,3158,3170,3180,3191,3198,3209,
	3220,3227,3232,3239,3248,3258,3264,3272,3279,3287,
	3297,3302,3318,3325,3331,3339,3346,3350,3357,3370,
	3383,3400,3414,3428,3436,3451,3467,3483,3489,3495,
	3504,3510,3517,3525,3531,3538,3547,3555,3562,3574,
	3580,3586,3596,3603,3609,3617,3626,3632,3639,3645,
};
static const int s390x_syscall_s2i_i[] = {
	149,364,33,51,278,124,137,27,134,361,
	351,45,451,184,185,12,15,212,61,337,
	261,260,262,259,120,435,6,436,362,375,
	8,127,129,41,63,326,249,327,250,312,
	441,251,318,323,11,354,1,248,300,439,
	253,314,332,333,133,94,299,452,207,291,
	55,148,229,344,232,143,2,235,431,226,
	432,430,433,108,100,266,118,93,238,456,
	455,449,454,292,130,305,311,183,141,202,
	201,200,205,105,368,132,65,20,188,64,
	96,349,211,209,191,77,147,367,365,236,
	78,199,227,112,128,285,284,324,286,247,
	244,245,382,243,246,426,427,425,54,283,
	282,117,343,381,277,280,37,445,444,446,
	198,228,9,296,363,458,230,231,234,19,
	225,459,461,460,107,219,453,356,350,218,
	39,289,14,290,150,374,152,90,21,442,
	429,125,276,275,271,274,273,272,163,462,
	144,151,153,91,335,162,293,169,34,5,
	336,428,288,437,29,331,136,438,434,424,
	42,325,217,385,386,384,168,302,172,180,
	328,376,334,440,448,340,341,301,26,189,
	181,329,377,167,131,443,3,222,89,85,
	298,145,88,371,357,372,267,233,38,295,
	347,279,40,383,174,176,175,178,173,179,
	177,330,353,352,342,380,159,160,240,346,
	155,157,161,239,345,154,156,158,348,142,
	187,358,370,369,450,304,252,121,216,215,
	214,206,74,104,339,57,97,204,210,208,
	203,75,66,366,79,213,224,373,67,186,
	48,316,322,73,126,119,72,359,102,360,
	306,106,99,265,457,379,115,87,83,297,
	36,307,338,135,116,103,308,241,254,258,
	257,256,255,317,319,321,320,43,237,92,
	60,22,52,122,10,294,303,86,355,62,
	30,315,313,190,111,309,114,281,4,146,
};
static int s390x_syscall_s2i(const char *s, int *value) {
	size_t len, i;
	 if (s == NULL || value == NULL)
		return 0;
	len = strlen(s);
	{ char copy[len + 1];
	for (i = 0; i < len; i++) {
		char c = s[i];
		copy[i] = GT_ISUPPER(c) ? c - 'A' + 'a' : c;
	}
	copy[i] = 0;
	return s2i__(s390x_syscall_strings, s390x_syscall_s2i_s, s390x_syscall_s2i_i, 360, copy, value);
	}
}
static const unsigned s390x_syscall_i2s_direct[] = {
	413,603,2234,3639,1856,217,-1u,259,1395,3531,
	397,108,-1u,1604,114,-1u,-1u,-1u,1458,892,
	1645,3510,-1u,-1u,-1u,2161,57,-1u,1904,3580,
	-1u,-1u,16,1851,-1u,3297,1308,2345,1590,2383,
	293,1979,3483,-1u,80,-1u,-1u,3121,-1u,-1u,
	23,3517,-1u,1237,547,-1u,2975,-1u,-1u,3504,
	126,3574,297,907,884,3043,3099,-1u,-1u,-1u,
	-1u,3180,3147,2947,3033,-1u,967,1014,3061,-1u,
	-1u,-1u,3279,-1u,2257,3555,3272,2283,2249,1640,
	1794,3495,692,505,-1u,915,2983,-1u,3232,668,
	-1u,3198,3339,2959,854,3227,1527,662,-1u,-1u,
	3609,1043,-1u,3626,3264,3331,1265,686,3170,204,
	2898,3525,-1u,36,1676,3158,265,1048,279,766,
	2213,876,498,63,3325,1926,45,-1u,-1u,-1u,
	812,2802,597,1769,2277,3645,977,553,0,1618,
	1775,1631,1783,2748,2660,2763,2675,2782,2582,2605,
	2694,1819,1756,-1u,-1u,-1u,2200,2036,1840,-1u,
	-1u,2047,2452,2394,2421,2407,2479,2436,2465,2053,
	2176,-1u,805,94,101,3109,2809,899,2168,3603,
	957,-1u,-1u,-1u,-1u,-1u,-1u,1378,1027,837,
	829,821,3024,2995,844,2937,531,3014,947,3004,
	937,120,3074,2930,2921,2912,1990,1582,1533,-1u,
	-1u,2239,-1u,3081,1464,630,1034,1385,563,1424,
	1434,586,2333,1445,608,1007,3489,702,2716,2628,
	3350,-1u,1170,1132,1143,1179,1122,418,307,334,
	369,2882,450,3357,3414,3400,3383,3370,190,160,
	147,174,-1u,-1u,3239,676,2316,-1u,-1u,-1u,
	1709,1746,1733,1717,1699,1685,1290,28,2371,1301,
	3632,1254,1243,1078,1060,1105,-1u,1889,1596,1610,
	538,756,1829,3538,2352,1400,3287,2266,512,429,
	2152,2041,3547,2866,782,3220,3302,3346,3617,-1u,
	798,344,3596,460,3586,3128,3428,380,3436,3467,
	3451,3137,388,1091,1984,302,320,2059,2183,2495,
	1910,470,484,2074,1801,1861,133,3318,2969,2117,
	2134,2552,1269,573,2734,2646,2361,2794,927,1569,
	76,2532,2513,404,3562,1558,2299,2818,3191,3209,
	71,235,1407,8,996,3050,984,864,2835,2827,
	2290,2308,3090,1624,243,2066,2191,-1u,3258,2571,
	1274,1156,2389,2022,2001,2012,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,-1u,
	-1u,-1u,-1u,1961,1222,1189,1204,1879,1665,648,
	621,640,655,1950,210,223,1896,1938,439,2084,
	356,1651,2222,1331,1313,1355,-1u,2100,733,2842,
	84,521,1541,745,722,708,3248,1414,1474,1509,
	1492,1763,
};
static const char *s390x_syscall_i2s(int v) {
	return i2s_direct__(s390x_syscall_strings, s390x_syscall_i2s_direct, 1, 462, v);
}

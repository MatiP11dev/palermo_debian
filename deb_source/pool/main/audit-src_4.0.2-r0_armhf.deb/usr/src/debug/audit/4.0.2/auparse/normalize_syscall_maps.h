/* This is a generated file, see Makefile.am for its inputs. */
static const char normalize_syscall_map_strings[] = "accept\0accept4\0access\0adjtimex\0bind\0brk\0chmod\0chown\0clock_settime\0clock_settime64\0"
	"connect\0creat\0delete_module\0execve\0execveat\0faccessat\0faccessat2\0fallocate\0fchmod\0fchmodat\0"
	"fchmodat2\0fchown\0fchownat\0fchownat2\0finit_module\0fremovexattr\0fsconfig\0fsetxattr\0fsmount\0fsopen\0"
	"fspick\0fstat\0fstatfs\0ftruncate\0futimesat\0init_module\0kill\0landlock_add_rule\0landlock_create_ruleset\0landlock_restrict_self\0"
	"lchown\0lremovexattr\0lsetxattr\0lsm_set_self_attr\0lstat\0map_shadow_stack\0memfd_create\0memfd_secret\0mkdir\0mkdirat\0"
	"mknod\0mknodat\0mmap\0mount\0mount_setattr\0move_mount\0mseal\0newfstatat\0open\0open_by_handle_at\0"
	"openat\0openat2\0pidfd_getfd\0readlink\0readlinkat\0recvfrom\0recvmsg\0removexattr\0rename\0renameat\0"
	"renameat2\0rmdir\0sched_setattr\0sched_setparam\0sched_setscheduler\0sendmsg\0sendto\0setdomainname\0setegid\0seteuid\0"
	"setfsgid\0setfsuid\0setgid\0sethostname\0setregid\0setresgid\0setresuid\0setreuid\0settimeofday\0setuid\0"
	"setxattr\0stat\0stat64\0statfs\0statmount\0statx\0stime\0symlink\0symlinkat\0tgkill\0"
	"tkill\0truncate\0umount\0umount2\0unlink\0unlinkat\0utime\0utimensat\0utimes";
static const unsigned normalize_syscall_map_s2i_s[] = {
	0,7,15,22,31,36,40,46,52,66,
	82,90,96,110,117,126,136,147,157,164,
	173,183,190,199,209,222,235,244,254,262,
	269,276,282,290,300,310,322,327,345,369,
	392,399,412,422,440,446,463,476,489,495,
	503,509,517,522,528,542,553,559,570,575,
	593,600,608,620,629,640,649,657,669,676,
	685,695,701,715,730,749,757,764,778,786,
	794,803,812,819,831,840,850,860,869,882,
	889,898,903,910,917,927,933,939,947,957,
	964,970,979,986,994,1001,1010,1016,1026,
};
static const int normalize_syscall_map_s2i_i[] = {
	16,16,10,31,17,35,3,4,31,31,
	18,1,6,15,15,10,10,1,3,3,
	3,4,4,4,5,2,8,2,8,8,
	8,10,34,1,14,5,21,40,40,40,
	4,2,2,40,10,35,1,1,7,7,
	32,32,35,8,2,8,40,10,1,1,
	1,1,1,1,1,19,19,2,9,9,
	9,13,36,36,36,20,20,33,30,29,
	30,29,30,33,30,30,29,29,31,29,
	2,10,10,34,34,10,31,11,11,21,
	21,1,12,12,13,13,14,14,14,
};
static int normalize_syscall_map_s2i(const char *s, int *value) {
	size_t len, i;
	 if (s == NULL || value == NULL)
		return 0;
	len = strlen(s);
	{ char copy[len + 1];
	for (i = 0; i < len; i++) {
		char c = s[i];
		copy[i] = GT_ISUPPER(c) ? c - 'A' + 'a' : c;
	}
	copy[i] = 0;
	return s2i__(normalize_syscall_map_strings, normalize_syscall_map_s2i_s, normalize_syscall_map_s2i_i, 109, copy, value);
	}
}

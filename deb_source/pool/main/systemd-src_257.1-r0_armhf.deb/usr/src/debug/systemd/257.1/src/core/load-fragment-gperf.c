/* ANSI-C code produced by gperf version 3.1 */
/* Command-line: gperf --output-file src/core/load-fragment-gperf.c src/core/load-fragment-gperf.gperf  */
/* Computed positions: -k'2,7-10,13,16,$' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 1 "src/core/load-fragment-gperf.gperf"

#if __GNUC__ >= 7
_Pragma("GCC diagnostic ignored \"-Wimplicit-fallthrough\"")
#endif
#include <stddef.h>
#include "all-units.h"
#include "conf-parser.h"
#include "image-policy.h"
#include "in-addr-prefix-util.h"
#include "load-fragment.h"
#include <string.h>

#define TOTAL_KEYWORDS 1341
#define MIN_WORD_LENGTH 9
#define MAX_WORD_LENGTH 43
#define MIN_HASH_VALUE 74
#define MAX_HASH_VALUE 11660
/* maximum key range = 11587, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
load_fragment_gperf_hash (register const char *str, register size_t len)
{
  static const unsigned short asso_values[] =
    {
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661,    60, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661,  1610,  1564,  1070,   815,  1962,
       3603,   475,   245,  1520, 11661,  3413,  1235,   380,  1202,  1395,
         95,    50,   290,   160,  3193,  1549,    10,  1876, 11661,    20,
         80, 11661, 11661, 11661, 11661, 11661, 11661,    35,   662,   240,
         25,     0,  3628,   695,   940,     0,    10,  1329,   295,   360,
         30,    30,   600,     0,    10,    15,     0,   980,  1698,   490,
       1490,   155,     5, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661, 11661,
      11661, 11661, 11661, 11661, 11661, 11661
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[15]];
      /*FALLTHROUGH*/
      case 15:
      case 14:
      case 13:
        hval += asso_values[(unsigned char)str[12]];
      /*FALLTHROUGH*/
      case 12:
      case 11:
      case 10:
        hval += asso_values[(unsigned char)str[9]];
      /*FALLTHROUGH*/
      case 9:
        hval += asso_values[(unsigned char)str[8]];
      /*FALLTHROUGH*/
      case 8:
        hval += asso_values[(unsigned char)str[7]];
      /*FALLTHROUGH*/
      case 7:
        hval += asso_values[(unsigned char)str[6]];
      /*FALLTHROUGH*/
      case 6:
      case 5:
      case 4:
      case 3:
      case 2:
        hval += asso_values[(unsigned char)str[1]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

const struct ConfigPerfItem *
load_fragment_gperf_lookup (register const char *str, register size_t len)
{
  static const struct ConfigPerfItem wordlist[] =
    {
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1202 "src/core/load-fragment-gperf.gperf"
      {"Path.Unit",                                    config_parse_trigger_unit,                          0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 117 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertFirstBoot",                         config_parse_unit_condition_string,                 CONDITION_FIRST_BOOT,               offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 121 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertKernelCommandLine",                 config_parse_unit_condition_string,                 CONDITION_KERNEL_COMMAND_LINE,      offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 118 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertArchitecture",                      config_parse_unit_condition_string,                 CONDITION_ARCHITECTURE,             offsetof(Unit, asserts)},
      {(char*)0},
#line 135 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertMemoryPressure",                    config_parse_unit_condition_string,                 CONDITION_MEMORY_PRESSURE,          offsetof(Unit, asserts)},
      {(char*)0},
#line 116 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertNeedsUpdate",                       config_parse_unit_condition_path,                   CONDITION_NEEDS_UPDATE,             offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 131 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertUser",                              config_parse_unit_condition_string,                 CONDITION_USER,                     offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 120 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertHost",                              config_parse_unit_condition_string,                 CONDITION_HOST,                     offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 122 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertKernelVersion",                     config_parse_unit_condition_string,                 CONDITION_KERNEL_VERSION,           offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 130 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertEnvironment",                       config_parse_unit_condition_string,                 CONDITION_ENVIRONMENT,              offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 28 "src/core/load-fragment-gperf.gperf"
      {"Unit.Wants",                                   config_parse_unit_deps,                             UNIT_WANTS,                         0},
#line 1189 "src/core/load-fragment-gperf.gperf"
      {"Timer.Persistent",                             config_parse_bool,                                  0,                                  offsetof(Timer, persistent)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 29 "src/core/load-fragment-gperf.gperf"
      {"Unit.BindsTo",                                 config_parse_unit_deps,                             UNIT_BINDS_TO,                      0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 133 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertControlGroupController",            config_parse_unit_condition_string,                 CONDITION_CONTROL_GROUP_CONTROLLER, offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 86 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionFirmware",                       config_parse_unit_condition_string,                 CONDITION_FIRMWARE,                 offsetof(Unit, conditions)},
#line 84 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionFirstBoot",                      config_parse_unit_condition_string,                 CONDITION_FIRST_BOOT,               offsetof(Unit, conditions)},
      {(char*)0},
#line 83 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionNeedsUpdate",                    config_parse_unit_condition_path,                   CONDITION_NEEDS_UPDATE,             offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0},
#line 103 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionMemoryPressure",                 config_parse_unit_condition_string,                 CONDITION_MEMORY_PRESSURE,          offsetof(Unit, conditions)},
      {(char*)0},
#line 82 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionFileIsExecutable",               config_parse_unit_condition_path,                   CONDITION_FILE_IS_EXECUTABLE,       offsetof(Unit, conditions)},
#line 89 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionKernelCommandLine",              config_parse_unit_condition_string,                 CONDITION_KERNEL_COMMAND_LINE,      offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 85 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionArchitecture",                   config_parse_unit_condition_string,                 CONDITION_ARCHITECTURE,             offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 128 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertCPUFeature",                        config_parse_unit_condition_string,                 CONDITION_CPU_FEATURE,              offsetof(Unit, asserts)},
      {(char*)0},
#line 99 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionUser",                           config_parse_unit_condition_string,                 CONDITION_USER,                     offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 88 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionHost",                           config_parse_unit_condition_string,                 CONDITION_HOST,                     offsetof(Unit, conditions)},
      {(char*)0},
#line 129 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertCPUs",                              config_parse_unit_condition_string,                 CONDITION_CPUS,                     offsetof(Unit, asserts)},
      {(char*)0},
#line 136 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertCPUPressure",                       config_parse_unit_condition_string,                 CONDITION_CPU_PRESSURE,             offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 98 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionEnvironment",                    config_parse_unit_condition_string,                 CONDITION_ENVIRONMENT,              offsetof(Unit, conditions)},
#line 866 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectHostname",                     config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.protect_hostname)},
#line 90 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionKernelVersion",                  config_parse_unit_condition_string,                 CONDITION_KERNEL_VERSION,           offsetof(Unit, conditions)},
#line 87 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionVirtualization",                 config_parse_unit_condition_string,                 CONDITION_VIRTUALIZATION,           offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 78 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionPathIsReadWrite",                config_parse_unit_condition_path,                   CONDITION_PATH_IS_READ_WRITE,       offsetof(Unit, conditions)},
#line 77 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionPathIsMountPoint",               config_parse_unit_condition_path,                   CONDITION_PATH_IS_MOUNT_POINT,      offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0},
#line 825 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectKernelLogs",                   config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.protect_kernel_logs)},
      {(char*)0}, {(char*)0},
#line 824 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectKernelModules",                config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.protect_kernel_modules)},
#line 823 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectKernelTunables",               config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.protect_kernel_tunables)},
      {(char*)0},
#line 73 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionPathExists",                     config_parse_unit_condition_path,                   CONDITION_PATH_EXISTS,              offsetof(Unit, conditions)},
      {(char*)0},
#line 101 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionControlGroupController",         config_parse_unit_condition_string,                 CONDITION_CONTROL_GROUP_CONTROLLER, offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 584 "src/core/load-fragment-gperf.gperf"
      {"Socket.PrivateDevices",                      config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.private_devices)},
      {(char*)0}, {(char*)0},
#line 79 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionPathIsEncrypted",                config_parse_unit_condition_path,                   CONDITION_PATH_IS_ENCRYPTED,        offsetof(Unit, conditions)},
      {(char*)0},
#line 827 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectControlGroups",                config_parse_protect_control_groups,                0,                                  offsetof(Mount, exec_context.protect_control_groups)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 594 "src/core/load-fragment-gperf.gperf"
      {"Socket.PrivateUsers",                        config_parse_private_users,                         0,                                  offsetof(Socket, exec_context.private_users)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 127 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertMemory",                            config_parse_unit_condition_string,                 CONDITION_MEMORY,                   offsetof(Unit, asserts)},
      {(char*)0},
#line 124 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertSecurity",                          config_parse_unit_condition_string,                 CONDITION_SECURITY,                 offsetof(Unit, asserts)},
      {(char*)0},
#line 316 "src/core/load-fragment-gperf.gperf"
      {"Service.StateDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_STATE].mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 595 "src/core/load-fragment-gperf.gperf"
      {"Socket.PrivateMounts",                       config_parse_tristate,                              0,                                  offsetof(Socket, exec_context.private_mounts)},
      {(char*)0}, {(char*)0},
#line 245 "src/core/load-fragment-gperf.gperf"
      {"Service.SecureBits",                          config_parse_exec_secure_bits,                      0,                                  offsetof(Service, exec_context.secure_bits)},
#line 96 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionCPUFeature",                     config_parse_unit_condition_string,                 CONDITION_CPU_FEATURE,              offsetof(Unit, conditions)},
#line 104 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionCPUPressure",                    config_parse_unit_condition_string,                 CONDITION_CPU_PRESSURE,             offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 97 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionCPUs",                           config_parse_unit_condition_string,                 CONDITION_CPUS,                     offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 181 "src/core/load-fragment-gperf.gperf"
      {"Service.Sockets",                              config_parse_service_sockets,                       0,                                  0},
      {(char*)0},
#line 458 "src/core/load-fragment-gperf.gperf"
      {"Socket.PassCredentials",                       config_parse_bool,                                  0,                                  offsetof(Socket, pass_cred)},
      {(char*)0}, {(char*)0},
#line 325 "src/core/load-fragment-gperf.gperf"
      {"Service.SetCredentialEncrypted",              config_parse_set_credential,                        1,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 224 "src/core/load-fragment-gperf.gperf"
      {"Service.StandardInput",                       config_parse_exec_input,                            0,                                  offsetof(Service, exec_context)},
#line 225 "src/core/load-fragment-gperf.gperf"
      {"Service.StandardOutput",                      config_parse_exec_output,                           0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0},
#line 227 "src/core/load-fragment-gperf.gperf"
      {"Service.StandardInputText",                   config_parse_exec_input_text,                       0,                                  offsetof(Service, exec_context)},
      {(char*)0},
#line 511 "src/core/load-fragment-gperf.gperf"
      {"Socket.PassEnvironment",                     config_parse_pass_environ,                          0,                                  offsetof(Socket, exec_context.pass_environment)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 226 "src/core/load-fragment-gperf.gperf"
      {"Service.StandardError",                       config_parse_exec_output,                           0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0},
#line 755 "src/core/load-fragment-gperf.gperf"
      {"Mount.StandardError",                       config_parse_exec_output,                           0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0},
#line 205 "src/core/load-fragment-gperf.gperf"
      {"Service.SetLoginEnvironment",                 config_parse_tristate,                              0,                                  offsetof(Service, exec_context.set_login_environment)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 753 "src/core/load-fragment-gperf.gperf"
      {"Mount.StandardInput",                       config_parse_exec_input,                            0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 756 "src/core/load-fragment-gperf.gperf"
      {"Mount.StandardInputText",                   config_parse_exec_input_text,                       0,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 95 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionMemory",                         config_parse_unit_condition_string,                 CONDITION_MEMORY,                   offsetof(Unit, conditions)},
#line 461 "src/core/load-fragment-gperf.gperf"
      {"Socket.PassPacketInfo",                        config_parse_bool,                                  0,                                  offsetof(Socket, pass_pktinfo)},
#line 92 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionSecurity",                       config_parse_unit_condition_string,                 CONDITION_SECURITY,                 offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 81 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionFileNotEmpty",                   config_parse_unit_condition_path,                   CONDITION_FILE_NOT_EMPTY,           offsetof(Unit, conditions)},
      {(char*)0},
#line 102 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionOSRelease",                      config_parse_unit_condition_string,                 CONDITION_OS_RELEASE,               offsetof(Unit, conditions)},
#line 306 "src/core/load-fragment-gperf.gperf"
      {"Service.PrivatePIDs",                         config_parse_private_pids,                          0,                                  offsetof(Service, exec_context.private_pids)},
#line 228 "src/core/load-fragment-gperf.gperf"
      {"Service.StandardInputData",                   config_parse_exec_input_data,                       0,                                  offsetof(Service, exec_context)},
#line 80 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionDirectoryNotEmpty",              config_parse_unit_condition_path,                   CONDITION_DIRECTORY_NOT_EMPTY,      offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0},
#line 616 "src/core/load-fragment-gperf.gperf"
      {"Socket.SetCredentialEncrypted",              config_parse_set_credential,                        1,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 168 "src/core/load-fragment-gperf.gperf"
      {"Service.PermissionsStartOnly",                 config_parse_bool,                                  0,                                  offsetof(Service, permissions_start_only)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1204 "src/core/load-fragment-gperf.gperf"
      {"Path.DirectoryMode",                           config_parse_mode,                                  0,                                  offsetof(Path, directory_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 757 "src/core/load-fragment-gperf.gperf"
      {"Mount.StandardInputData",                   config_parse_exec_input_data,                       0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 841 "src/core/load-fragment-gperf.gperf"
      {"Mount.Personality",                         config_parse_personality,                           0,                                  offsetof(Mount, exec_context.personality)},
#line 252 "src/core/load-fragment-gperf.gperf"
      {"Service.ProcSubset",                          config_parse_proc_subset,                           0,                                  offsetof(Service, exec_context.proc_subset)},
#line 93 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionCapability",                     config_parse_unit_condition_string,                 CONDITION_CAPABILITY,               offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 75 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionPathIsDirectory",                config_parse_unit_condition_path,                   CONDITION_PATH_IS_DIRECTORY,        offsetof(Unit, conditions)},
#line 448 "src/core/load-fragment-gperf.gperf"
      {"Socket.Priority",                              config_parse_int,                                   0,                                  offsetof(Socket, priority)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 23 "src/core/load-fragment-gperf.gperf"
      {"Unit.Description",                             config_parse_unit_string_printf,                    0,                                  offsetof(Unit, description)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 259 "src/core/load-fragment-gperf.gperf"
      {"Service.RestrictRealtime",                    config_parse_bool,                                  0,                                  offsetof(Service, exec_context.restrict_realtime)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 123 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertCredential",                        config_parse_unit_condition_string,                 CONDITION_CREDENTIAL,               offsetof(Unit, asserts)},
      {(char*)0},
#line 603 "src/core/load-fragment-gperf.gperf"
      {"Socket.Personality",                         config_parse_personality,                           0,                                  offsetof(Socket, exec_context.personality)},
      {(char*)0},
#line 166 "src/core/load-fragment-gperf.gperf"
      {"Service.Restart",                              config_parse_service_restart,                       0,                                  offsetof(Service, restart)},
#line 258 "src/core/load-fragment-gperf.gperf"
      {"Service.RestrictNamespaces",                  config_parse_restrict_namespaces,                   0,                                  offsetof(Service, exec_context)},
#line 263 "src/core/load-fragment-gperf.gperf"
      {"Service.RestrictFileSystems",                 config_parse_restrict_filesystems,                  0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 261 "src/core/load-fragment-gperf.gperf"
      {"Service.RestrictAddressFamilies",             config_parse_address_families,                      0,                                  offsetof(Service, exec_context)},
#line 317 "src/core/load-fragment-gperf.gperf"
      {"Service.StateDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_STATE])},
#line 404 "src/core/load-fragment-gperf.gperf"
      {"Service.RestrictNetworkInterfaces",           config_parse_restrict_network_interfaces,           0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 163 "src/core/load-fragment-gperf.gperf"
      {"Service.RebootArgument",                       config_parse_unit_string_printf,                    0,                                  offsetof(Unit, reboot_arg)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 723 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootHashSignature",                   config_parse_exec_root_hash_sig,                    0,                                  offsetof(Mount, exec_context)},
#line 460 "src/core/load-fragment-gperf.gperf"
      {"Socket.PassSecurity",                          config_parse_bool,                                  0,                                  offsetof(Socket, pass_sec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 403 "src/core/load-fragment-gperf.gperf"
      {"Service.SocketBindDeny",                      config_parse_cgroup_socket_bind,                    0,                                  offsetof(Service, cgroup_context.socket_bind_deny)},
      {(char*)0},
#line 308 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectHome",                         config_parse_protect_home,                          0,                                  offsetof(Service, exec_context.protect_home)},
#line 719 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootImage",                           config_parse_unit_path_printf,                      true,                               offsetof(Mount, exec_context.root_image)},
      {(char*)0}, {(char*)0},
#line 337 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectHostname",                     config_parse_bool,                                  0,                                  offsetof(Service, exec_context.protect_hostname)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 253 "src/core/load-fragment-gperf.gperf"
      {"Service.SystemCallFilter",                    config_parse_syscall_filter,                        0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 255 "src/core/load-fragment-gperf.gperf"
      {"Service.SystemCallErrorNumber",               config_parse_syscall_errno,                         0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0},
#line 780 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectProc",                         config_parse_protect_proc,                          0,                                  offsetof(Mount, exec_context.protect_proc)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 254 "src/core/load-fragment-gperf.gperf"
      {"Service.SystemCallArchitectures",             config_parse_syscall_archs,                         0,                                  offsetof(Service, exec_context.syscall_archs)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 574 "src/core/load-fragment-gperf.gperf"
      {"Socket.ReadWritePaths",                      config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.read_write_paths)},
      {(char*)0}, {(char*)0},
#line 235 "src/core/load-fragment-gperf.gperf"
      {"Service.SyslogIdentifier",                    config_parse_unit_string_printf,                    0,                                  offsetof(Service, exec_context.syslog_identifier)},
      {(char*)0}, {(char*)0},
#line 571 "src/core/load-fragment-gperf.gperf"
      {"Socket.ReadWriteDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.read_write_paths)},
      {(char*)0},
#line 367 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryLimit",                         config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 91 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionCredential",                     config_parse_unit_condition_string,                 CONDITION_CREDENTIAL,               offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 257 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryDenyWriteExecute",              config_parse_bool,                                  0,                                  offsetof(Service, exec_context.memory_deny_write_execute)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 845 "src/core/load-fragment-gperf.gperf"
      {"Mount.StateDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_STATE].mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 113 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertDirectoryNotEmpty",                 config_parse_unit_condition_path,                   CONDITION_DIRECTORY_NOT_EMPTY,      offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 352 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryMin",                           config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1201 "src/core/load-fragment-gperf.gperf"
      {"Path.DirectoryNotEmpty",                       config_parse_path_spec,                             0,                                  0},
      {(char*)0},
#line 587 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectKernelLogs",                   config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.protect_kernel_logs)},
      {(char*)0}, {(char*)0},
#line 586 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectKernelModules",                config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.protect_kernel_modules)},
#line 585 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectKernelTunables",               config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.protect_kernel_tunables)},
      {(char*)0},
#line 812 "src/core/load-fragment-gperf.gperf"
      {"Mount.ReadWritePaths",                      config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.read_write_paths)},
      {(char*)0}, {(char*)0},
#line 599 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectHome",                         config_parse_protect_home,                          0,                                  offsetof(Socket, exec_context.protect_home)},
#line 470 "src/core/load-fragment-gperf.gperf"
      {"Socket.Service",                               config_parse_socket_service,                        0,                                  0},
      {(char*)0}, {(char*)0},
#line 628 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectHostname",                     config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.protect_hostname)},
      {(char*)0},
#line 251 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectProc",                         config_parse_protect_proc,                          0,                                  offsetof(Service, exec_context.protect_proc)},
      {(char*)0}, {(char*)0},
#line 536 "src/core/load-fragment-gperf.gperf"
      {"Socket.SecureBits",                          config_parse_exec_secure_bits,                      0,                                  offsetof(Socket, exec_context.secure_bits)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 172 "src/core/load-fragment-gperf.gperf"
      {"Service.RestartPreventExitStatus",             config_parse_set_status,                            0,                                  offsetof(Service, restart_prevent_status)},
#line 339 "src/core/load-fragment-gperf.gperf"
      {"Service.Slice",                               config_parse_unit_slice,                            0,                                  0},
      {(char*)0}, {(char*)0},
#line 474 "src/core/load-fragment-gperf.gperf"
      {"Socket.PollLimitBurst",                        config_parse_unsigned,                              0,                                  offsetof(Socket, poll_limit.burst)},
      {(char*)0}, {(char*)0},
#line 967 "src/core/load-fragment-gperf.gperf"
      {"Swap.User",                                config_parse_user_group_compat,                     0,                                  offsetof(Swap, exec_context.user)},
      {(char*)0}, {(char*)0},
#line 589 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectControlGroups",                config_parse_protect_control_groups,                0,                                  offsetof(Socket, exec_context.protect_control_groups)},
#line 309 "src/core/load-fragment-gperf.gperf"
      {"Service.MountFlags",                          config_parse_exec_mount_propagation_flag,           0,                                  offsetof(Service, exec_context.mount_propagation_flag)},
#line 200 "src/core/load-fragment-gperf.gperf"
      {"Service.MountImages",                         config_parse_mount_images,                          0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0},
#line 837 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectHome",                         config_parse_protect_home,                          0,                                  offsetof(Mount, exec_context.protect_home)},
      {(char*)0}, {(char*)0},
#line 134 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertOSRelease",                         config_parse_unit_condition_string,                 CONDITION_OS_RELEASE,               offsetof(Unit, asserts)},
#line 324 "src/core/load-fragment-gperf.gperf"
      {"Service.SetCredential",                       config_parse_set_credential,                        0,                                  offsetof(Service, exec_context)},
#line 433 "src/core/load-fragment-gperf.gperf"
      {"Socket.SocketUser",                            config_parse_user_group_compat,                     0,                                  offsetof(Socket, user)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 630 "src/core/load-fragment-gperf.gperf"
      {"Socket.Slice",                               config_parse_unit_slice,                            0,                                  0},
#line 1081 "src/core/load-fragment-gperf.gperf"
      {"Swap.StateDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_STATE].mode)},
#line 836 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectSystem",                       config_parse_protect_system,                        0,                                  offsetof(Mount, exec_context.protect_system)},
#line 1169 "src/core/load-fragment-gperf.gperf"
      {"Swap.RestrictNetworkInterfaces",           config_parse_restrict_network_interfaces,           0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0},
#line 435 "src/core/load-fragment-gperf.gperf"
      {"Socket.SocketMode",                            config_parse_mode,                                  0,                                  offsetof(Socket, socket_mode)},
#line 195 "src/core/load-fragment-gperf.gperf"
      {"Service.RootVerity",                          config_parse_unit_path_printf,                      true,                               offsetof(Service, exec_context.root_verity)},
#line 718 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootDirectory",                       config_parse_unit_path_printf,                      true,                               offsetof(Mount, exec_context.root_directory)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1024 "src/core/load-fragment-gperf.gperf"
      {"Swap.RestrictRealtime",                    config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.restrict_realtime)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 575 "src/core/load-fragment-gperf.gperf"
      {"Socket.ReadOnlyPaths",                       config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.read_only_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 148 "src/core/load-fragment-gperf.gperf"
      {"Service.RestartSteps",                         config_parse_unsigned,                              0,                                  offsetof(Service, restart_steps)},
      {(char*)0}, {(char*)0},
#line 1026 "src/core/load-fragment-gperf.gperf"
      {"Swap.RestrictAddressFamilies",             config_parse_address_families,                      0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 615 "src/core/load-fragment-gperf.gperf"
      {"Socket.SetCredential",                       config_parse_set_credential,                        0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 788 "src/core/load-fragment-gperf.gperf"
      {"Mount.RestrictRealtime",                    config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.restrict_realtime)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 160 "src/core/load-fragment-gperf.gperf"
      {"Service.StartLimitBurst",                      config_parse_unsigned,                              0,                                  offsetof(Unit, start_ratelimit.burst)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 486 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootVerity",                          config_parse_unit_path_printf,                      true,                               offsetof(Socket, exec_context.root_verity)},
      {(char*)0}, {(char*)0},
#line 792 "src/core/load-fragment-gperf.gperf"
      {"Mount.RestrictFileSystems",                 config_parse_restrict_filesystems,                  0,                                  offsetof(Mount, exec_context)},
#line 304 "src/core/load-fragment-gperf.gperf"
      {"Service.PrivateMounts",                       config_parse_tristate,                              0,                                  offsetof(Service, exec_context.private_mounts)},
#line 236 "src/core/load-fragment-gperf.gperf"
      {"Service.SyslogFacility",                      config_parse_log_facility,                          0,                                  offsetof(Service, exec_context.syslog_priority)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 933 "src/core/load-fragment-gperf.gperf"
      {"Mount.RestrictNetworkInterfaces",           config_parse_restrict_network_interfaces,           0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 990 "src/core/load-fragment-gperf.gperf"
      {"Swap.StandardOutput",                      config_parse_exec_output,                           0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 161 "src/core/load-fragment-gperf.gperf"
      {"Service.StartLimitAction",                     config_parse_emergency_action,                      0,                                  offsetof(Unit, start_limit_action)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 846 "src/core/load-fragment-gperf.gperf"
      {"Mount.StateDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_STATE])},
      {(char*)0}, {(char*)0},
#line 991 "src/core/load-fragment-gperf.gperf"
      {"Swap.StandardError",                       config_parse_exec_output,                           0,                                  offsetof(Swap, exec_context)},
#line 790 "src/core/load-fragment-gperf.gperf"
      {"Mount.RestrictAddressFamilies",             config_parse_address_families,                      0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 787 "src/core/load-fragment-gperf.gperf"
      {"Mount.RestrictNamespaces",                  config_parse_restrict_namespaces,                   0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 312 "src/core/load-fragment-gperf.gperf"
      {"Service.Personality",                         config_parse_personality,                           0,                                  offsetof(Service, exec_context.personality)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 485 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootHashSignature",                   config_parse_exec_root_hash_sig,                    0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1195 "src/core/load-fragment-gperf.gperf"
      {"Timer.RandomizedDelaySec",                     config_parse_sec,                                   0,                                  offsetof(Timer, random_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 201 "src/core/load-fragment-gperf.gperf"
      {"Service.MountImagePolicy",                    config_parse_image_policy,                          0,                                  offsetof(Service, exec_context.mount_image_policy)},
      {(char*)0},
#line 721 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootImagePolicy",                     config_parse_image_policy,                          0,                                  offsetof(Mount, exec_context.root_image_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 187 "src/core/load-fragment-gperf.gperf"
      {"Service.ReloadSignal",                         config_parse_signal,                                0,                                  offsetof(Service, reload_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 307 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectSystem",                       config_parse_protect_system,                        0,                                  offsetof(Service, exec_context.protect_system)},
      {(char*)0},
#line 550 "src/core/load-fragment-gperf.gperf"
      {"Socket.RestrictRealtime",                    config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.restrict_realtime)},
#line 1082 "src/core/load-fragment-gperf.gperf"
      {"Swap.StateDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_STATE])},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 810 "src/core/load-fragment-gperf.gperf"
      {"Mount.ReadOnlyDirectories",                 config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.read_only_paths)},
#line 724 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootVerity",                          config_parse_unit_path_printf,                      true,                               offsetof(Mount, exec_context.root_verity)},
      {(char*)0}, {(char*)0},
#line 237 "src/core/load-fragment-gperf.gperf"
      {"Service.SyslogLevel",                         config_parse_log_level,                             0,                                  offsetof(Service, exec_context.syslog_priority)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 704 "src/core/load-fragment-gperf.gperf"
      {"Socket.RestartKillSignal",                   config_parse_signal,                                0,                                  offsetof(Socket, kill_context.restart_kill_signal)},
#line 175 "src/core/load-fragment-gperf.gperf"
      {"Service.SysVStartPriority",                    config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
#line 694 "src/core/load-fragment-gperf.gperf"
      {"Socket.SocketBindDeny",                      config_parse_cgroup_socket_bind,                    0,                                  offsetof(Socket, cgroup_context.socket_bind_deny)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 960 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootVerity",                          config_parse_unit_path_printf,                      true,                               offsetof(Swap, exec_context.root_verity)},
      {(char*)0}, {(char*)0},
#line 542 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectProc",                         config_parse_protect_proc,                          0,                                  offsetof(Socket, exec_context.protect_proc)},
#line 405 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryPressureThresholdSec",          config_parse_sec,                                   0,                                  offsetof(Service, cgroup_context.memory_pressure_threshold_usec)},
      {(char*)0},
#line 868 "src/core/load-fragment-gperf.gperf"
      {"Mount.Slice",                               config_parse_unit_slice,                            0,                                  0},
      {(char*)0},
#line 410 "src/core/load-fragment-gperf.gperf"
      {"Service.SendSIGHUP",                          config_parse_bool,                                  0,                                  offsetof(Service, kill_context.send_sighup)},
#line 971 "src/core/load-fragment-gperf.gperf"
      {"Swap.Nice",                                config_parse_exec_nice,                             0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 813 "src/core/load-fragment-gperf.gperf"
      {"Mount.ReadOnlyPaths",                       config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.read_only_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 38 "src/core/load-fragment-gperf.gperf"
      {"Unit.PropagateReloadTo",                       config_parse_unit_deps,                             UNIT_PROPAGATES_RELOAD_TO,          0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 402 "src/core/load-fragment-gperf.gperf"
      {"Service.SocketBindAllow",                     config_parse_cgroup_socket_bind,                    0,                                  offsetof(Service, cgroup_context.socket_bind_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 100 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionGroup",                          config_parse_unit_condition_string,                 CONDITION_GROUP,                    offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0},
#line 473 "src/core/load-fragment-gperf.gperf"
      {"Socket.PollLimitIntervalSec",                  config_parse_sec,                                   0,                                  offsetof(Socket, poll_limit.interval)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 167 "src/core/load-fragment-gperf.gperf"
      {"Service.RestartMode",                          config_parse_service_restart_mode,                  0,                                  offsetof(Service, restart_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1073 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectHome",                         config_parse_protect_home,                          0,                                  offsetof(Swap, exec_context.protect_home)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1102 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectHostname",                     config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.protect_hostname)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 454 "src/core/load-fragment-gperf.gperf"
      {"Socket.PipeSize",                              config_parse_iec_size,                              0,                                  offsetof(Socket, pipe_size)},
      {(char*)0}, {(char*)0},
#line 147 "src/core/load-fragment-gperf.gperf"
      {"Service.RestartSec",                           config_parse_sec,                                   0,                                  offsetof(Service, restart_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 481 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootImage",                           config_parse_unit_path_printf,                      true,                               offsetof(Socket, exec_context.root_image)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 39 "src/core/load-fragment-gperf.gperf"
      {"Unit.ReloadPropagatedFrom",                    config_parse_unit_deps,                             UNIT_RELOAD_PROPAGATED_FROM,        0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 468 "src/core/load-fragment-gperf.gperf"
      {"Socket.Symlinks",                              config_parse_unit_path_strv_printf,                 0,                                  offsetof(Socket, symlinks)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1342 "src/core/load-fragment-gperf.gperf"
      {"Scope.RestrictNetworkInterfaces",           config_parse_restrict_network_interfaces,           0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 482 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootImageOptions",                    config_parse_root_image_options,                    0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1028 "src/core/load-fragment-gperf.gperf"
      {"Swap.RestrictFileSystems",                 config_parse_restrict_filesystems,                  0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 480 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootDirectory",                       config_parse_unit_path_printf,                      true,                               offsetof(Socket, exec_context.root_directory)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 950 "src/core/load-fragment-gperf.gperf"
      {"Swap.Priority",                                config_parse_swap_priority,                         0,                                  0},
      {(char*)0}, {(char*)0},
#line 424 "src/core/load-fragment-gperf.gperf"
      {"Socket.SocketProtocol",                        config_parse_socket_protocol,                       0,                                  offsetof(Socket, socket_protocol)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 74 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionPathExistsGlob",                 config_parse_unit_condition_path,                   CONDITION_PATH_EXISTS_GLOB,         offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0},
#line 1360 "src/core/load-fragment-gperf.gperf"
      {"Install.RequiredBy",                           NULL,                                               0,                                  0},
      {(char*)0},
#line 58 "src/core/load-fragment-gperf.gperf"
      {"Unit.IgnoreOnIsolate",                         config_parse_bool,                                  0,                                  offsetof(Unit, ignore_on_isolate)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 59 "src/core/load-fragment-gperf.gperf"
      {"Unit.IgnoreOnSnapshot",                        config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1272 "src/core/load-fragment-gperf.gperf"
      {"Slice.RestrictNetworkInterfaces",           config_parse_restrict_network_interfaces,           0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 910 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupBlockIOWeight",                config_parse_blockio_weight,                        0,                                  offsetof(Mount, cgroup_context.startup_blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 159 "src/core/load-fragment-gperf.gperf"
      {"Service.StartLimitInterval",                   config_parse_sec,                                   0,                                  offsetof(Unit, start_ratelimit.interval)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1132 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryLimit",                         config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1023 "src/core/load-fragment-gperf.gperf"
      {"Swap.RestrictNamespaces",                  config_parse_restrict_namespaces,                   0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0},
#line 41 "src/core/load-fragment-gperf.gperf"
      {"Unit.PropagatesStopTo",                        config_parse_unit_deps,                             UNIT_PROPAGATES_STOP_TO,            0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 939 "src/core/load-fragment-gperf.gperf"
      {"Mount.SendSIGHUP",                          config_parse_bool,                                  0,                                  offsetof(Mount, kill_context.send_sighup)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1117 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryMin",                           config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 928 "src/core/load-fragment-gperf.gperf"
      {"Mount.ManagedOOMPreference",                config_parse_managed_oom_preference,                0,                                  offsetof(Mount, cgroup_context.moom_preference)},
      {(char*)0},
#line 125 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertCapability",                        config_parse_unit_condition_string,                 CONDITION_CAPABILITY,               offsetof(Unit, asserts)},
      {(char*)0},
#line 925 "src/core/load-fragment-gperf.gperf"
      {"Mount.ManagedOOMMemoryPressure",            config_parse_managed_oom_mode,                      0,                                  offsetof(Mount, cgroup_context.moom_mem_pressure)},
#line 1277 "src/core/load-fragment-gperf.gperf"
      {"Scope.Slice",                               config_parse_unit_slice,                            0,                                  0},
      {(char*)0},
#line 942 "src/core/load-fragment-gperf.gperf"
      {"Mount.RestartKillSignal",                   config_parse_signal,                                0,                                  offsetof(Mount, kill_context.restart_kill_signal)},
      {(char*)0},
#line 926 "src/core/load-fragment-gperf.gperf"
      {"Mount.ManagedOOMMemoryPressureLimit",       config_parse_managed_oom_mem_pressure_limit,        0,                                  offsetof(Mount, cgroup_context.moom_mem_pressure_limit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1017 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProcSubset",                          config_parse_proc_subset,                           0,                                  offsetof(Swap, exec_context.proc_subset)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 918 "src/core/load-fragment-gperf.gperf"
      {"Mount.DisableControllers",                  config_parse_disable_controllers,                   0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 483 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootImagePolicy",                     config_parse_image_policy,                          0,                                  offsetof(Socket, exec_context.root_image_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 356 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryLow",                           config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 598 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectSystem",                       config_parse_protect_system,                        0,                                  offsetof(Socket, exec_context.protect_system)},
#line 1207 "src/core/load-fragment-gperf.gperf"
      {"Slice.Slice",                               config_parse_unit_slice,                            0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 338 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryKSM",                           config_parse_tristate,                              0,                                  offsetof(Service, exec_context.memory_ksm)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1036 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitAS",                             config_parse_rlimit,                                RLIMIT_AS,                          offsetof(Swap, exec_context.rlimit)},
      {(char*)0},
#line 27 "src/core/load-fragment-gperf.gperf"
      {"Unit.Requisite",                               config_parse_unit_deps,                             UNIT_REQUISITE,                     0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 149 "src/core/load-fragment-gperf.gperf"
      {"Service.RestartMaxDelaySec",                   config_parse_sec,                                   0,                                  offsetof(Service, restart_max_delay_usec)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1104 "src/core/load-fragment-gperf.gperf"
      {"Swap.Slice",                               config_parse_unit_slice,                            0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1000 "src/core/load-fragment-gperf.gperf"
      {"Swap.SyslogIdentifier",                    config_parse_unit_string_printf,                    0,                                  offsetof(Swap, exec_context.syslog_identifier)},
      {(char*)0}, {(char*)0},
#line 548 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryDenyWriteExecute",              config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.memory_deny_write_execute)},
      {(char*)0},
#line 138 "src/core/load-fragment-gperf.gperf"
      {"Unit.CollectMode",                             config_parse_collect_mode,                          0,                                  offsetof(Unit, collect_mode)},
      {(char*)0},
#line 37 "src/core/load-fragment-gperf.gperf"
      {"Unit.PropagatesReloadTo",                      config_parse_unit_deps,                             UNIT_PROPAGATES_RELOAD_TO,          0},
#line 45 "src/core/load-fragment-gperf.gperf"
      {"Unit.RequiresOverridable",                     config_parse_obsolete_unit_deps,                    UNIT_REQUIRES,                      0},
      {(char*)0},
#line 1015 "src/core/load-fragment-gperf.gperf"
      {"Swap.KeyringMode",                         config_parse_exec_keyring_mode,                     0,                                  offsetof(Swap, exec_context.keyring_mode)},
#line 293 "src/core/load-fragment-gperf.gperf"
      {"Service.PrivateDevices",                      config_parse_bool,                                  0,                                  offsetof(Service, exec_context.private_devices)},
#line 26 "src/core/load-fragment-gperf.gperf"
      {"Unit.Requires",                                config_parse_unit_deps,                             UNIT_REQUIRES,                      0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1175 "src/core/load-fragment-gperf.gperf"
      {"Swap.SendSIGHUP",                          config_parse_bool,                                  0,                                  offsetof(Swap, kill_context.send_sighup)},
#line 643 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryMin",                           config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
#line 693 "src/core/load-fragment-gperf.gperf"
      {"Socket.SocketBindAllow",                     config_parse_cgroup_socket_bind,                    0,                                  offsetof(Socket, cgroup_context.socket_bind_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1072 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectSystem",                       config_parse_protect_system,                        0,                                  offsetof(Swap, exec_context.protect_system)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 781 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProcSubset",                          config_parse_proc_subset,                           0,                                  offsetof(Mount, exec_context.proc_subset)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 40 "src/core/load-fragment-gperf.gperf"
      {"Unit.PropagateReloadFrom",                     config_parse_unit_deps,                             UNIT_RELOAD_PROPAGATED_FROM,        0},
#line 436 "src/core/load-fragment-gperf.gperf"
      {"Socket.DirectoryMode",                         config_parse_mode,                                  0,                                  offsetof(Socket, directory_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1319 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupBlockIOWeight",                config_parse_blockio_weight,                        0,                                  offsetof(Scope, cgroup_context.startup_blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 119 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertVirtualization",                    config_parse_unit_condition_string,                 CONDITION_VIRTUALIZATION,           offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 544 "src/core/load-fragment-gperf.gperf"
      {"Socket.SystemCallFilter",                    config_parse_syscall_filter,                        0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 546 "src/core/load-fragment-gperf.gperf"
      {"Socket.SystemCallErrorNumber",               config_parse_syscall_errno,                         0,                                  offsetof(Socket, exec_context)},
#line 357 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 545 "src/core/load-fragment-gperf.gperf"
      {"Socket.SystemCallArchitectures",             config_parse_syscall_archs,                         0,                                  offsetof(Socket, exec_context.syscall_archs)},
#line 1016 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectProc",                         config_parse_protect_proc,                          0,                                  offsetof(Swap, exec_context.protect_proc)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 607 "src/core/load-fragment-gperf.gperf"
      {"Socket.StateDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_STATE].mode)},
#line 256 "src/core/load-fragment-gperf.gperf"
      {"Service.SystemCallLog",                       config_parse_syscall_log,                           0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 513 "src/core/load-fragment-gperf.gperf"
      {"Socket.DynamicUser",                         config_parse_bool,                                  true,                               offsetof(Socket, exec_context.dynamic_user)},
#line 48 "src/core/load-fragment-gperf.gperf"
      {"Unit.WantsMountsFor",                          config_parse_unit_mounts_for,                       0,                                  0},
      {(char*)0},
#line 1348 "src/core/load-fragment-gperf.gperf"
      {"Scope.SendSIGHUP",                          config_parse_bool,                                  0,                                  offsetof(Scope, kill_context.send_sighup)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 72 "src/core/load-fragment-gperf.gperf"
      {"Unit.RebootArgument",                          config_parse_reboot_parameter,                      0,                                  offsetof(Unit, reboot_arg)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 951 "src/core/load-fragment-gperf.gperf"
      {"Swap.Options",                                 config_parse_unit_string_printf,                    0,                                  offsetof(Swap, parameters_fragment.options)},
#line 526 "src/core/load-fragment-gperf.gperf"
      {"Socket.SyslogIdentifier",                    config_parse_unit_string_printf,                    0,                                  offsetof(Socket, exec_context.syslog_identifier)},
      {(char*)0}, {(char*)0},
#line 1337 "src/core/load-fragment-gperf.gperf"
      {"Scope.ManagedOOMPreference",                config_parse_managed_oom_preference,                0,                                  offsetof(Scope, cgroup_context.moom_preference)},
      {(char*)0},
#line 865 "src/core/load-fragment-gperf.gperf"
      {"Mount.SmackProcessLabel",                   config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
#line 916 "src/core/load-fragment-gperf.gperf"
      {"Mount.Delegate",                            config_parse_delegate,                              0,                                  offsetof(Mount, cgroup_context)},
#line 1334 "src/core/load-fragment-gperf.gperf"
      {"Scope.ManagedOOMMemoryPressure",            config_parse_managed_oom_mode,                      0,                                  offsetof(Scope, cgroup_context.moom_mem_pressure)},
#line 1249 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupBlockIOWeight",                config_parse_blockio_weight,                        0,                                  offsetof(Slice, cgroup_context.startup_blockio_weight)},
      {(char*)0},
#line 1351 "src/core/load-fragment-gperf.gperf"
      {"Scope.RestartKillSignal",                   config_parse_signal,                                0,                                  offsetof(Scope, kill_context.restart_kill_signal)},
      {(char*)0},
#line 1335 "src/core/load-fragment-gperf.gperf"
      {"Scope.ManagedOOMMemoryPressureLimit",       config_parse_managed_oom_mem_pressure_limit,        0,                                  offsetof(Scope, cgroup_context.moom_mem_pressure_limit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1077 "src/core/load-fragment-gperf.gperf"
      {"Swap.Personality",                         config_parse_personality,                           0,                                  offsetof(Swap, exec_context.personality)},
      {(char*)0},
#line 434 "src/core/load-fragment-gperf.gperf"
      {"Socket.SocketGroup",                           config_parse_user_group_compat,                     0,                                  offsetof(Socket, group)},
#line 870 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupAllowedCPUs",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Mount, cgroup_context.startup_cpuset_cpus)},
      {(char*)0}, {(char*)0},
#line 583 "src/core/load-fragment-gperf.gperf"
      {"Socket.PrivateTmp",                          config_parse_private_tmp,                           0,                                  offsetof(Socket, exec_context.private_tmp)},
      {(char*)0},
#line 1327 "src/core/load-fragment-gperf.gperf"
      {"Scope.DisableControllers",                  config_parse_disable_controllers,                   0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0},
#line 872 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupAllowedMemoryNodes",           config_parse_allowed_cpuset,                        0,                                  offsetof(Mount, cgroup_context.startup_cpuset_mems)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 934 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryPressureThresholdSec",          config_parse_sec,                                   0,                                  offsetof(Mount, cgroup_context.memory_pressure_threshold_usec)},
#line 1034 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitRSS",                            config_parse_rlimit,                                RLIMIT_RSS,                         offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0},
#line 1170 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryPressureThresholdSec",          config_parse_sec,                                   0,                                  offsetof(Swap, cgroup_context.memory_pressure_threshold_usec)},
#line 52 "src/core/load-fragment-gperf.gperf"
      {"Unit.AllowIsolate",                            config_parse_bool,                                  0,                                  offsetof(Unit, allow_isolate)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1055 "src/core/load-fragment-gperf.gperf"
      {"Swap.BindReadOnlyPaths",                   config_parse_bind_paths,                            0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 927 "src/core/load-fragment-gperf.gperf"
      {"Mount.ManagedOOMMemoryPressureDurationSec", config_parse_managed_oom_mem_pressure_duration_sec, 0,                                  offsetof(Mount, cgroup_context.moom_mem_pressure_duration_usec)},
      {(char*)0}, {(char*)0},
#line 260 "src/core/load-fragment-gperf.gperf"
      {"Service.RestrictSUIDSGID",                    config_parse_bool,                                  0,                                  offsetof(Service, exec_context.restrict_suid_sgid)},
      {(char*)0},
#line 318 "src/core/load-fragment-gperf.gperf"
      {"Service.CacheDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_CACHE].mode)},
      {(char*)0}, {(char*)0},
#line 322 "src/core/load-fragment-gperf.gperf"
      {"Service.ConfigurationDirectoryMode",          config_parse_mode,                                  0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION].mode)},
      {(char*)0},
#line 1267 "src/core/load-fragment-gperf.gperf"
      {"Slice.ManagedOOMPreference",                config_parse_managed_oom_preference,                0,                                  offsetof(Slice, cgroup_context.moom_preference)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1264 "src/core/load-fragment-gperf.gperf"
      {"Slice.ManagedOOMMemoryPressure",            config_parse_managed_oom_mode,                      0,                                  offsetof(Slice, cgroup_context.moom_mem_pressure)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1265 "src/core/load-fragment-gperf.gperf"
      {"Slice.ManagedOOMMemoryPressureLimit",       config_parse_managed_oom_mem_pressure_limit,        0,                                  offsetof(Slice, cgroup_context.moom_mem_pressure_limit)},
      {(char*)0},
#line 494 "src/core/load-fragment-gperf.gperf"
      {"Socket.Group",                               config_parse_user_group_compat,                     0,                                  offsetof(Socket, exec_context.group)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 543 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProcSubset",                          config_parse_proc_subset,                           0,                                  offsetof(Socket, exec_context.proc_subset)},
#line 989 "src/core/load-fragment-gperf.gperf"
      {"Swap.StandardInput",                       config_parse_exec_input,                            0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 881 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryMin",                           config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0},
#line 992 "src/core/load-fragment-gperf.gperf"
      {"Swap.StandardInputText",                   config_parse_exec_input_text,                       0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 1257 "src/core/load-fragment-gperf.gperf"
      {"Slice.DisableControllers",                  config_parse_disable_controllers,                   0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 809 "src/core/load-fragment-gperf.gperf"
      {"Mount.ReadWriteDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.read_write_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 94 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionACPower",                        config_parse_unit_condition_string,                 CONDITION_AC_POWER,                 offsetof(Unit, conditions)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 678 "src/core/load-fragment-gperf.gperf"
      {"Socket.Delegate",                            config_parse_delegate,                              0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 696 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryPressureThresholdSec",          config_parse_sec,                                   0,                                  offsetof(Socket, cgroup_context.memory_pressure_threshold_usec)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 993 "src/core/load-fragment-gperf.gperf"
      {"Swap.StandardInputData",                   config_parse_exec_input_data,                       0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0},
#line 754 "src/core/load-fragment-gperf.gperf"
      {"Mount.StandardOutput",                      config_parse_exec_output,                           0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 206 "src/core/load-fragment-gperf.gperf"
      {"Service.Nice",                                config_parse_exec_nice,                             0,                                  offsetof(Service, exec_context)},
      {(char*)0},
#line 608 "src/core/load-fragment-gperf.gperf"
      {"Socket.StateDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_STATE])},
      {(char*)0},
#line 298 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectControlGroups",                config_parse_protect_control_groups,                0,                                  offsetof(Service, exec_context.protect_control_groups)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 712 "src/core/load-fragment-gperf.gperf"
      {"Mount.DirectoryMode",                          config_parse_mode,                                  0,                                  offsetof(Mount, directory_mode)},
#line 680 "src/core/load-fragment-gperf.gperf"
      {"Socket.DisableControllers",                  config_parse_disable_controllers,                   0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0},
#line 450 "src/core/load-fragment-gperf.gperf"
      {"Socket.SendBuffer",                            config_parse_iec_size,                              0,                                  offsetof(Socket, send_buffer)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 952 "src/core/load-fragment-gperf.gperf"
      {"Swap.TimeoutSec",                              config_parse_sec_fix_0,                             0,                                  offsetof(Swap, timeout_usec)},
#line 132 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertGroup",                             config_parse_unit_condition_string,                 CONDITION_GROUP,                    offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 627 "src/core/load-fragment-gperf.gperf"
      {"Socket.SmackProcessLabel",                   config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0},
#line 572 "src/core/load-fragment-gperf.gperf"
      {"Socket.ReadOnlyDirectories",                 config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.read_only_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 346 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupCPUWeight",                    config_parse_cg_cpu_weight,                         0,                                  offsetof(Service, cgroup_context.startup_cpu_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 369 "src/core/load-fragment-gperf.gperf"
      {"Service.DevicePolicy",                        config_parse_device_policy,                         0,                                  offsetof(Service, cgroup_context.device_policy)},
      {(char*)0},
#line 459 "src/core/load-fragment-gperf.gperf"
      {"Socket.PassFileDescriptorsToExec",             config_parse_bool,                                  0,                                  offsetof(Socket, pass_fds_to_exec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 348 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupCPUShares",                    config_parse_cpu_shares,                            0,                                  offsetof(Service, cgroup_context.startup_cpu_shares)},
      {(char*)0}, {(char*)0},
#line 751 "src/core/load-fragment-gperf.gperf"
      {"Mount.DynamicUser",                         config_parse_bool,                                  true,                               offsetof(Mount, exec_context.dynamic_user)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 854 "src/core/load-fragment-gperf.gperf"
      {"Mount.SetCredentialEncrypted",              config_parse_set_credential,                        1,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 722 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootHash",                            config_parse_exec_root_hash,                        0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0},
#line 319 "src/core/load-fragment-gperf.gperf"
      {"Service.CacheDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_CACHE])},
      {(char*)0}, {(char*)0},
#line 323 "src/core/load-fragment-gperf.gperf"
      {"Service.ConfigurationDirectory",              config_parse_exec_directories,                      0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION])},
      {(char*)0},
#line 691 "src/core/load-fragment-gperf.gperf"
      {"Socket.NetClass",                            config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 287 "src/core/load-fragment-gperf.gperf"
      {"Service.NoExecPaths",                         config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.no_exec_paths)},
      {(char*)0},
#line 658 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryLimit",                         config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
#line 1325 "src/core/load-fragment-gperf.gperf"
      {"Scope.Delegate",                            config_parse_delegate,                              0,                                  offsetof(Scope, cgroup_context)},
#line 243 "src/core/load-fragment-gperf.gperf"
      {"Service.LogFilterPatterns",                   config_parse_log_filter_patterns,                   0,                                  offsetof(Service, exec_context)},
#line 843 "src/core/load-fragment-gperf.gperf"
      {"Mount.RuntimeDirectoryMode",                config_parse_mode,                                  0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_RUNTIME].mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 842 "src/core/load-fragment-gperf.gperf"
      {"Mount.RuntimeDirectoryPreserve",            config_parse_exec_preserve_mode,                    0,                                  offsetof(Mount, exec_context.runtime_directory_preserve_mode)},
#line 189 "src/core/load-fragment-gperf.gperf"
      {"Service.RootDirectory",                       config_parse_unit_path_printf,                      true,                               offsetof(Service, exec_context.root_directory)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 596 "src/core/load-fragment-gperf.gperf"
      {"Socket.PrivateIPC",                          config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.private_ipc)},
      {(char*)0},
#line 1279 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupAllowedCPUs",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Scope, cgroup_context.startup_cpuset_cpus)},
#line 169 "src/core/load-fragment-gperf.gperf"
      {"Service.RootDirectoryStartOnly",               config_parse_bool,                                  0,                                  offsetof(Service, root_directory_start_only)},
      {(char*)0},
#line 1050 "src/core/load-fragment-gperf.gperf"
      {"Swap.InaccessiblePaths",                   config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.inaccessible_paths)},
#line 637 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupCPUWeight",                    config_parse_cg_cpu_weight,                         0,                                  offsetof(Socket, cgroup_context.startup_cpu_weight)},
      {(char*)0}, {(char*)0},
#line 1281 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupAllowedMemoryNodes",           config_parse_allowed_cpuset,                        0,                                  offsetof(Scope, cgroup_context.startup_cpuset_mems)},
      {(char*)0},
#line 1047 "src/core/load-fragment-gperf.gperf"
      {"Swap.InaccessibleDirectories",             config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.inaccessible_paths)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1343 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryPressureThresholdSec",          config_parse_sec,                                   0,                                  offsetof(Scope, cgroup_context.memory_pressure_threshold_usec)},
#line 551 "src/core/load-fragment-gperf.gperf"
      {"Socket.RestrictSUIDSGID",                    config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.restrict_suid_sgid)},
      {(char*)0},
#line 301 "src/core/load-fragment-gperf.gperf"
      {"Service.LogNamespace",                        config_parse_log_namespace,                         0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0},
#line 639 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupCPUShares",                    config_parse_cpu_shares,                            0,                                  offsetof(Socket, cgroup_context.startup_cpu_shares)},
#line 418 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenSequentialPacket",                config_parse_socket_listen,                         SOCKET_SOCKET,                      0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1336 "src/core/load-fragment-gperf.gperf"
      {"Scope.ManagedOOMMemoryPressureDurationSec", config_parse_managed_oom_mem_pressure_duration_sec, 0,                                  offsetof(Scope, cgroup_context.moom_mem_pressure_duration_usec)},
      {(char*)0},
#line 358 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryHigh",                          config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
#line 351 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryAccounting",                    config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.memory_accounting)},
#line 422 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenMessageQueue",                    config_parse_socket_listen,                         SOCKET_MQUEUE,                      0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1173 "src/core/load-fragment-gperf.gperf"
      {"Swap.CoredumpReceive",                     config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.coredump_receive)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1255 "src/core/load-fragment-gperf.gperf"
      {"Slice.Delegate",                            config_parse_delegate,                              0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1121 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryLow",                           config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 406 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryPressureWatch",                 config_parse_memory_pressure_watch,                 0,                                  offsetof(Service, cgroup_context.memory_pressure_watch)},
      {(char*)0}, {(char*)0},
#line 484 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootHash",                            config_parse_exec_root_hash,                        0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 1200 "src/core/load-fragment-gperf.gperf"
      {"Path.PathModified",                            config_parse_path_spec,                             0,                                  0},
      {(char*)0},
#line 1209 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupAllowedCPUs",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Slice, cgroup_context.startup_cpuset_cpus)},
#line 1290 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryMin",                           config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 856 "src/core/load-fragment-gperf.gperf"
      {"Mount.LoadCredentialEncrypted",             config_parse_load_credential,                       1,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 1211 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupAllowedMemoryNodes",           config_parse_allowed_cpuset,                        0,                                  offsetof(Slice, cgroup_context.startup_cpuset_mems)},
      {(char*)0}, {(char*)0},
#line 1103 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryKSM",                           config_parse_tristate,                              0,                                  offsetof(Swap, exec_context.memory_ksm)},
      {(char*)0}, {(char*)0},
#line 1273 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryPressureThresholdSec",          config_parse_sec,                                   0,                                  offsetof(Slice, cgroup_context.memory_pressure_threshold_usec)},
      {(char*)0}, {(char*)0},
#line 114 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertFileNotEmpty",                      config_parse_unit_condition_path,                   CONDITION_FILE_NOT_EMPTY,           offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 618 "src/core/load-fragment-gperf.gperf"
      {"Socket.LoadCredentialEncrypted",             config_parse_load_credential,                       1,                                  offsetof(Socket, exec_context)},
#line 1122 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1179 "src/core/load-fragment-gperf.gperf"
      {"Swap.FinalKillSignal",                     config_parse_signal,                                0,                                  offsetof(Swap, kill_context.final_kill_signal)},
#line 1266 "src/core/load-fragment-gperf.gperf"
      {"Slice.ManagedOOMMemoryPressureDurationSec", config_parse_managed_oom_mem_pressure_duration_sec, 0,                                  offsetof(Slice, cgroup_context.moom_mem_pressure_duration_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 271 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitAS",                             config_parse_rlimit,                                RLIMIT_AS,                          offsetof(Service, exec_context.rlimit)},
#line 464 "src/core/load-fragment-gperf.gperf"
      {"Socket.ReusePort",                             config_parse_bool,                                  0,                                  offsetof(Socket, reuse_port)},
      {(char*)0},
#line 1176 "src/core/load-fragment-gperf.gperf"
      {"Swap.KillMode",                            config_parse_kill_mode,                             0,                                  offsetof(Swap, kill_context.kill_mode)},
#line 949 "src/core/load-fragment-gperf.gperf"
      {"Swap.What",                                    config_parse_mount_node,                            0,                                  offsetof(Swap, parameters_fragment.what)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 973 "src/core/load-fragment-gperf.gperf"
      {"Swap.CoredumpFilter",                      config_parse_exec_coredump_filter,                  0,                                  offsetof(Swap, exec_context)},
#line 734 "src/core/load-fragment-gperf.gperf"
      {"Mount.SetLoginEnvironment",                 config_parse_tristate,                              0,                                  offsetof(Mount, exec_context.set_login_environment)},
      {(char*)0},
#line 735 "src/core/load-fragment-gperf.gperf"
      {"Mount.Nice",                                config_parse_exec_nice,                             0,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 35 "src/core/load-fragment-gperf.gperf"
      {"Unit.OnSuccess",                               config_parse_unit_deps,                             UNIT_ON_SUCCESS,                    0},
      {(char*)0},
#line 137 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertIOPressure",                        config_parse_unit_condition_string,                 CONDITION_IO_PRESSURE,              offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 1001 "src/core/load-fragment-gperf.gperf"
      {"Swap.SyslogFacility",                      config_parse_log_facility,                          0,                                  offsetof(Swap, exec_context.syslog_priority)},
#line 1220 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryMin",                           config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 1152 "src/core/load-fragment-gperf.gperf"
      {"Swap.Delegate",                            config_parse_delegate,                              0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 55 "src/core/load-fragment-gperf.gperf"
      {"Unit.OnSuccessJobMode",                        config_parse_job_mode,                              0,                                  offsetof(Unit, on_success_job_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 844 "src/core/load-fragment-gperf.gperf"
      {"Mount.RuntimeDirectory",                    config_parse_exec_directories,                      0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_RUNTIME])},
      {(char*)0},
#line 467 "src/core/load-fragment-gperf.gperf"
      {"Socket.RemoveOnStop",                          config_parse_bool,                                  0,                                  offsetof(Socket, remove_on_stop)},
      {(char*)0},
#line 937 "src/core/load-fragment-gperf.gperf"
      {"Mount.CoredumpReceive",                     config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.coredump_receive)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 737 "src/core/load-fragment-gperf.gperf"
      {"Mount.CoredumpFilter",                      config_parse_exec_coredump_filter,                  0,                                  offsetof(Mount, exec_context)},
#line 527 "src/core/load-fragment-gperf.gperf"
      {"Socket.SyslogFacility",                      config_parse_log_facility,                          0,                                  offsetof(Socket, exec_context.syslog_priority)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 924 "src/core/load-fragment-gperf.gperf"
      {"Mount.ManagedOOMSwap",                      config_parse_managed_oom_mode,                      0,                                  offsetof(Mount, cgroup_context.moom_swap)},
      {(char*)0},
#line 204 "src/core/load-fragment-gperf.gperf"
      {"Service.SupplementaryGroups",                 config_parse_user_group_strv_compat,                0,                                  offsetof(Service, exec_context.supplementary_groups)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 76 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionPathIsSymbolicLink",             config_parse_unit_condition_path,                   CONDITION_PATH_IS_SYMBOLIC_LINK,    offsetof(Unit, conditions)},
#line 826 "src/core/load-fragment-gperf.gperf"
      {"Mount.ProtectClock",                        config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.protect_clock)},
#line 497 "src/core/load-fragment-gperf.gperf"
      {"Socket.Nice",                                config_parse_exec_nice,                             0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 593 "src/core/load-fragment-gperf.gperf"
      {"Socket.PrivateNetwork",                      config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.private_network)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 105 "src/core/load-fragment-gperf.gperf"
      {"Unit.ConditionIOPressure",                     config_parse_unit_condition_string,                 CONDITION_IO_PRESSURE,              offsetof(Unit, conditions)},
#line 359 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupMemoryHigh",                   config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 954 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootDirectory",                       config_parse_unit_path_printf,                      true,                               offsetof(Swap, exec_context.root_directory)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1177 "src/core/load-fragment-gperf.gperf"
      {"Swap.KillSignal",                          config_parse_signal,                                0,                                  offsetof(Swap, kill_context.kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 387 "src/core/load-fragment-gperf.gperf"
      {"Service.Delegate",                            config_parse_delegate,                              0,                                  offsetof(Service, cgroup_context)},
#line 672 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupBlockIOWeight",                config_parse_blockio_weight,                        0,                                  offsetof(Socket, cgroup_context.startup_blockio_weight)},
      {(char*)0},
#line 1196 "src/core/load-fragment-gperf.gperf"
      {"Timer.Unit",                                   config_parse_trigger_unit,                          0,                                  0},
#line 194 "src/core/load-fragment-gperf.gperf"
      {"Service.RootHashSignature",                   config_parse_exec_root_hash_sig,                    0,                                  offsetof(Service, exec_context)},
#line 1002 "src/core/load-fragment-gperf.gperf"
      {"Swap.SyslogLevel",                         config_parse_log_level,                             0,                                  offsetof(Swap, exec_context.syslog_priority)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1074 "src/core/load-fragment-gperf.gperf"
      {"Swap.MountFlags",                          config_parse_exec_mount_propagation_flag,           0,                                  offsetof(Swap, exec_context.mount_propagation_flag)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 853 "src/core/load-fragment-gperf.gperf"
      {"Mount.SetCredential",                       config_parse_set_credential,                        0,                                  offsetof(Mount, exec_context)},
#line 632 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupAllowedCPUs",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Socket, cgroup_context.startup_cpuset_cpus)},
      {(char*)0}, {(char*)0},
#line 400 "src/core/load-fragment-gperf.gperf"
      {"Service.NetClass",                            config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 634 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupAllowedMemoryNodes",           config_parse_allowed_cpuset,                        0,                                  offsetof(Socket, cgroup_context.startup_cpuset_mems)},
      {(char*)0},
#line 1054 "src/core/load-fragment-gperf.gperf"
      {"Swap.BindPaths",                           config_parse_bind_paths,                            0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 965 "src/core/load-fragment-gperf.gperf"
      {"Swap.MountImages",                         config_parse_mount_images,                          0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 262 "src/core/load-fragment-gperf.gperf"
      {"Service.LockPersonality",                     config_parse_bool,                                  0,                                  offsetof(Service, exec_context.lock_personality)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 115 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertFileIsExecutable",                  config_parse_unit_condition_path,                   CONDITION_FILE_IS_EXECUTABLE,       offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1090 "src/core/load-fragment-gperf.gperf"
      {"Swap.SetCredentialEncrypted",              config_parse_set_credential,                        1,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 731 "src/core/load-fragment-gperf.gperf"
      {"Mount.User",                                config_parse_user_group_compat,                     0,                                  offsetof(Mount, exec_context.user)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 269 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitRSS",                            config_parse_rlimit,                                RLIMIT_RSS,                         offsetof(Service, exec_context.rlimit)},
      {(char*)0}, {(char*)0},
#line 725 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootEphemeral",                       config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.root_ephemeral)},
      {(char*)0}, {(char*)0},
#line 549 "src/core/load-fragment-gperf.gperf"
      {"Socket.RestrictNamespaces",                  config_parse_restrict_namespaces,                   0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0},
#line 1063 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectControlGroups",                config_parse_protect_control_groups,                0,                                  offsetof(Swap, exec_context.protect_control_groups)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 695 "src/core/load-fragment-gperf.gperf"
      {"Socket.RestrictNetworkInterfaces",           config_parse_restrict_network_interfaces,           0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0},
#line 202 "src/core/load-fragment-gperf.gperf"
      {"Service.User",                                config_parse_user_group_compat,                     0,                                  offsetof(Service, exec_context.user)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 111 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertPathIsReadWrite",                   config_parse_unit_condition_path,                   CONDITION_PATH_IS_READ_WRITE,       offsetof(Unit, asserts)},
#line 110 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertPathIsMountPoint",                  config_parse_unit_condition_path,                   CONDITION_PATH_IS_MOUNT_POINT,      offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 126 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertACPower",                           config_parse_unit_condition_string,                 CONDITION_AC_POWER,                 offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 211 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUSchedulingPolicy",                 config_parse_exec_cpu_sched_policy,                 0,                                  offsetof(Service, exec_context)},
      {(char*)0},
#line 212 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUSchedulingPriority",               config_parse_exec_cpu_sched_prio,                   0,                                  offsetof(Service, exec_context)},
#line 493 "src/core/load-fragment-gperf.gperf"
      {"Socket.User",                                config_parse_user_group_compat,                     0,                                  offsetof(Socket, exec_context.user)},
#line 112 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertPathIsEncrypted",                   config_parse_unit_condition_path,                   CONDITION_PATH_IS_ENCRYPTED,        offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 818 "src/core/load-fragment-gperf.gperf"
      {"Mount.BindPaths",                           config_parse_bind_paths,                            0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 421 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenSpecial",                         config_parse_socket_listen,                         SOCKET_SPECIAL,                     0},
#line 750 "src/core/load-fragment-gperf.gperf"
      {"Mount.UnsetEnvironment",                    config_parse_unset_environ,                         0,                                  offsetof(Mount, exec_context.unset_environment)},
      {(char*)0},
#line 24 "src/core/load-fragment-gperf.gperf"
      {"Unit.Documentation",                           config_parse_documentation,                         0,                                  offsetof(Unit, documentation)},
      {(char*)0},
#line 139 "src/core/load-fragment-gperf.gperf"
      {"Service.PIDFile",                              config_parse_pid_file,                              0,                                  offsetof(Service, pid_file)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 855 "src/core/load-fragment-gperf.gperf"
      {"Mount.LoadCredential",                      config_parse_load_credential,                       0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 886 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 576 "src/core/load-fragment-gperf.gperf"
      {"Socket.InaccessiblePaths",                   config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.inaccessible_paths)},
#line 487 "src/core/load-fragment-gperf.gperf"
      {"Socket.RootEphemeral",                       config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.root_ephemeral)},
#line 617 "src/core/load-fragment-gperf.gperf"
      {"Socket.LoadCredential",                      config_parse_load_credential,                       0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 573 "src/core/load-fragment-gperf.gperf"
      {"Socket.InaccessibleDirectories",             config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.inaccessible_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1092 "src/core/load-fragment-gperf.gperf"
      {"Swap.LoadCredentialEncrypted",             config_parse_load_credential,                       1,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0},
#line 1346 "src/core/load-fragment-gperf.gperf"
      {"Scope.CoredumpReceive",                     config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.coredump_receive)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 516 "src/core/load-fragment-gperf.gperf"
      {"Socket.StandardOutput",                      config_parse_exec_output,                           0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 1083 "src/core/load-fragment-gperf.gperf"
      {"Swap.CacheDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_CACHE].mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1333 "src/core/load-fragment-gperf.gperf"
      {"Scope.ManagedOOMSwap",                      config_parse_managed_oom_mode,                      0,                                  offsetof(Scope, cgroup_context.moom_swap)},
      {(char*)0}, {(char*)0},
#line 597 "src/core/load-fragment-gperf.gperf"
      {"Socket.PrivatePIDs",                         config_parse_private_pids,                          0,                                  offsetof(Socket, exec_context.private_pids)},
      {(char*)0},
#line 1010 "src/core/load-fragment-gperf.gperf"
      {"Swap.SecureBits",                          config_parse_exec_secure_bits,                      0,                                  offsetof(Swap, exec_context.secure_bits)},
#line 417 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenDatagram",                        config_parse_socket_listen,                         SOCKET_SOCKET,                      0},
#line 819 "src/core/load-fragment-gperf.gperf"
      {"Mount.BindReadOnlyPaths",                   config_parse_bind_paths,                            0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 782 "src/core/load-fragment-gperf.gperf"
      {"Mount.SystemCallFilter",                    config_parse_syscall_filter,                        0,                                  offsetof(Mount, exec_context)},
#line 203 "src/core/load-fragment-gperf.gperf"
      {"Service.Group",                               config_parse_user_group_compat,                     0,                                  offsetof(Service, exec_context.group)},
#line 416 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenStream",                          config_parse_socket_listen,                         SOCKET_SOCKET,                      0},
      {(char*)0},
#line 629 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryKSM",                           config_parse_tristate,                              0,                                  offsetof(Socket, exec_context.memory_ksm)},
#line 784 "src/core/load-fragment-gperf.gperf"
      {"Mount.SystemCallErrorNumber",               config_parse_syscall_errno,                         0,                                  offsetof(Mount, exec_context)},
#line 372 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupIOWeight",                     config_parse_cg_weight,                             0,                                  offsetof(Service, cgroup_context.startup_io_weight)},
      {(char*)0},
#line 580 "src/core/load-fragment-gperf.gperf"
      {"Socket.BindPaths",                           config_parse_bind_paths,                            0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 783 "src/core/load-fragment-gperf.gperf"
      {"Mount.SystemCallArchitectures",             config_parse_syscall_archs,                         0,                                  offsetof(Mount, exec_context.syscall_archs)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 42 "src/core/load-fragment-gperf.gperf"
      {"Unit.StopPropagatedFrom",                      config_parse_unit_deps,                             UNIT_STOP_PROPAGATED_FROM,          0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 605 "src/core/load-fragment-gperf.gperf"
      {"Socket.RuntimeDirectoryMode",                config_parse_mode,                                  0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_RUNTIME].mode)},
#line 648 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0},
#line 602 "src/core/load-fragment-gperf.gperf"
      {"Socket.BindLogSockets",                      config_parse_tristate,                              0,                                  offsetof(Socket, exec_context.bind_log_sockets)},
#line 604 "src/core/load-fragment-gperf.gperf"
      {"Socket.RuntimeDirectoryPreserve",            config_parse_exec_preserve_mode,                    0,                                  offsetof(Socket, exec_context.runtime_directory_preserve_mode)},
      {(char*)0}, {(char*)0},
#line 303 "src/core/load-fragment-gperf.gperf"
      {"Service.PrivateUsers",                        config_parse_private_users,                         0,                                  offsetof(Service, exec_context.private_users)},
      {(char*)0},
#line 1276 "src/core/load-fragment-gperf.gperf"
      {"Slice.CoredumpReceive",                     config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.coredump_receive)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 547 "src/core/load-fragment-gperf.gperf"
      {"Socket.SystemCallLog",                       config_parse_syscall_log,                           0,                                  offsetof(Socket, exec_context)},
#line 838 "src/core/load-fragment-gperf.gperf"
      {"Mount.MountFlags",                          config_parse_exec_mount_propagation_flag,           0,                                  offsetof(Mount, exec_context.mount_propagation_flag)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 786 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryDenyWriteExecute",              config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.memory_deny_write_execute)},
      {(char*)0},
#line 1263 "src/core/load-fragment-gperf.gperf"
      {"Slice.ManagedOOMSwap",                      config_parse_managed_oom_mode,                      0,                                  offsetof(Slice, cgroup_context.moom_swap)},
#line 1113 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupCPUShares",                    config_parse_cpu_shares,                            0,                                  offsetof(Swap, cgroup_context.startup_cpu_shares)},
#line 553 "src/core/load-fragment-gperf.gperf"
      {"Socket.LockPersonality",                     config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.lock_personality)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 108 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertPathIsDirectory",                   config_parse_unit_condition_path,                   CONDITION_PATH_IS_DIRECTORY,        offsetof(Unit, asserts)},
      {(char*)0},
#line 408 "src/core/load-fragment-gperf.gperf"
      {"Service.CoredumpReceive",                     config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.coredump_receive)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 381 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupBlockIOWeight",                config_parse_blockio_weight,                        0,                                  offsetof(Service, cgroup_context.startup_blockio_weight)},
      {(char*)0}, {(char*)0},
#line 330 "src/core/load-fragment-gperf.gperf"
      {"Service.PAMName",                             config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
#line 1093 "src/core/load-fragment-gperf.gperf"
      {"Swap.ImportCredential",                    config_parse_import_credential,                     0,                                  offsetof(Swap, exec_context)},
#line 208 "src/core/load-fragment-gperf.gperf"
      {"Service.CoredumpFilter",                      config_parse_exec_coredump_filter,                  0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0},
#line 249 "src/core/load-fragment-gperf.gperf"
      {"Service.NoNewPrivileges",                     config_parse_bool,                                  0,                                  offsetof(Service, exec_context.no_new_privileges)},
      {(char*)0}, {(char*)0},
#line 537 "src/core/load-fragment-gperf.gperf"
      {"Socket.CapabilityBoundingSet",               config_parse_capability_set,                        0,                                  offsetof(Socket, exec_context.capability_bounding_set)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 535 "src/core/load-fragment-gperf.gperf"
      {"Socket.Capabilities",                        config_parse_warn_compat,                           DISABLED_LEGACY,                    offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 966 "src/core/load-fragment-gperf.gperf"
      {"Swap.MountImagePolicy",                    config_parse_image_policy,                          0,                                  offsetof(Swap, exec_context.mount_image_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1355 "src/core/load-fragment-gperf.gperf"
      {"Scope.RuntimeRandomizedExtraSec",              config_parse_sec,                                   0,                                  offsetof(Scope, runtime_rand_extra_usec)},
#line 729 "src/core/load-fragment-gperf.gperf"
      {"Mount.MountImages",                         config_parse_mount_images,                          0,                                  offsetof(Mount, exec_context)},
#line 1098 "src/core/load-fragment-gperf.gperf"
      {"Swap.UtmpMode",                            config_parse_exec_utmp_mode,                        0,                                  offsetof(Swap, exec_context.utmp_mode)},
      {(char*)0},
#line 1123 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryHigh",                          config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0},
#line 720 "src/core/load-fragment-gperf.gperf"
      {"Mount.RootImageOptions",                    config_parse_root_image_options,                    0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1009 "src/core/load-fragment-gperf.gperf"
      {"Swap.Capabilities",                        config_parse_warn_compat,                           DISABLED_LEGACY,                    offsetof(Swap, exec_context)},
#line 453 "src/core/load-fragment-gperf.gperf"
      {"Socket.Mark",                                  config_parse_int,                                   0,                                  offsetof(Socket, mark)},
#line 246 "src/core/load-fragment-gperf.gperf"
      {"Service.CapabilityBoundingSet",               config_parse_capability_set,                        0,                                  offsetof(Service, exec_context.capability_bounding_set)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 515 "src/core/load-fragment-gperf.gperf"
      {"Socket.StandardInput",                       config_parse_exec_input,                            0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 244 "src/core/load-fragment-gperf.gperf"
      {"Service.Capabilities",                        config_parse_warn_compat,                           DISABLED_LEGACY,                    offsetof(Service, exec_context)},
      {(char*)0},
#line 518 "src/core/load-fragment-gperf.gperf"
      {"Socket.StandardInputText",                   config_parse_exec_input_text,                       0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 832 "src/core/load-fragment-gperf.gperf"
      {"Mount.PrivateUsers",                        config_parse_private_users,                         0,                                  offsetof(Mount, exec_context.private_users)},
#line 714 "src/core/load-fragment-gperf.gperf"
      {"Mount.LazyUnmount",                            config_parse_bool,                                  0,                                  offsetof(Mount, lazy_unmount)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 341 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupAllowedCPUs",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Service, cgroup_context.startup_cpuset_cpus)},
      {(char*)0}, {(char*)0},
#line 1056 "src/core/load-fragment-gperf.gperf"
      {"Swap.TemporaryFileSystem",                 config_parse_temporary_filesystems,                 0,                                  offsetof(Swap, exec_context)},
#line 935 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryPressureWatch",                 config_parse_memory_pressure_watch,                 0,                                  offsetof(Mount, cgroup_context.memory_pressure_watch)},
      {(char*)0}, {(char*)0},
#line 343 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupAllowedMemoryNodes",           config_parse_allowed_cpuset,                        0,                                  offsetof(Service, cgroup_context.startup_cpuset_mems)},
#line 1171 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryPressureWatch",                 config_parse_memory_pressure_watch,                 0,                                  offsetof(Swap, cgroup_context.memory_pressure_watch)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1089 "src/core/load-fragment-gperf.gperf"
      {"Swap.SetCredential",                       config_parse_set_credential,                        0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1084 "src/core/load-fragment-gperf.gperf"
      {"Swap.CacheDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_CACHE])},
      {(char*)0},
#line 392 "src/core/load-fragment-gperf.gperf"
      {"Service.IPAddressDeny",                       config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Service, cgroup_context.ip_address_deny)},
      {(char*)0},
#line 157 "src/core/load-fragment-gperf.gperf"
      {"Service.RuntimeRandomizedExtraSec",            config_parse_sec,                                   0,                                  offsetof(Service, runtime_rand_extra_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1165 "src/core/load-fragment-gperf.gperf"
      {"Swap.NetClass",                            config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
#line 519 "src/core/load-fragment-gperf.gperf"
      {"Socket.StandardInputData",                   config_parse_exec_input_data,                       0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 495 "src/core/load-fragment-gperf.gperf"
      {"Socket.SupplementaryGroups",                 config_parse_user_group_strv_compat,                0,                                  offsetof(Socket, exec_context.supplementary_groups)},
#line 477 "src/core/load-fragment-gperf.gperf"
      {"Socket.SmackLabelIPOut",                       config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0},
#line 285 "src/core/load-fragment-gperf.gperf"
      {"Service.InaccessiblePaths",                   config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.inaccessible_paths)},
      {(char*)0},
#line 1124 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupMemoryHigh",                   config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 282 "src/core/load-fragment-gperf.gperf"
      {"Service.InaccessibleDirectories",             config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.inaccessible_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1295 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0},
#line 368 "src/core/load-fragment-gperf.gperf"
      {"Service.DeviceAllow",                         config_parse_device_allow,                          0,                                  offsetof(Service, cgroup_context)},
#line 238 "src/core/load-fragment-gperf.gperf"
      {"Service.SyslogLevelPrefix",                   config_parse_bool,                                  0,                                  offsetof(Service, exec_context.syslog_level_prefix)},
      {(char*)0},
#line 31 "src/core/load-fragment-gperf.gperf"
      {"Unit.Upholds",                                 config_parse_unit_deps,                             UNIT_UPHOLDS,                       0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 606 "src/core/load-fragment-gperf.gperf"
      {"Socket.RuntimeDirectory",                    config_parse_exec_directories,                      0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_RUNTIME])},
      {(char*)0}, {(char*)0},
#line 476 "src/core/load-fragment-gperf.gperf"
      {"Socket.SmackLabelIPIn",                        config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 284 "src/core/load-fragment-gperf.gperf"
      {"Service.ReadOnlyPaths",                       config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.read_only_paths)},
      {(char*)0}, {(char*)0},
#line 749 "src/core/load-fragment-gperf.gperf"
      {"Mount.PassEnvironment",                     config_parse_pass_environ,                          0,                                  offsetof(Mount, exec_context.pass_environment)},
      {(char*)0}, {(char*)0},
#line 281 "src/core/load-fragment-gperf.gperf"
      {"Service.ReadOnlyDirectories",                 config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.read_only_paths)},
#line 642 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryAccounting",                    config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.memory_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 716 "src/core/load-fragment-gperf.gperf"
      {"Mount.ReadWriteOnly",                          config_parse_bool,                                  0,                                  offsetof(Mount, read_write_only)},
#line 457 "src/core/load-fragment-gperf.gperf"
      {"Socket.Broadcast",                             config_parse_bool,                                  0,                                  offsetof(Socket, broadcast)},
#line 697 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryPressureWatch",                 config_parse_memory_pressure_watch,                 0,                                  offsetof(Socket, cgroup_context.memory_pressure_watch)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 690 "src/core/load-fragment-gperf.gperf"
      {"Socket.ManagedOOMPreference",                config_parse_managed_oom_preference,                0,                                  offsetof(Socket, cgroup_context.moom_preference)},
#line 800 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitAS",                             config_parse_rlimit,                                RLIMIT_AS,                          offsetof(Mount, exec_context.rlimit)},
#line 798 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitRSS",                            config_parse_rlimit,                                RLIMIT_RSS,                         offsetof(Mount, exec_context.rlimit)},
      {(char*)0},
#line 687 "src/core/load-fragment-gperf.gperf"
      {"Socket.ManagedOOMMemoryPressure",            config_parse_managed_oom_mode,                      0,                                  offsetof(Socket, cgroup_context.moom_mem_pressure)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 688 "src/core/load-fragment-gperf.gperf"
      {"Socket.ManagedOOMMemoryPressureLimit",       config_parse_managed_oom_mem_pressure_limit,        0,                                  offsetof(Socket, cgroup_context.moom_mem_pressure_limit)},
#line 366 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryZSwapWriteback",                config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.memory_zswap_writeback)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 156 "src/core/load-fragment-gperf.gperf"
      {"Service.RuntimeMaxSec",                        config_parse_sec,                                   0,                                  offsetof(Service, runtime_max_usec)},
#line 1225 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 290 "src/core/load-fragment-gperf.gperf"
      {"Service.BindReadOnlyPaths",                   config_parse_bind_paths,                            0,                                  offsetof(Service, exec_context)},
      {(char*)0},
#line 647 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryLow",                           config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0},
#line 613 "src/core/load-fragment-gperf.gperf"
      {"Socket.ConfigurationDirectoryMode",          config_parse_mode,                                  0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION].mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 730 "src/core/load-fragment-gperf.gperf"
      {"Mount.MountImagePolicy",                    config_parse_image_policy,                          0,                                  offsetof(Mount, exec_context.mount_image_policy)},
      {(char*)0},
#line 1091 "src/core/load-fragment-gperf.gperf"
      {"Swap.LoadCredential",                      config_parse_load_credential,                       0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0},
#line 360 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryMax",                           config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1184 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnStartupSec",                           config_parse_timer,                                 TIMER_STARTUP,                      0},
      {(char*)0},
#line 333 "src/core/load-fragment-gperf.gperf"
      {"Service.UtmpMode",                            config_parse_exec_utmp_mode,                        0,                                  offsetof(Service, exec_context.utmp_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 679 "src/core/load-fragment-gperf.gperf"
      {"Socket.DelegateSubgroup",                    config_parse_delegate_subgroup,                     0,                                  offsetof(Socket, cgroup_context)},
#line 66 "src/core/load-fragment-gperf.gperf"
      {"Unit.StartLimitBurst",                         config_parse_unsigned,                              0,                                  offsetof(Unit, start_ratelimit.burst)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 47 "src/core/load-fragment-gperf.gperf"
      {"Unit.RequiresMountsFor",                       config_parse_unit_mounts_for,                       0,                                  0},
#line 849 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogsDirectoryMode",                   config_parse_mode,                                  0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_LOGS].mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 624 "src/core/load-fragment-gperf.gperf"
      {"Socket.UtmpMode",                            config_parse_exec_utmp_mode,                        0,                                  offsetof(Socket, exec_context.utmp_mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1107 "src/core/load-fragment-gperf.gperf"
      {"Swap.AllowedMemoryNodes",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Swap, cgroup_context.cpuset_mems)},
      {(char*)0},
#line 552 "src/core/load-fragment-gperf.gperf"
      {"Socket.RestrictAddressFamilies",             config_parse_address_families,                      0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 896 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryLimit",                         config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 623 "src/core/load-fragment-gperf.gperf"
      {"Socket.UtmpIdentifier",                      config_parse_unit_string_printf,                    0,                                  offsetof(Socket, exec_context.utmp_id)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 945 "src/core/load-fragment-gperf.gperf"
      {"Automount.Where",                              config_parse_unit_path_printf,                      0,                                  offsetof(Automount, where)},
      {(char*)0}, {(char*)0},
#line 709 "src/core/load-fragment-gperf.gperf"
      {"Mount.Options",                                config_parse_unit_string_printf,                    0,                                  offsetof(Mount, parameters_fragment.options)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 532 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogRateLimitBurst",                   config_parse_unsigned,                              0,                                  offsetof(Socket, exec_context.log_ratelimit.burst)},
#line 1137 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupIOWeight",                     config_parse_cg_weight,                             0,                                  offsetof(Swap, cgroup_context.startup_io_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 962 "src/core/load-fragment-gperf.gperf"
      {"Swap.ExtensionDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.extension_directories)},
      {(char*)0}, {(char*)0},
#line 947 "src/core/load-fragment-gperf.gperf"
      {"Automount.DirectoryMode",                      config_parse_mode,                                  0,                                  offsetof(Automount, directory_mode)},
      {(char*)0},
#line 1344 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryPressureWatch",                 config_parse_memory_pressure_watch,                 0,                                  offsetof(Scope, cgroup_context.memory_pressure_watch)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1039 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitLOCKS",                          config_parse_rlimit,                                RLIMIT_LOCKS,                       offsetof(Swap, exec_context.rlimit)},
#line 67 "src/core/load-fragment-gperf.gperf"
      {"Unit.StartLimitAction",                        config_parse_emergency_action,                      0,                                  offsetof(Unit, start_limit_action)},
#line 1085 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogsDirectoryMode",                   config_parse_mode,                                  0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_LOGS].mode)},
#line 773 "src/core/load-fragment-gperf.gperf"
      {"Mount.Capabilities",                        config_parse_warn_compat,                           DISABLED_LEGACY,                    offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 106 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertPathExists",                        config_parse_unit_condition_path,                   CONDITION_PATH_EXISTS,              offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 588 "src/core/load-fragment-gperf.gperf"
      {"Socket.ProtectClock",                        config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.protect_clock)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 361 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupMemoryMax",                    config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 401 "src/core/load-fragment-gperf.gperf"
      {"Service.BPFProgram",                          config_parse_bpf_foreign_program,                   0,                                  offsetof(Service, cgroup_context)},
#line 363 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupMemorySwapMax",                config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
#line 365 "src/core/load-fragment-gperf.gperf"
      {"Service.StartupMemoryZSwapMax",               config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 364 "src/core/load-fragment-gperf.gperf"
      {"Service.MemoryZSwapMax",                      config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1049 "src/core/load-fragment-gperf.gperf"
      {"Swap.ReadOnlyPaths",                       config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.read_only_paths)},
#line 614 "src/core/load-fragment-gperf.gperf"
      {"Socket.ConfigurationDirectory",              config_parse_exec_directories,                      0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION])},
      {(char*)0},
#line 732 "src/core/load-fragment-gperf.gperf"
      {"Mount.Group",                               config_parse_user_group_compat,                     0,                                  offsetof(Mount, exec_context.group)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1274 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryPressureWatch",                 config_parse_memory_pressure_watch,                 0,                                  offsetof(Slice, cgroup_context.memory_pressure_watch)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1046 "src/core/load-fragment-gperf.gperf"
      {"Swap.ReadOnlyDirectories",                 config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.read_only_paths)},
#line 560 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitRSS",                            config_parse_rlimit,                                RLIMIT_RSS,                         offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 888 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupMemoryHigh",                   config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 320 "src/core/load-fragment-gperf.gperf"
      {"Service.LogsDirectoryMode",                   config_parse_mode,                                  0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_LOGS].mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 310 "src/core/load-fragment-gperf.gperf"
      {"Service.MountAPIVFS",                         config_parse_tristate,                              0,                                  offsetof(Service, exec_context.mount_apivfs)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 314 "src/core/load-fragment-gperf.gperf"
      {"Service.RuntimeDirectoryMode",                config_parse_mode,                                  0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_RUNTIME].mode)},
      {(char*)0},
#line 220 "src/core/load-fragment-gperf.gperf"
      {"Service.PassEnvironment",                     config_parse_pass_environ,                          0,                                  offsetof(Service, exec_context.pass_environment)},
#line 1199 "src/core/load-fragment-gperf.gperf"
      {"Path.PathChanged",                             config_parse_path_spec,                             0,                                  0},
#line 313 "src/core/load-fragment-gperf.gperf"
      {"Service.RuntimeDirectoryPreserve",            config_parse_exec_preserve_mode,                    0,                                  offsetof(Service, exec_context.runtime_directory_preserve_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 345 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUWeight",                           config_parse_cg_cpu_weight,                         0,                                  offsetof(Service, cgroup_context.cpu_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 850 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogsDirectory",                       config_parse_exec_directories,                      0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_LOGS])},
#line 466 "src/core/load-fragment-gperf.gperf"
      {"Socket.MessageQueueMessageSize",               config_parse_long,                                  0,                                  offsetof(Socket, mq_msgsize)},
      {(char*)0},
#line 475 "src/core/load-fragment-gperf.gperf"
      {"Socket.SmackLabel",                            config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
#line 437 "src/core/load-fragment-gperf.gperf"
      {"Socket.Accept",                                config_parse_bool,                                  0,                                  offsetof(Socket, accept)},
#line 388 "src/core/load-fragment-gperf.gperf"
      {"Service.DelegateSubgroup",                    config_parse_delegate_subgroup,                     0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 347 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUShares",                           config_parse_cpu_shares,                            0,                                  offsetof(Service, cgroup_context.cpu_shares)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 766 "src/core/load-fragment-gperf.gperf"
      {"Mount.SyslogLevel",                         config_parse_log_level,                             0,                                  offsetof(Mount, exec_context.syslog_priority)},
      {(char*)0}, {(char*)0},
#line 465 "src/core/load-fragment-gperf.gperf"
      {"Socket.MessageQueueMaxMessages",               config_parse_long,                                  0,                                  offsetof(Socket, mq_maxmsg)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 689 "src/core/load-fragment-gperf.gperf"
      {"Socket.ManagedOOMMemoryPressureDurationSec", config_parse_managed_oom_mem_pressure_duration_sec, 0,                                  offsetof(Socket, cgroup_context.moom_mem_pressure_duration_usec)},
#line 1106 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupAllowedCPUs",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Swap, cgroup_context.startup_cpuset_cpus)},
#line 479 "src/core/load-fragment-gperf.gperf"
      {"Socket.WorkingDirectory",                    config_parse_working_directory,                     0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1108 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupAllowedMemoryNodes",           config_parse_allowed_cpuset,                        0,                                  offsetof(Swap, cgroup_context.startup_cpuset_mems)},
#line 64 "src/core/load-fragment-gperf.gperf"
      {"Unit.StartLimitIntervalSec",                   config_parse_sec,                                   0,                                  offsetof(Unit, start_ratelimit.interval)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1037 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitNPROC",                          config_parse_rlimit,                                RLIMIT_NPROC,                       offsetof(Swap, exec_context.rlimit)},
      {(char*)0},
#line 391 "src/core/load-fragment-gperf.gperf"
      {"Service.IPAddressAllow",                      config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Service, cgroup_context.ip_address_allow)},
      {(char*)0},
#line 650 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupMemoryHigh",                   config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 764 "src/core/load-fragment-gperf.gperf"
      {"Mount.SyslogIdentifier",                    config_parse_unit_string_printf,                    0,                                  offsetof(Mount, exec_context.syslog_identifier)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1094 "src/core/load-fragment-gperf.gperf"
      {"Swap.TimeoutCleanSec",                     config_parse_sec,                                   0,                                  offsetof(Swap, exec_context.timeout_clean_usec)},
      {(char*)0},
#line 775 "src/core/load-fragment-gperf.gperf"
      {"Mount.CapabilityBoundingSet",               config_parse_capability_set,                        0,                                  offsetof(Mount, exec_context.capability_bounding_set)},
#line 1086 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogsDirectory",                       config_parse_exec_directories,                      0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_LOGS])},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 336 "src/core/load-fragment-gperf.gperf"
      {"Service.SmackProcessLabel",                   config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0},
#line 1305 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryLimit",                         config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
#line 283 "src/core/load-fragment-gperf.gperf"
      {"Service.ReadWritePaths",                      config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.read_write_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 275 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitSIGPENDING",                     config_parse_rlimit,                                RLIMIT_SIGPENDING,                  offsetof(Service, exec_context.rlimit)},
#line 280 "src/core/load-fragment-gperf.gperf"
      {"Service.ReadWriteDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.read_write_paths)},
#line 895 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryZSwapWriteback",                config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.memory_zswap_writeback)},
      {(char*)0}, {(char*)0},
#line 65 "src/core/load-fragment-gperf.gperf"
      {"Unit.StartLimitInterval",                      config_parse_sec,                                   0,                                  offsetof(Unit, start_ratelimit.interval)},
      {(char*)0},
#line 609 "src/core/load-fragment-gperf.gperf"
      {"Socket.CacheDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_CACHE].mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 328 "src/core/load-fragment-gperf.gperf"
      {"Service.ImportCredential",                    config_parse_import_credential,                     0,                                  offsetof(Service, exec_context)},
#line 25 "src/core/load-fragment-gperf.gperf"
      {"Unit.SourcePath",                              config_parse_unit_path_printf,                      0,                                  offsetof(Unit, source_path)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 986 "src/core/load-fragment-gperf.gperf"
      {"Swap.UnsetEnvironment",                    config_parse_unset_environ,                         0,                                  offsetof(Swap, exec_context.unset_environment)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 353 "src/core/load-fragment-gperf.gperf"
      {"Service.DefaultMemoryMin",                    config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0},
#line 349 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUQuota",                            config_parse_cpu_quota,                             0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 441 "src/core/load-fragment-gperf.gperf"
      {"Socket.MaxConnectionsPerSource",               config_parse_unsigned,                              0,                                  offsetof(Socket, max_connections_per_source)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 440 "src/core/load-fragment-gperf.gperf"
      {"Socket.MaxConnections",                        config_parse_unsigned,                              0,                                  offsetof(Socket, max_connections)},
      {(char*)0}, {(char*)0},
#line 590 "src/core/load-fragment-gperf.gperf"
      {"Socket.NetworkNamespacePath",                config_parse_unit_path_printf,                      0,                                  offsetof(Socket, exec_context.network_namespace_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1154 "src/core/load-fragment-gperf.gperf"
      {"Swap.DisableControllers",                  config_parse_disable_controllers,                   0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0},
#line 517 "src/core/load-fragment-gperf.gperf"
      {"Socket.StandardError",                       config_parse_exec_output,                           0,                                  offsetof(Socket, exec_context)},
#line 335 "src/core/load-fragment-gperf.gperf"
      {"Service.AppArmorProfile",                     config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
#line 611 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogsDirectoryMode",                   config_parse_mode,                                  0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_LOGS].mode)},
      {(char*)0},
#line 321 "src/core/load-fragment-gperf.gperf"
      {"Service.LogsDirectory",                       config_parse_exec_directories,                      0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_LOGS])},
#line 1235 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryLimit",                         config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
#line 1191 "src/core/load-fragment-gperf.gperf"
      {"Timer.RemainAfterElapse",                      config_parse_bool,                                  0,                                  offsetof(Timer, remain_after_elapse)},
      {(char*)0},
#line 531 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogRateLimitIntervalSec",             config_parse_sec,                                   0,                                  offsetof(Socket, exec_context.log_ratelimit.interval)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 315 "src/core/load-fragment-gperf.gperf"
      {"Service.RuntimeDirectory",                    config_parse_exec_directories,                      0,                                  offsetof(Service, exec_context.directories[EXEC_DIRECTORY_RUNTIME])},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 633 "src/core/load-fragment-gperf.gperf"
      {"Socket.AllowedMemoryNodes",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Socket, cgroup_context.cpuset_mems)},
      {(char*)0},
#line 1362 "src/core/load-fragment-gperf.gperf"
      {"Install.Also",                                 NULL,                                               0,                                  0},
#line 1358 "src/core/load-fragment-gperf.gperf"
      {"Install.Alias",                                NULL,                                               0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1079 "src/core/load-fragment-gperf.gperf"
      {"Swap.RuntimeDirectoryMode",                config_parse_mode,                                  0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_RUNTIME].mode)},
#line 447 "src/core/load-fragment-gperf.gperf"
      {"Socket.NoDelay",                               config_parse_bool,                                  0,                                  offsetof(Socket, no_delay)},
      {(char*)0}, {(char*)0},
#line 1078 "src/core/load-fragment-gperf.gperf"
      {"Swap.RuntimeDirectoryPreserve",            config_parse_exec_preserve_mode,                    0,                                  offsetof(Swap, exec_context.runtime_directory_preserve_mode)},
      {(char*)0},
#line 929 "src/core/load-fragment-gperf.gperf"
      {"Mount.NetClass",                            config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
      {(char*)0},
#line 1019 "src/core/load-fragment-gperf.gperf"
      {"Swap.SystemCallArchitectures",             config_parse_syscall_archs,                         0,                                  offsetof(Swap, exec_context.syscall_archs)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1013 "src/core/load-fragment-gperf.gperf"
      {"Swap.TimerSlackNSec",                      config_parse_nsec,                                  0,                                  offsetof(Swap, exec_context.timer_slack_nsec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1146 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupBlockIOWeight",                config_parse_blockio_weight,                        0,                                  offsetof(Swap, cgroup_context.startup_blockio_weight)},
#line 171 "src/core/load-fragment-gperf.gperf"
      {"Service.GuessMainPID",                         config_parse_bool,                                  0,                                  offsetof(Service, guess_main_pid)},
      {(char*)0}, {(char*)0},
#line 1297 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupMemoryHigh",                   config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1071 "src/core/load-fragment-gperf.gperf"
      {"Swap.PrivatePIDs",                         config_parse_private_pids,                          0,                                  offsetof(Swap, exec_context.private_pids)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 534 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogFilterPatterns",                   config_parse_log_filter_patterns,                   0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 875 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupCPUWeight",                    config_parse_cg_cpu_weight,                         0,                                  offsetof(Mount, cgroup_context.startup_cpu_weight)},
      {(char*)0}, {(char*)0},
#line 1027 "src/core/load-fragment-gperf.gperf"
      {"Swap.LockPersonality",                     config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.lock_personality)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1203 "src/core/load-fragment-gperf.gperf"
      {"Path.MakeDirectory",                           config_parse_bool,                                  0,                                  offsetof(Path, make_directory)},
#line 631 "src/core/load-fragment-gperf.gperf"
      {"Socket.AllowedCPUs",                         config_parse_allowed_cpuset,                        0,                                  offsetof(Socket, cgroup_context.cpuset_cpus)},
      {(char*)0}, {(char*)0},
#line 877 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupCPUShares",                    config_parse_cpu_shares,                            0,                                  offsetof(Mount, cgroup_context.startup_cpu_shares)},
      {(char*)0},
#line 1227 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupMemoryHigh",                   config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0},
#line 893 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryZSwapMax",                      config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
#line 610 "src/core/load-fragment-gperf.gperf"
      {"Socket.CacheDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_CACHE])},
      {(char*)0}, {(char*)0},
#line 1125 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryMax",                           config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1157 "src/core/load-fragment-gperf.gperf"
      {"Swap.IPAddressDeny",                       config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Swap, cgroup_context.ip_address_deny)},
      {(char*)0},
#line 963 "src/core/load-fragment-gperf.gperf"
      {"Swap.ExtensionImages",                     config_parse_extension_images,                      0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 566 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitSIGPENDING",                     config_parse_rlimit,                                RLIMIT_SIGPENDING,                  offsetof(Socket, exec_context.rlimit)},
      {(char*)0},
#line 785 "src/core/load-fragment-gperf.gperf"
      {"Mount.SystemCallLog",                       config_parse_syscall_log,                           0,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 218 "src/core/load-fragment-gperf.gperf"
      {"Service.Environment",                         config_parse_environ,                               0,                                  offsetof(Service, exec_context.environment)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 219 "src/core/load-fragment-gperf.gperf"
      {"Service.EnvironmentFile",                     config_parse_unit_env_file,                         0,                                  offsetof(Service, exec_context.environment_files)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 362 "src/core/load-fragment-gperf.gperf"
      {"Service.MemorySwapMax",                       config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
#line 959 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootHashSignature",                   config_parse_exec_root_hash_sig,                    0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1126 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupMemoryMax",                    config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1128 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupMemorySwapMax",                config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
#line 1130 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupMemoryZSwapMax",               config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 612 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogsDirectory",                       config_parse_exec_directories,                      0,                                  offsetof(Socket, exec_context.directories[EXEC_DIRECTORY_LOGS])},
#line 1045 "src/core/load-fragment-gperf.gperf"
      {"Swap.ReadWriteDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.read_write_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 327 "src/core/load-fragment-gperf.gperf"
      {"Service.LoadCredentialEncrypted",             config_parse_load_credential,                       1,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1304 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryZSwapWriteback",                config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.memory_zswap_writeback)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1080 "src/core/load-fragment-gperf.gperf"
      {"Swap.RuntimeDirectory",                    config_parse_exec_directories,                      0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_RUNTIME])},
#line 699 "src/core/load-fragment-gperf.gperf"
      {"Socket.CoredumpReceive",                     config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.coredump_receive)},
      {(char*)0}, {(char*)0},
#line 1048 "src/core/load-fragment-gperf.gperf"
      {"Swap.ReadWritePaths",                      config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.read_write_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 706 "src/core/load-fragment-gperf.gperf"
      {"Socket.WatchdogSignal",                      config_parse_signal,                                0,                                  offsetof(Socket, kill_context.watchdog_signal)},
      {(char*)0}, {(char*)0},
#line 350 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUQuotaPeriodSec",                   config_parse_sec_def_infinity,                      0,                                  offsetof(Service, cgroup_context.cpu_quota_period_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 778 "src/core/load-fragment-gperf.gperf"
      {"Mount.NoNewPrivileges",                     config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.no_new_privileges)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 193 "src/core/load-fragment-gperf.gperf"
      {"Service.RootHash",                            config_parse_exec_root_hash,                        0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 944 "src/core/load-fragment-gperf.gperf"
      {"Mount.WatchdogSignal",                      config_parse_signal,                                0,                                  offsetof(Mount, kill_context.watchdog_signal)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 653 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemorySwapMax",                       config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1234 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryZSwapWriteback",                config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.memory_zswap_writeback)},
#line 355 "src/core/load-fragment-gperf.gperf"
      {"Service.DefaultStartupMemoryLow",             config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 885 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryLow",                           config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0},
#line 1014 "src/core/load-fragment-gperf.gperf"
      {"Swap.NoNewPrivileges",                     config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.no_new_privileges)},
#line 274 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitLOCKS",                          config_parse_rlimit,                                RLIMIT_LOCKS,                       offsetof(Service, exec_context.rlimit)},
#line 713 "src/core/load-fragment-gperf.gperf"
      {"Mount.SloppyOptions",                          config_parse_bool,                                  0,                                  offsetof(Mount, sloppy_options)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 621 "src/core/load-fragment-gperf.gperf"
      {"Socket.PAMName",                             config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0},
#line 686 "src/core/load-fragment-gperf.gperf"
      {"Socket.ManagedOOMSwap",                      config_parse_managed_oom_mode,                      0,                                  offsetof(Socket, cgroup_context.moom_swap)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1338 "src/core/load-fragment-gperf.gperf"
      {"Scope.NetClass",                            config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 985 "src/core/load-fragment-gperf.gperf"
      {"Swap.PassEnvironment",                     config_parse_pass_environ,                          0,                                  offsetof(Swap, exec_context.pass_environment)},
      {(char*)0},
#line 861 "src/core/load-fragment-gperf.gperf"
      {"Mount.UtmpIdentifier",                      config_parse_unit_string_printf,                    0,                                  offsetof(Mount, exec_context.utmp_id)},
#line 814 "src/core/load-fragment-gperf.gperf"
      {"Mount.InaccessiblePaths",                   config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.inaccessible_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 811 "src/core/load-fragment-gperf.gperf"
      {"Mount.InaccessibleDirectories",             config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.inaccessible_paths)},
      {(char*)0},
#line 862 "src/core/load-fragment-gperf.gperf"
      {"Mount.UtmpMode",                            config_parse_exec_utmp_mode,                        0,                                  offsetof(Mount, exec_context.utmp_mode)},
#line 847 "src/core/load-fragment-gperf.gperf"
      {"Mount.CacheDirectoryMode",                  config_parse_mode,                                  0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_CACHE].mode)},
#line 964 "src/core/load-fragment-gperf.gperf"
      {"Swap.ExtensionImagePolicy",                config_parse_image_policy,                          0,                                  offsetof(Swap, exec_context.extension_image_policy)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 297 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectClock",                        config_parse_bool,                                  0,                                  offsetof(Service, exec_context.protect_clock)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 399 "src/core/load-fragment-gperf.gperf"
      {"Service.ManagedOOMPreference",                config_parse_managed_oom_preference,                0,                                  offsetof(Service, cgroup_context.moom_preference)},
      {(char*)0}, {(char*)0},
#line 1181 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnCalendar",                             config_parse_timer,                                 TIMER_CALENDAR,                     0},
#line 396 "src/core/load-fragment-gperf.gperf"
      {"Service.ManagedOOMMemoryPressure",            config_parse_managed_oom_mode,                      0,                                  offsetof(Service, cgroup_context.moom_mem_pressure)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 397 "src/core/load-fragment-gperf.gperf"
      {"Service.ManagedOOMMemoryPressureLimit",       config_parse_managed_oom_mem_pressure_limit,        0,                                  offsetof(Service, cgroup_context.moom_mem_pressure_limit)},
      {(char*)0},
#line 983 "src/core/load-fragment-gperf.gperf"
      {"Swap.Environment",                         config_parse_environ,                               0,                                  offsetof(Swap, exec_context.environment)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 984 "src/core/load-fragment-gperf.gperf"
      {"Swap.EnvironmentFile",                     config_parse_unit_env_file,                         0,                                  offsetof(Swap, exec_context.environment_files)},
      {(char*)0}, {(char*)0},
#line 1268 "src/core/load-fragment-gperf.gperf"
      {"Slice.NetClass",                            config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
#line 190 "src/core/load-fragment-gperf.gperf"
      {"Service.RootImage",                           config_parse_unit_path_printf,                      true,                               offsetof(Service, exec_context.root_image)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1284 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupCPUWeight",                    config_parse_cg_cpu_weight,                         0,                                  offsetof(Scope, cgroup_context.startup_cpu_weight)},
      {(char*)0}, {(char*)0},
#line 840 "src/core/load-fragment-gperf.gperf"
      {"Mount.BindLogSockets",                      config_parse_tristate,                              0,                                  offsetof(Mount, exec_context.bind_log_sockets)},
#line 241 "src/core/load-fragment-gperf.gperf"
      {"Service.LogRateLimitBurst",                   config_parse_unsigned,                              0,                                  offsetof(Service, exec_context.log_ratelimit.burst)},
      {(char*)0},
#line 1359 "src/core/load-fragment-gperf.gperf"
      {"Install.WantedBy",                             NULL,                                               0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1286 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupCPUShares",                    config_parse_cpu_shares,                            0,                                  offsetof(Scope, cgroup_context.startup_cpu_shares)},
      {(char*)0}, {(char*)0},
#line 191 "src/core/load-fragment-gperf.gperf"
      {"Service.RootImageOptions",                    config_parse_root_image_options,                    0,                                  offsetof(Service, exec_context)},
#line 1302 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryZSwapMax",                      config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0},
#line 649 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryHigh",                          config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 49 "src/core/load-fragment-gperf.gperf"
      {"Unit.StopWhenUnneeded",                        config_parse_bool,                                  0,                                  offsetof(Unit, stop_when_unneeded)},
#line 1021 "src/core/load-fragment-gperf.gperf"
      {"Swap.SystemCallLog",                       config_parse_syscall_log,                           0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 389 "src/core/load-fragment-gperf.gperf"
      {"Service.DisableControllers",                  config_parse_disable_controllers,                   0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 439 "src/core/load-fragment-gperf.gperf"
      {"Socket.Writable",                              config_parse_bool,                                  0,                                  offsetof(Socket, writable)},
#line 177 "src/core/load-fragment-gperf.gperf"
      {"Service.BusName",                              config_parse_bus_name,                              0,                                  offsetof(Service, bus_name)},
#line 987 "src/core/load-fragment-gperf.gperf"
      {"Swap.DynamicUser",                         config_parse_bool,                                  true,                               offsetof(Swap, exec_context.dynamic_user)},
#line 1012 "src/core/load-fragment-gperf.gperf"
      {"Swap.AmbientCapabilities",                 config_parse_capability_set,                        0,                                  offsetof(Swap, exec_context.capability_ambient_set)},
      {(char*)0},
#line 196 "src/core/load-fragment-gperf.gperf"
      {"Service.RootEphemeral",                       config_parse_bool,                                  0,                                  offsetof(Service, exec_context.root_ephemeral)},
      {(char*)0},
#line 390 "src/core/load-fragment-gperf.gperf"
      {"Service.IPAccounting",                        config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.ip_accounting)},
      {(char*)0}, {(char*)0},
#line 770 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogRateLimitBurst",                   config_parse_unsigned,                              0,                                  offsetof(Mount, exec_context.log_ratelimit.burst)},
      {(char*)0}, {(char*)0},
#line 394 "src/core/load-fragment-gperf.gperf"
      {"Service.IPEgressFilterPath",                  config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Service, cgroup_context.ip_filters_egress)},
      {(char*)0},
#line 426 "src/core/load-fragment-gperf.gperf"
      {"Socket.Backlog",                               config_parse_unsigned,                              0,                                  offsetof(Socket, backlog)},
      {(char*)0}, {(char*)0},
#line 1214 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupCPUWeight",                    config_parse_cg_cpu_weight,                         0,                                  offsetof(Slice, cgroup_context.startup_cpu_weight)},
      {(char*)0},
#line 272 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitNPROC",                          config_parse_rlimit,                                RLIMIT_NPROC,                       offsetof(Service, exec_context.rlimit)},
      {(char*)0}, {(char*)0},
#line 1069 "src/core/load-fragment-gperf.gperf"
      {"Swap.PrivateMounts",                       config_parse_tristate,                              0,                                  offsetof(Swap, exec_context.private_mounts)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 835 "src/core/load-fragment-gperf.gperf"
      {"Mount.PrivatePIDs",                         config_parse_private_pids,                          0,                                  offsetof(Mount, exec_context.private_pids)},
      {(char*)0},
#line 663 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupIOWeight",                     config_parse_cg_weight,                             0,                                  offsetof(Socket, cgroup_context.startup_io_weight)},
      {(char*)0},
#line 871 "src/core/load-fragment-gperf.gperf"
      {"Mount.AllowedMemoryNodes",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Mount, cgroup_context.cpuset_mems)},
#line 889 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryMax",                           config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
#line 1216 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupCPUShares",                    config_parse_cpu_shares,                            0,                                  offsetof(Slice, cgroup_context.startup_cpu_shares)},
      {(char*)0},
#line 958 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootHash",                            config_parse_exec_root_hash,                        0,                                  offsetof(Swap, exec_context)},
#line 300 "src/core/load-fragment-gperf.gperf"
      {"Service.IPCNamespacePath",                    config_parse_unit_path_printf,                      0,                                  offsetof(Service, exec_context.ipc_namespace_path)},
#line 1232 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryZSwapMax",                      config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
#line 289 "src/core/load-fragment-gperf.gperf"
      {"Service.BindPaths",                           config_parse_bind_paths,                            0,                                  offsetof(Service, exec_context)},
#line 1206 "src/core/load-fragment-gperf.gperf"
      {"Path.TriggerLimitBurst",                       config_parse_unsigned,                              0,                                  offsetof(Path, trigger_limit.burst)},
#line 1020 "src/core/load-fragment-gperf.gperf"
      {"Swap.SystemCallErrorNumber",               config_parse_syscall_errno,                         0,                                  offsetof(Swap, exec_context)},
#line 972 "src/core/load-fragment-gperf.gperf"
      {"Swap.OOMScoreAdjust",                      config_parse_exec_oom_score_adjust,                 0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 890 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupMemoryMax",                    config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 892 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupMemorySwapMax",                config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
#line 894 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupMemoryZSwapMax",               config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1105 "src/core/load-fragment-gperf.gperf"
      {"Swap.AllowedCPUs",                         config_parse_allowed_cpuset,                        0,                                  offsetof(Swap, cgroup_context.cpuset_cpus)},
      {(char*)0}, {(char*)0},
#line 420 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenNetlink",                         config_parse_socket_listen,                         SOCKET_SOCKET,                      0},
#line 968 "src/core/load-fragment-gperf.gperf"
      {"Swap.Group",                               config_parse_user_group_compat,                     0,                                  offsetof(Swap, exec_context.group)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1066 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogNamespace",                        config_parse_log_namespace,                         0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 848 "src/core/load-fragment-gperf.gperf"
      {"Mount.CacheDirectory",                      config_parse_exec_directories,                      0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_CACHE])},
      {(char*)0},
#line 901 "src/core/load-fragment-gperf.gperf"
      {"Mount.StartupIOWeight",                     config_parse_cg_weight,                             0,                                  offsetof(Mount, cgroup_context.startup_io_weight)},
#line 46 "src/core/load-fragment-gperf.gperf"
      {"Unit.RequisiteOverridable",                    config_parse_obsolete_unit_deps,                    UNIT_REQUISITE,                     0},
      {(char*)0}, {(char*)0},
#line 1353 "src/core/load-fragment-gperf.gperf"
      {"Scope.WatchdogSignal",                      config_parse_signal,                                0,                                  offsetof(Scope, kill_context.watchdog_signal)},
#line 326 "src/core/load-fragment-gperf.gperf"
      {"Service.LoadCredential",                      config_parse_load_credential,                       0,                                  offsetof(Service, exec_context)},
#line 976 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUSchedulingPolicy",                 config_parse_exec_cpu_sched_policy,                 0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 977 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUSchedulingPriority",               config_parse_exec_cpu_sched_prio,                   0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 917 "src/core/load-fragment-gperf.gperf"
      {"Mount.DelegateSubgroup",                    config_parse_delegate_subgroup,                     0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 354 "src/core/load-fragment-gperf.gperf"
      {"Service.DefaultMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Service, cgroup_context)},
#line 1294 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryLow",                           config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 302 "src/core/load-fragment-gperf.gperf"
      {"Service.PrivateNetwork",                      config_parse_bool,                                  0,                                  offsetof(Service, exec_context.private_network)},
#line 107 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertPathExistsGlob",                    config_parse_unit_condition_path,                   CONDITION_PATH_EXISTS_GLOB,         offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1153 "src/core/load-fragment-gperf.gperf"
      {"Swap.DelegateSubgroup",                    config_parse_delegate_subgroup,                     0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 733 "src/core/load-fragment-gperf.gperf"
      {"Mount.SupplementaryGroups",                 config_parse_user_group_strv_compat,                0,                                  offsetof(Mount, exec_context.supplementary_groups)},
      {(char*)0}, {(char*)0},
#line 192 "src/core/load-fragment-gperf.gperf"
      {"Service.RootImagePolicy",                     config_parse_image_policy,                          0,                                  offsetof(Service, exec_context.root_image_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 652 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupMemoryMax",                    config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
#line 955 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootImage",                           config_parse_unit_path_printf,                      true,                               offsetof(Swap, exec_context.root_image)},
      {(char*)0}, {(char*)0},
#line 654 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupMemorySwapMax",                config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
#line 656 "src/core/load-fragment-gperf.gperf"
      {"Socket.StartupMemoryZSwapMax",               config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 184 "src/core/load-fragment-gperf.gperf"
      {"Service.USBFunctionStrings",                   config_parse_unit_path_printf,                      0,                                  offsetof(Service, usb_function_strings)},
      {(char*)0},
#line 1003 "src/core/load-fragment-gperf.gperf"
      {"Swap.SyslogLevelPrefix",                   config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.syslog_level_prefix)},
#line 1022 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryDenyWriteExecute",              config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.memory_deny_write_execute)},
#line 183 "src/core/load-fragment-gperf.gperf"
      {"Service.USBFunctionDescriptors",               config_parse_unit_path_printf,                      0,                                  offsetof(Service, usb_function_descriptors)},
      {(char*)0}, {(char*)0},
#line 1006 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogRateLimitBurst",                   config_parse_unsigned,                              0,                                  offsetof(Swap, exec_context.log_ratelimit.burst)},
      {(char*)0}, {(char*)0},
#line 1164 "src/core/load-fragment-gperf.gperf"
      {"Swap.ManagedOOMPreference",                config_parse_managed_oom_preference,                0,                                  offsetof(Swap, cgroup_context.moom_preference)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 278 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitRTPRIO",                         config_parse_rlimit,                                RLIMIT_RTPRIO,                      offsetof(Service, exec_context.rlimit)},
#line 1224 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryLow",                           config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 305 "src/core/load-fragment-gperf.gperf"
      {"Service.PrivateIPC",                          config_parse_bool,                                  0,                                  offsetof(Service, exec_context.private_ipc)},
      {(char*)0}, {(char*)0},
#line 898 "src/core/load-fragment-gperf.gperf"
      {"Mount.DevicePolicy",                        config_parse_device_policy,                         0,                                  offsetof(Mount, cgroup_context.device_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1101 "src/core/load-fragment-gperf.gperf"
      {"Swap.SmackProcessLabel",                   config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 636 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUWeight",                           config_parse_cg_cpu_weight,                         0,                                  offsetof(Socket, cgroup_context.cpu_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1116 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryAccounting",                    config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.memory_accounting)},
      {(char*)0},
#line 538 "src/core/load-fragment-gperf.gperf"
      {"Socket.AmbientCapabilities",                 config_parse_capability_set,                        0,                                  offsetof(Socket, exec_context.capability_ambient_set)},
      {(char*)0}, {(char*)0},
#line 657 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryZSwapWriteback",                config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.memory_zswap_writeback)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 961 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootEphemeral",                       config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.root_ephemeral)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 878 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUQuota",                            config_parse_cpu_quota,                             0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 833 "src/core/load-fragment-gperf.gperf"
      {"Mount.PrivateMounts",                       config_parse_tristate,                              0,                                  offsetof(Mount, exec_context.private_mounts)},
#line 398 "src/core/load-fragment-gperf.gperf"
      {"Service.ManagedOOMMemoryPressureDurationSec", config_parse_managed_oom_mem_pressure_duration_sec, 0,                                  offsetof(Service, cgroup_context.moom_mem_pressure_duration_usec)},
      {(char*)0},
#line 953 "src/core/load-fragment-gperf.gperf"
      {"Swap.WorkingDirectory",                    config_parse_working_directory,                     0,                                  offsetof(Swap, exec_context)},
#line 213 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUSchedulingResetOnFork",            config_parse_bool,                                  0,                                  offsetof(Service, exec_context.cpu_sched_reset_on_fork)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 240 "src/core/load-fragment-gperf.gperf"
      {"Service.LogRateLimitIntervalSec",             config_parse_sec,                                   0,                                  offsetof(Service, exec_context.log_ratelimit.interval)},
#line 708 "src/core/load-fragment-gperf.gperf"
      {"Mount.Where",                                  config_parse_unit_path_printf,                      0,                                  offsetof(Mount, where)},
      {(char*)0},
#line 1150 "src/core/load-fragment-gperf.gperf"
      {"Swap.TasksAccounting",                     config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.tasks_accounting)},
#line 1134 "src/core/load-fragment-gperf.gperf"
      {"Swap.DevicePolicy",                        config_parse_device_policy,                         0,                                  offsetof(Swap, cgroup_context.device_policy)},
#line 1025 "src/core/load-fragment-gperf.gperf"
      {"Swap.RestrictSUIDSGID",                    config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.restrict_suid_sgid)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 342 "src/core/load-fragment-gperf.gperf"
      {"Service.AllowedMemoryNodes",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Service, cgroup_context.cpuset_mems)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 640 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUQuota",                            config_parse_cpu_quota,                             0,                                  offsetof(Socket, cgroup_context)},
#line 638 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUShares",                           config_parse_cpu_shares,                            0,                                  offsetof(Socket, cgroup_context.cpu_shares)},
      {(char*)0},
#line 242 "src/core/load-fragment-gperf.gperf"
      {"Service.LogExtraFields",                      config_parse_log_extra_fields,                      0,                                  offsetof(Service, exec_context)},
#line 619 "src/core/load-fragment-gperf.gperf"
      {"Socket.ImportCredential",                    config_parse_import_credential,                     0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0},
#line 707 "src/core/load-fragment-gperf.gperf"
      {"Mount.What",                                   config_parse_mount_node,                            0,                                  offsetof(Mount, parameters_fragment.what)},
      {(char*)0}, {(char*)0},
#line 1280 "src/core/load-fragment-gperf.gperf"
      {"Scope.AllowedMemoryNodes",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Scope, cgroup_context.cpuset_mems)},
#line 1298 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryMax",                           config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
#line 514 "src/core/load-fragment-gperf.gperf"
      {"Socket.RemoveIPC",                           config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.remove_ipc)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 769 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogRateLimitIntervalSec",             config_parse_sec,                                   0,                                  offsetof(Mount, exec_context.log_ratelimit.interval)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1299 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupMemoryMax",                    config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1301 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupMemorySwapMax",                config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
#line 1303 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupMemoryZSwapMax",               config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 496 "src/core/load-fragment-gperf.gperf"
      {"Socket.SetLoginEnvironment",                 config_parse_tristate,                              0,                                  offsetof(Socket, exec_context.set_login_environment)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1205 "src/core/load-fragment-gperf.gperf"
      {"Path.TriggerLimitIntervalSec",                 config_parse_sec,                                   0,                                  offsetof(Path, trigger_limit.interval)},
      {(char*)0}, {(char*)0},
#line 887 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryHigh",                          config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
#line 1310 "src/core/load-fragment-gperf.gperf"
      {"Scope.StartupIOWeight",                     config_parse_cg_weight,                             0,                                  offsetof(Scope, cgroup_context.startup_io_weight)},
      {(char*)0},
#line 876 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUShares",                           config_parse_cpu_shares,                            0,                                  offsetof(Mount, cgroup_context.cpu_shares)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1210 "src/core/load-fragment-gperf.gperf"
      {"Slice.AllowedMemoryNodes",                  config_parse_allowed_cpuset,                        0,                                  offsetof(Slice, cgroup_context.cpuset_mems)},
#line 1228 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryMax",                           config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0},
#line 1326 "src/core/load-fragment-gperf.gperf"
      {"Scope.DelegateSubgroup",                    config_parse_delegate_subgroup,                     0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 188 "src/core/load-fragment-gperf.gperf"
      {"Service.WorkingDirectory",                    config_parse_working_directory,                     0,                                  offsetof(Service, exec_context)},
#line 789 "src/core/load-fragment-gperf.gperf"
      {"Mount.RestrictSUIDSGID",                    config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.restrict_suid_sgid)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 222 "src/core/load-fragment-gperf.gperf"
      {"Service.DynamicUser",                         config_parse_bool,                                  true,                               offsetof(Service, exec_context.dynamic_user)},
      {(char*)0},
#line 957 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootImagePolicy",                     config_parse_image_policy,                          0,                                  offsetof(Swap, exec_context.root_image_policy)},
      {(char*)0},
#line 1229 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupMemoryMax",                    config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1231 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupMemorySwapMax",                config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
#line 1233 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupMemoryZSwapMax",               config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 109 "src/core/load-fragment-gperf.gperf"
      {"Unit.AssertPathIsSymbolicLink",                config_parse_unit_condition_path,                   CONDITION_PATH_IS_SYMBOLIC_LINK,    offsetof(Unit, asserts)},
      {(char*)0}, {(char*)0},
#line 655 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryZSwapMax",                      config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0},
#line 423 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenUSBFunction",                     config_parse_socket_listen,                         SOCKET_USB_FUNCTION,                0},
      {(char*)0}, {(char*)0},
#line 371 "src/core/load-fragment-gperf.gperf"
      {"Service.IOWeight",                            config_parse_cg_weight,                             0,                                  offsetof(Service, cgroup_context.io_weight)},
      {(char*)0},
#line 70 "src/core/load-fragment-gperf.gperf"
      {"Unit.FailureActionExitStatus",                 config_parse_exit_status,                           0,                                  offsetof(Unit, failure_action_exit_status)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1240 "src/core/load-fragment-gperf.gperf"
      {"Slice.StartupIOWeight",                     config_parse_cg_weight,                             0,                                  offsetof(Slice, cgroup_context.startup_io_weight)},
#line 68 "src/core/load-fragment-gperf.gperf"
      {"Unit.FailureAction",                           config_parse_emergency_action,                      0,                                  offsetof(Unit, failure_action)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1131 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryZSwapWriteback",                config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.memory_zswap_writeback)},
      {(char*)0}, {(char*)0},
#line 1256 "src/core/load-fragment-gperf.gperf"
      {"Slice.DelegateSubgroup",                    config_parse_delegate_subgroup,                     0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1197 "src/core/load-fragment-gperf.gperf"
      {"Path.PathExists",                              config_parse_path_spec,                             0,                                  0},
      {(char*)0}, {(char*)0},
#line 774 "src/core/load-fragment-gperf.gperf"
      {"Mount.SecureBits",                          config_parse_exec_secure_bits,                      0,                                  offsetof(Mount, exec_context.secure_bits)},
#line 1307 "src/core/load-fragment-gperf.gperf"
      {"Scope.DevicePolicy",                        config_parse_device_policy,                         0,                                  offsetof(Scope, cgroup_context.device_policy)},
#line 1040 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitSIGPENDING",                     config_parse_rlimit,                                RLIMIT_SIGPENDING,                  offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 592 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogNamespace",                        config_parse_log_namespace,                         0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 969 "src/core/load-fragment-gperf.gperf"
      {"Swap.SupplementaryGroups",                 config_parse_user_group_strv_compat,                0,                                  offsetof(Swap, exec_context.supplementary_groups)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1005 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogRateLimitIntervalSec",             config_parse_sec,                                   0,                                  offsetof(Swap, exec_context.log_ratelimit.interval)},
      {(char*)0}, {(char*)0},
#line 182 "src/core/load-fragment-gperf.gperf"
      {"Service.BusPolicy",                            config_parse_warn_compat,                           DISABLED_LEGACY,                    0},
      {(char*)0}, {(char*)0},
#line 821 "src/core/load-fragment-gperf.gperf"
      {"Mount.PrivateTmp",                          config_parse_private_tmp,                           0,                                  offsetof(Mount, exec_context.private_tmp)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1287 "src/core/load-fragment-gperf.gperf"
      {"Scope.CPUQuota",                            config_parse_cpu_quota,                             0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 311 "src/core/load-fragment-gperf.gperf"
      {"Service.BindLogSockets",                      config_parse_tristate,                              0,                                  offsetof(Service, exec_context.bind_log_sockets)},
#line 879 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUQuotaPeriodSec",                   config_parse_sec_def_infinity,                      0,                                  offsetof(Mount, cgroup_context.cpu_quota_period_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1156 "src/core/load-fragment-gperf.gperf"
      {"Swap.IPAddressAllow",                      config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Swap, cgroup_context.ip_address_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 891 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemorySwapMax",                       config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 660 "src/core/load-fragment-gperf.gperf"
      {"Socket.DevicePolicy",                        config_parse_device_policy,                         0,                                  offsetof(Socket, cgroup_context.device_policy)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1237 "src/core/load-fragment-gperf.gperf"
      {"Slice.DevicePolicy",                        config_parse_device_policy,                         0,                                  offsetof(Slice, cgroup_context.device_policy)},
      {(char*)0},
#line 1168 "src/core/load-fragment-gperf.gperf"
      {"Swap.SocketBindDeny",                      config_parse_cgroup_socket_bind,                    0,                                  offsetof(Swap, cgroup_context.socket_bind_deny)},
#line 215 "src/core/load-fragment-gperf.gperf"
      {"Service.NUMAPolicy",                          config_parse_numa_policy,                           0,                                  offsetof(Service, exec_context.numa_policy.type)},
#line 791 "src/core/load-fragment-gperf.gperf"
      {"Mount.LockPersonality",                     config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.lock_personality)},
      {(char*)0},
#line 1058 "src/core/load-fragment-gperf.gperf"
      {"Swap.PrivateDevices",                      config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.private_devices)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1161 "src/core/load-fragment-gperf.gperf"
      {"Swap.ManagedOOMMemoryPressure",            config_parse_managed_oom_mode,                      0,                                  offsetof(Swap, cgroup_context.moom_mem_pressure)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1162 "src/core/load-fragment-gperf.gperf"
      {"Swap.ManagedOOMMemoryPressureLimit",       config_parse_managed_oom_mem_pressure_limit,        0,                                  offsetof(Swap, cgroup_context.moom_mem_pressure_limit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1217 "src/core/load-fragment-gperf.gperf"
      {"Slice.CPUQuota",                            config_parse_cpu_quota,                             0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 207 "src/core/load-fragment-gperf.gperf"
      {"Service.OOMScoreAdjust",                      config_parse_exec_oom_score_adjust,                 0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1033 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitCORE",                           config_parse_rlimit,                                RLIMIT_CORE,                        offsetof(Swap, exec_context.rlimit)},
      {(char*)0},
#line 581 "src/core/load-fragment-gperf.gperf"
      {"Socket.BindReadOnlyPaths",                   config_parse_bind_paths,                            0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 528 "src/core/load-fragment-gperf.gperf"
      {"Socket.SyslogLevel",                         config_parse_log_level,                             0,                                  offsetof(Socket, exec_context.syslog_priority)},
      {(char*)0}, {(char*)0},
#line 239 "src/core/load-fragment-gperf.gperf"
      {"Service.LogLevelMax",                         config_parse_log_level,                             0,                                  offsetof(Service, exec_context.log_level_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 247 "src/core/load-fragment-gperf.gperf"
      {"Service.AmbientCapabilities",                 config_parse_capability_set,                        0,                                  offsetof(Service, exec_context.capability_ambient_set)},
#line 71 "src/core/load-fragment-gperf.gperf"
      {"Unit.SuccessActionExitStatus",                 config_parse_exit_status,                           0,                                  offsetof(Unit, success_action_exit_status)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 69 "src/core/load-fragment-gperf.gperf"
      {"Unit.SuccessAction",                           config_parse_emergency_action,                      0,                                  offsetof(Unit, success_action)},
      {(char*)0}, {(char*)0},
#line 1296 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryHigh",                          config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 1285 "src/core/load-fragment-gperf.gperf"
      {"Scope.CPUShares",                           config_parse_cpu_shares,                            0,                                  offsetof(Scope, cgroup_context.cpu_shares)},
#line 1361 "src/core/load-fragment-gperf.gperf"
      {"Install.UpheldBy",                             NULL,                                               0,                                  0},
      {(char*)0},
#line 880 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryAccounting",                    config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.memory_accounting)},
      {(char*)0},
#line 1129 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemoryZSwapMax",                      config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0},
#line 344 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUAccounting",                       config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.cpu_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1064 "src/core/load-fragment-gperf.gperf"
      {"Swap.NetworkNamespacePath",                config_parse_unit_path_printf,                      0,                                  offsetof(Swap, exec_context.network_namespace_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 831 "src/core/load-fragment-gperf.gperf"
      {"Mount.PrivateNetwork",                      config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.private_network)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1062 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectClock",                        config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.protect_clock)},
#line 395 "src/core/load-fragment-gperf.gperf"
      {"Service.ManagedOOMSwap",                      config_parse_managed_oom_mode,                      0,                                  offsetof(Service, cgroup_context.moom_swap)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 332 "src/core/load-fragment-gperf.gperf"
      {"Service.UtmpIdentifier",                      config_parse_unit_string_printf,                    0,                                  offsetof(Service, exec_context.utmp_id)},
      {(char*)0},
#line 641 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUQuotaPeriodSec",                   config_parse_sec_def_infinity,                      0,                                  offsetof(Socket, cgroup_context.cpu_quota_period_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 174 "src/core/load-fragment-gperf.gperf"
      {"Service.SuccessExitStatus",                    config_parse_set_status,                            0,                                  offsetof(Service, success_status)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1226 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryHigh",                          config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
#line 938 "src/core/load-fragment-gperf.gperf"
      {"Mount.SendSIGKILL",                         config_parse_bool,                                  0,                                  offsetof(Mount, kill_context.send_sigkill)},
      {(char*)0},
#line 1215 "src/core/load-fragment-gperf.gperf"
      {"Slice.CPUShares",                           config_parse_cpu_shares,                            0,                                  offsetof(Slice, cgroup_context.cpu_shares)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1147 "src/core/load-fragment-gperf.gperf"
      {"Swap.BlockIODeviceWeight",                 config_parse_blockio_device_weight,                 0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 223 "src/core/load-fragment-gperf.gperf"
      {"Service.RemoveIPC",                           config_parse_bool,                                  0,                                  offsetof(Service, exec_context.remove_ipc)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 830 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogNamespace",                        config_parse_log_namespace,                         0,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 1114 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUQuota",                            config_parse_cpu_quota,                             0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1112 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUShares",                           config_parse_cpu_shares,                            0,                                  offsetof(Swap, cgroup_context.cpu_shares)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1288 "src/core/load-fragment-gperf.gperf"
      {"Scope.CPUQuotaPeriodSec",                   config_parse_sec_def_infinity,                      0,                                  offsetof(Scope, cgroup_context.cpu_quota_period_usec)},
#line 1127 "src/core/load-fragment-gperf.gperf"
      {"Swap.MemorySwapMax",                       config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 601 "src/core/load-fragment-gperf.gperf"
      {"Socket.MountAPIVFS",                         config_parse_tristate,                              0,                                  offsetof(Socket, exec_context.mount_apivfs)},
#line 1300 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemorySwapMax",                       config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 793 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitCPU",                            config_parse_rlimit,                                RLIMIT_CPU,                         offsetof(Mount, exec_context.rlimit)},
#line 1051 "src/core/load-fragment-gperf.gperf"
      {"Swap.ExecPaths",                           config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.exec_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1354 "src/core/load-fragment-gperf.gperf"
      {"Scope.RuntimeMaxSec",                          config_parse_sec,                                   0,                                  offsetof(Scope, runtime_max_usec)},
      {(char*)0}, {(char*)0},
#line 185 "src/core/load-fragment-gperf.gperf"
      {"Service.OOMPolicy",                            config_parse_oom_policy,                            0,                                  offsetof(Service, oom_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 776 "src/core/load-fragment-gperf.gperf"
      {"Mount.AmbientCapabilities",                 config_parse_capability_set,                        0,                                  offsetof(Mount, exec_context.capability_ambient_set)},
#line 1076 "src/core/load-fragment-gperf.gperf"
      {"Swap.BindLogSockets",                      config_parse_tristate,                              0,                                  offsetof(Swap, exec_context.bind_log_sockets)},
#line 334 "src/core/load-fragment-gperf.gperf"
      {"Service.SELinuxContext",                      config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 752 "src/core/load-fragment-gperf.gperf"
      {"Mount.RemoveIPC",                           config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.remove_ipc)},
      {(char*)0},
#line 472 "src/core/load-fragment-gperf.gperf"
      {"Socket.TriggerLimitBurst",                     config_parse_unsigned,                              0,                                  offsetof(Socket, trigger_limit.burst)},
      {(char*)0},
#line 30 "src/core/load-fragment-gperf.gperf"
      {"Unit.BindTo",                                  config_parse_unit_deps,                             UNIT_BINDS_TO,                      0},
      {(char*)0}, {(char*)0},
#line 1218 "src/core/load-fragment-gperf.gperf"
      {"Slice.CPUQuotaPeriodSec",                   config_parse_sec_def_infinity,                      0,                                  offsetof(Slice, cgroup_context.cpu_quota_period_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 449 "src/core/load-fragment-gperf.gperf"
      {"Socket.ReceiveBuffer",                         config_parse_iec_size,                              0,                                  offsetof(Socket, receive_buffer)},
      {(char*)0},
#line 859 "src/core/load-fragment-gperf.gperf"
      {"Mount.PAMName",                             config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1230 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemorySwapMax",                       config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1163 "src/core/load-fragment-gperf.gperf"
      {"Swap.ManagedOOMMemoryPressureDurationSec", config_parse_managed_oom_mem_pressure_duration_sec, 0,                                  offsetof(Swap, cgroup_context.moom_mem_pressure_duration_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 425 "src/core/load-fragment-gperf.gperf"
      {"Socket.BindIPv6Only",                          config_parse_socket_bind,                           0,                                  offsetof(Socket, bind_ipv6_only)},
#line 746 "src/core/load-fragment-gperf.gperf"
      {"Mount.UMask",                               config_parse_mode,                                  0,                                  offsetof(Mount, exec_context.umask)},
      {(char*)0}, {(char*)0},
#line 393 "src/core/load-fragment-gperf.gperf"
      {"Service.IPIngressFilterPath",                 config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Service, cgroup_context.ip_filters_ingress)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 803 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitLOCKS",                          config_parse_rlimit,                                RLIMIT_LOCKS,                       offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 221 "src/core/load-fragment-gperf.gperf"
      {"Service.UnsetEnvironment",                    config_parse_unset_environ,                         0,                                  offsetof(Service, exec_context.unset_environment)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1289 "src/core/load-fragment-gperf.gperf"
      {"Scope.MemoryAccounting",                    config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.memory_accounting)},
      {(char*)0}, {(char*)0},
#line 1100 "src/core/load-fragment-gperf.gperf"
      {"Swap.AppArmorProfile",                     config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 626 "src/core/load-fragment-gperf.gperf"
      {"Socket.AppArmorProfile",                     config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0},
#line 740 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUSchedulingPolicy",                 config_parse_exec_cpu_sched_policy,                 0,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 741 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUSchedulingPriority",               config_parse_exec_cpu_sched_prio,                   0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1075 "src/core/load-fragment-gperf.gperf"
      {"Swap.MountAPIVFS",                         config_parse_tristate,                              0,                                  offsetof(Swap, exec_context.mount_apivfs)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 508 "src/core/load-fragment-gperf.gperf"
      {"Socket.UMask",                               config_parse_mode,                                  0,                                  offsetof(Socket, exec_context.umask)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 956 "src/core/load-fragment-gperf.gperf"
      {"Swap.RootImageOptions",                    config_parse_root_image_options,                    0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 767 "src/core/load-fragment-gperf.gperf"
      {"Mount.SyslogLevelPrefix",                   config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.syslog_level_prefix)},
      {(char*)0}, {(char*)0},
#line 659 "src/core/load-fragment-gperf.gperf"
      {"Socket.DeviceAllow",                         config_parse_device_allow,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0},
#line 738 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOSchedulingClass",                   config_parse_exec_io_class,                         0,                                  offsetof(Mount, exec_context)},
#line 1180 "src/core/load-fragment-gperf.gperf"
      {"Swap.WatchdogSignal",                      config_parse_signal,                                0,                                  offsetof(Swap, kill_context.watchdog_signal)},
      {(char*)0}, {(char*)0},
#line 1011 "src/core/load-fragment-gperf.gperf"
      {"Swap.CapabilityBoundingSet",               config_parse_capability_set,                        0,                                  offsetof(Swap, exec_context.capability_bounding_set)},
      {(char*)0}, {(char*)0},
#line 736 "src/core/load-fragment-gperf.gperf"
      {"Mount.OOMScoreAdjust",                      config_parse_exec_oom_score_adjust,                 0,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 1347 "src/core/load-fragment-gperf.gperf"
      {"Scope.SendSIGKILL",                         config_parse_bool,                                  0,                                  offsetof(Scope, kill_context.send_sigkill)},
      {(char*)0}, {(char*)0},
#line 164 "src/core/load-fragment-gperf.gperf"
      {"Service.Type",                                 config_parse_service_type,                          0,                                  offsetof(Service, type)},
      {(char*)0},
#line 1219 "src/core/load-fragment-gperf.gperf"
      {"Slice.MemoryAccounting",                    config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.memory_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 427 "src/core/load-fragment-gperf.gperf"
      {"Socket.BindToDevice",                          config_parse_socket_bindtodevice,                   0,                                  0},
      {(char*)0}, {(char*)0},
#line 1183 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnBootSec",                              config_parse_timer,                                 TIMER_BOOT,                         0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1053 "src/core/load-fragment-gperf.gperf"
      {"Swap.ExecSearchPath",                      config_parse_colon_separated_paths,                 0,                                  offsetof(Swap, exec_context.exec_search_path)},
      {(char*)0}, {(char*)0},
#line 1155 "src/core/load-fragment-gperf.gperf"
      {"Swap.IPAccounting",                        config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.ip_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1160 "src/core/load-fragment-gperf.gperf"
      {"Swap.ManagedOOMSwap",                      config_parse_managed_oom_mode,                      0,                                  offsetof(Swap, cgroup_context.moom_swap)},
      {(char*)0},
#line 701 "src/core/load-fragment-gperf.gperf"
      {"Socket.SendSIGHUP",                          config_parse_bool,                                  0,                                  offsetof(Socket, kill_context.send_sighup)},
#line 299 "src/core/load-fragment-gperf.gperf"
      {"Service.NetworkNamespacePath",                config_parse_unit_path_printf,                      0,                                  offsetof(Service, exec_context.network_namespace_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 562 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitAS",                             config_parse_rlimit,                                RLIMIT_AS,                          offsetof(Socket, exec_context.rlimit)},
      {(char*)0},
#line 1115 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUQuotaPeriodSec",                   config_parse_sec_def_infinity,                      0,                                  offsetof(Swap, cgroup_context.cpu_quota_period_usec)},
      {(char*)0},
#line 155 "src/core/load-fragment-gperf.gperf"
      {"Service.TimeoutStopFailureMode",               config_parse_service_timeout_failure_mode,          0,                                  offsetof(Service, timeout_stop_failure_mode)},
#line 154 "src/core/load-fragment-gperf.gperf"
      {"Service.TimeoutStartFailureMode",              config_parse_service_timeout_failure_mode,          0,                                  offsetof(Service, timeout_start_failure_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 946 "src/core/load-fragment-gperf.gperf"
      {"Automount.ExtraOptions",                       config_parse_unit_string_printf,                    0,                                  offsetof(Automount, extra_options)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 500 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOSchedulingClass",                   config_parse_exec_io_class,                         0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0},
#line 1111 "src/core/load-fragment-gperf.gperf"
      {"Swap.StartupCPUWeight",                    config_parse_cg_cpu_weight,                         0,                                  offsetof(Swap, cgroup_context.startup_cpu_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 970 "src/core/load-fragment-gperf.gperf"
      {"Swap.SetLoginEnvironment",                 config_parse_tristate,                              0,                                  offsetof(Swap, exec_context.set_login_environment)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 683 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPAddressDeny",                       config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Socket, cgroup_context.ip_address_deny)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 671 "src/core/load-fragment-gperf.gperf"
      {"Socket.BlockIOWeight",                       config_parse_blockio_weight,                        0,                                  offsetof(Socket, cgroup_context.blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 673 "src/core/load-fragment-gperf.gperf"
      {"Socket.BlockIODeviceWeight",                 config_parse_blockio_device_weight,                 0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 739 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOSchedulingPriority",                config_parse_exec_io_priority,                      0,                                  offsetof(Mount, exec_context)},
      {(char*)0},
#line 932 "src/core/load-fragment-gperf.gperf"
      {"Mount.SocketBindDeny",                      config_parse_cgroup_socket_bind,                    0,                                  offsetof(Mount, cgroup_context.socket_bind_deny)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 578 "src/core/load-fragment-gperf.gperf"
      {"Socket.NoExecPaths",                         config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.no_exec_paths)},
      {(char*)0},
#line 340 "src/core/load-fragment-gperf.gperf"
      {"Service.AllowedCPUs",                         config_parse_allowed_cpuset,                        0,                                  offsetof(Service, cgroup_context.cpuset_cpus)},
#line 248 "src/core/load-fragment-gperf.gperf"
      {"Service.TimerSlackNSec",                      config_parse_nsec,                                  0,                                  offsetof(Service, exec_context.timer_slack_nsec)},
#line 428 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExecStartPre",                          config_parse_exec,                                  SOCKET_EXEC_START_PRE,              offsetof(Socket, exec_command)},
#line 429 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExecStartPost",                         config_parse_exec,                                  SOCKET_EXEC_START_POST,             offsetof(Socket, exec_command)},
#line 471 "src/core/load-fragment-gperf.gperf"
      {"Socket.TriggerLimitIntervalSec",               config_parse_sec,                                   0,                                  offsetof(Socket, trigger_limit.interval)},
#line 268 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitCORE",                           config_parse_rlimit,                                RLIMIT_CORE,                        offsetof(Service, exec_context.rlimit)},
      {(char*)0},
#line 822 "src/core/load-fragment-gperf.gperf"
      {"Mount.PrivateDevices",                      config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.private_devices)},
#line 1194 "src/core/load-fragment-gperf.gperf"
      {"Timer.AccuracySec",                            config_parse_sec,                                   0,                                  offsetof(Timer, accuracy_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 909 "src/core/load-fragment-gperf.gperf"
      {"Mount.BlockIOWeight",                       config_parse_blockio_weight,                        0,                                  offsetof(Mount, cgroup_context.blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 982 "src/core/load-fragment-gperf.gperf"
      {"Swap.UMask",                               config_parse_mode,                                  0,                                  offsetof(Swap, exec_context.umask)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 198 "src/core/load-fragment-gperf.gperf"
      {"Service.ExtensionImages",                     config_parse_extension_images,                      0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 197 "src/core/load-fragment-gperf.gperf"
      {"Service.ExtensionDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.extension_directories)},
      {(char*)0}, {(char*)0},
#line 296 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectKernelLogs",                   config_parse_bool,                                  0,                                  offsetof(Service, exec_context.protect_kernel_logs)},
      {(char*)0}, {(char*)0},
#line 295 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectKernelModules",                config_parse_bool,                                  0,                                  offsetof(Service, exec_context.protect_kernel_modules)},
#line 294 "src/core/load-fragment-gperf.gperf"
      {"Service.ProtectKernelTunables",               config_parse_bool,                                  0,                                  offsetof(Service, exec_context.protect_kernel_tunables)},
#line 577 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExecPaths",                           config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.exec_paths)},
#line 489 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExtensionImages",                     config_parse_extension_images,                      0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 488 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExtensionDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Socket, exec_context.extension_directories)},
#line 176 "src/core/load-fragment-gperf.gperf"
      {"Service.NonBlocking",                          config_parse_bool,                                  0,                                  offsetof(Service, exec_context.non_blocking)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 501 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOSchedulingPriority",                config_parse_exec_io_priority,                      0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 948 "src/core/load-fragment-gperf.gperf"
      {"Automount.TimeoutIdleSec",                     config_parse_sec_fix_0,                             0,                                  offsetof(Automount, timeout_idle_usec)},
#line 430 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExecStopPre",                           config_parse_exec,                                  SOCKET_EXEC_STOP_PRE,               offsetof(Socket, exec_command)},
#line 431 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExecStopPost",                          config_parse_exec,                                  SOCKET_EXEC_STOP_POST,              offsetof(Socket, exec_command)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 506 "src/core/load-fragment-gperf.gperf"
      {"Socket.NUMAPolicy",                          config_parse_numa_policy,                           0,                                  offsetof(Socket, exec_context.numa_policy.type)},
#line 1148 "src/core/load-fragment-gperf.gperf"
      {"Swap.BlockIOReadBandwidth",                config_parse_blockio_bandwidth,                     0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 512 "src/core/load-fragment-gperf.gperf"
      {"Socket.UnsetEnvironment",                    config_parse_unset_environ,                         0,                                  offsetof(Socket, exec_context.unset_environment)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1357 "src/core/load-fragment-gperf.gperf"
      {"Scope.OOMPolicy",                              config_parse_oom_policy,                            0,                                  offsetof(Scope, oom_policy)},
      {(char*)0}, {(char*)0},
#line 569 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitRTPRIO",                         config_parse_rlimit,                                RLIMIT_RTPRIO,                      offsetof(Socket, exec_context.rlimit)},
      {(char*)0},
#line 291 "src/core/load-fragment-gperf.gperf"
      {"Service.TemporaryFileSystem",                 config_parse_temporary_filesystems,                 0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 34 "src/core/load-fragment-gperf.gperf"
      {"Unit.After",                                   config_parse_unit_deps,                             UNIT_AFTER,                         0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 142 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecStart",                            config_parse_exec,                                  SERVICE_EXEC_START,                 offsetof(Service, exec_command)},
      {(char*)0},
#line 150 "src/core/load-fragment-gperf.gperf"
      {"Service.TimeoutSec",                           config_parse_service_timeout,                       0,                                  0},
#line 141 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecStartPre",                         config_parse_exec,                                  SERVICE_EXEC_START_PRE,             offsetof(Service, exec_command)},
#line 144 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecStartPost",                        config_parse_exec,                                  SERVICE_EXEC_START_POST,            offsetof(Service, exec_command)},
      {(char*)0},
#line 152 "src/core/load-fragment-gperf.gperf"
      {"Service.TimeoutStopSec",                       config_parse_sec_fix_0,                             0,                                  offsetof(Service, timeout_stop_usec)},
#line 151 "src/core/load-fragment-gperf.gperf"
      {"Service.TimeoutStartSec",                      config_parse_service_timeout,                       0,                                  0},
      {(char*)0}, {(char*)0},
#line 33 "src/core/load-fragment-gperf.gperf"
      {"Unit.Before",                                  config_parse_unit_deps,                             UNIT_BEFORE,                        0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1133 "src/core/load-fragment-gperf.gperf"
      {"Swap.DeviceAllow",                         config_parse_device_allow,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 36 "src/core/load-fragment-gperf.gperf"
      {"Unit.OnFailure",                               config_parse_unit_deps,                             UNIT_ON_FAILURE,                    0},
#line 1363 "src/core/load-fragment-gperf.gperf"
      {"Install.DefaultInstance",                      NULL,                                               0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 491 "src/core/load-fragment-gperf.gperf"
      {"Socket.MountImages",                         config_parse_mount_images,                          0,                                  offsetof(Socket, exec_context)},
#line 1095 "src/core/load-fragment-gperf.gperf"
      {"Swap.PAMName",                             config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 541 "src/core/load-fragment-gperf.gperf"
      {"Socket.KeyringMode",                         config_parse_exec_keyring_mode,                     0,                                  offsetof(Socket, exec_context.keyring_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 455 "src/core/load-fragment-gperf.gperf"
      {"Socket.FreeBind",                              config_parse_bool,                                  0,                                  offsetof(Socket, free_bind)},
#line 57 "src/core/load-fragment-gperf.gperf"
      {"Unit.OnFailureIsolate",                        config_parse_job_mode_isolate,                      0,                                  offsetof(Unit, on_failure_job_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1043 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitRTPRIO",                         config_parse_rlimit,                                RLIMIT_RTPRIO,                      offsetof(Swap, exec_context.rlimit)},
#line 815 "src/core/load-fragment-gperf.gperf"
      {"Mount.ExecPaths",                           config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.exec_paths)},
#line 276 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitMSGQUEUE",                       config_parse_rlimit,                                RLIMIT_MSGQUEUE,                    offsetof(Service, exec_context.rlimit)},
      {(char*)0},
#line 199 "src/core/load-fragment-gperf.gperf"
      {"Service.ExtensionImagePolicy",                config_parse_image_policy,                          0,                                  offsetof(Service, exec_context.extension_image_policy)},
      {(char*)0},
#line 988 "src/core/load-fragment-gperf.gperf"
      {"Swap.RemoveIPC",                           config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.remove_ipc)},
      {(char*)0},
#line 56 "src/core/load-fragment-gperf.gperf"
      {"Unit.OnFailureJobMode",                        config_parse_job_mode,                              0,                                  offsetof(Unit, on_failure_job_mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1341 "src/core/load-fragment-gperf.gperf"
      {"Scope.SocketBindDeny",                      config_parse_cgroup_socket_bind,                    0,                                  offsetof(Scope, cgroup_context.socket_bind_deny)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 490 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExtensionImagePolicy",                config_parse_image_policy,                          0,                                  offsetof(Socket, exec_context.extension_image_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1136 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOWeight",                            config_parse_cg_weight,                             0,                                  offsetof(Swap, cgroup_context.io_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1318 "src/core/load-fragment-gperf.gperf"
      {"Scope.BlockIOWeight",                       config_parse_blockio_weight,                        0,                                  offsetof(Scope, cgroup_context.blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 635 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUAccounting",                       config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.cpu_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 747 "src/core/load-fragment-gperf.gperf"
      {"Mount.Environment",                         config_parse_environ,                               0,                                  offsetof(Mount, exec_context.environment)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 748 "src/core/load-fragment-gperf.gperf"
      {"Mount.EnvironmentFile",                     config_parse_unit_env_file,                         0,                                  offsetof(Mount, exec_context.environment_files)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1158 "src/core/load-fragment-gperf.gperf"
      {"Swap.IPIngressFilterPath",                 config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Swap, cgroup_context.ip_filters_ingress)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 442 "src/core/load-fragment-gperf.gperf"
      {"Socket.KeepAlive",                             config_parse_bool,                                  0,                                  offsetof(Socket, keep_alive)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1271 "src/core/load-fragment-gperf.gperf"
      {"Slice.SocketBindDeny",                      config_parse_cgroup_socket_bind,                    0,                                  offsetof(Slice, cgroup_context.socket_bind_deny)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1068 "src/core/load-fragment-gperf.gperf"
      {"Swap.PrivateUsers",                        config_parse_private_users,                         0,                                  offsetof(Swap, exec_context.private_users)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 509 "src/core/load-fragment-gperf.gperf"
      {"Socket.Environment",                         config_parse_environ,                               0,                                  offsetof(Socket, exec_context.environment)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 510 "src/core/load-fragment-gperf.gperf"
      {"Socket.EnvironmentFile",                     config_parse_unit_env_file,                         0,                                  offsetof(Socket, exec_context.environment_files)},
      {(char*)0}, {(char*)0},
#line 445 "src/core/load-fragment-gperf.gperf"
      {"Socket.KeepAliveProbes",                       config_parse_unsigned,                              0,                                  offsetof(Socket, keep_alive_cnt)},
      {(char*)0}, {(char*)0},
#line 1248 "src/core/load-fragment-gperf.gperf"
      {"Slice.BlockIOWeight",                       config_parse_blockio_weight,                        0,                                  offsetof(Slice, cgroup_context.blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 702 "src/core/load-fragment-gperf.gperf"
      {"Socket.KillMode",                            config_parse_kill_mode,                             0,                                  offsetof(Socket, kill_context.kill_mode)},
#line 858 "src/core/load-fragment-gperf.gperf"
      {"Mount.TimeoutCleanSec",                     config_parse_sec,                                   0,                                  offsetof(Mount, exec_context.timeout_clean_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 682 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPAddressAllow",                      config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Socket, cgroup_context.ip_address_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 158 "src/core/load-fragment-gperf.gperf"
      {"Service.WatchdogSec",                          config_parse_sec,                                   0,                                  offsetof(Service, watchdog_usec)},
#line 869 "src/core/load-fragment-gperf.gperf"
      {"Mount.AllowedCPUs",                         config_parse_allowed_cpuset,                        0,                                  offsetof(Mount, cgroup_context.cpuset_cpus)},
      {(char*)0}, {(char*)0},
#line 411 "src/core/load-fragment-gperf.gperf"
      {"Service.KillMode",                            config_parse_kill_mode,                             0,                                  offsetof(Service, kill_context.kill_mode)},
      {(char*)0}, {(char*)0},
#line 250 "src/core/load-fragment-gperf.gperf"
      {"Service.KeyringMode",                         config_parse_exec_keyring_mode,                     0,                                  offsetof(Service, exec_context.keyring_mode)},
#line 492 "src/core/load-fragment-gperf.gperf"
      {"Socket.MountImagePolicy",                    config_parse_image_policy,                          0,                                  offsetof(Socket, exec_context.mount_image_policy)},
      {(char*)0},
#line 143 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecReload",                           config_parse_exec,                                  SERVICE_EXEC_RELOAD,                offsetof(Service, exec_command)},
#line 801 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitNPROC",                          config_parse_rlimit,                                RLIMIT_NPROC,                       offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 931 "src/core/load-fragment-gperf.gperf"
      {"Mount.SocketBindAllow",                     config_parse_cgroup_socket_bind,                    0,                                  offsetof(Mount, cgroup_context.socket_bind_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1042 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitNICE",                           config_parse_rlimit,                                RLIMIT_NICE,                        offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 978 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUSchedulingResetOnFork",            config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.cpu_sched_reset_on_fork)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 415 "src/core/load-fragment-gperf.gperf"
      {"Service.WatchdogSignal",                      config_parse_signal,                                0,                                  offsetof(Service, kill_context.watchdog_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 456 "src/core/load-fragment-gperf.gperf"
      {"Socket.Transparent",                           config_parse_bool,                                  0,                                  offsetof(Socket, transparent)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 857 "src/core/load-fragment-gperf.gperf"
      {"Mount.ImportCredential",                    config_parse_import_credential,                     0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 370 "src/core/load-fragment-gperf.gperf"
      {"Service.IOAccounting",                        config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.io_accounting)},
#line 1029 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitCPU",                            config_parse_rlimit,                                RLIMIT_CPU,                         offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 412 "src/core/load-fragment-gperf.gperf"
      {"Service.KillSignal",                          config_parse_signal,                                0,                                  offsetof(Service, kill_context.kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 651 "src/core/load-fragment-gperf.gperf"
      {"Socket.MemoryMax",                           config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 710 "src/core/load-fragment-gperf.gperf"
      {"Mount.Type",                                   config_parse_unit_string_printf,                    0,                                  offsetof(Mount, parameters_fragment.fstype)},
#line 834 "src/core/load-fragment-gperf.gperf"
      {"Mount.PrivateIPC",                          config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.private_ipc)},
      {(char*)0},
#line 1190 "src/core/load-fragment-gperf.gperf"
      {"Timer.WakeSystem",                             config_parse_bool,                                  0,                                  offsetof(Timer, wake_system)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 771 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogExtraFields",                      config_parse_log_extra_fields,                      0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 170 "src/core/load-fragment-gperf.gperf"
      {"Service.RemainAfterExit",                      config_parse_bool,                                  0,                                  offsetof(Service, remain_after_exit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 995 "src/core/load-fragment-gperf.gperf"
      {"Swap.TTYReset",                            config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.tty_reset)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1061 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectKernelLogs",                   config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.protect_kernel_logs)},
#line 292 "src/core/load-fragment-gperf.gperf"
      {"Service.PrivateTmp",                          config_parse_private_tmp,                           0,                                  offsetof(Service, exec_context.private_tmp)},
      {(char*)0},
#line 1060 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectKernelModules",                config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.protect_kernel_modules)},
#line 1059 "src/core/load-fragment-gperf.gperf"
      {"Swap.ProtectKernelTunables",               config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.protect_kernel_tunables)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 902 "src/core/load-fragment-gperf.gperf"
      {"Mount.IODeviceWeight",                      config_parse_io_device_weight,                      0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 469 "src/core/load-fragment-gperf.gperf"
      {"Socket.FileDescriptorName",                    config_parse_fdname,                                0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 173 "src/core/load-fragment-gperf.gperf"
      {"Service.RestartForceExitStatus",               config_parse_set_status,                            0,                                  offsetof(Service, restart_force_status)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 554 "src/core/load-fragment-gperf.gperf"
      {"Socket.RestrictFileSystems",                 config_parse_restrict_filesystems,                  0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0},
#line 32 "src/core/load-fragment-gperf.gperf"
      {"Unit.Conflicts",                               config_parse_unit_deps,                             UNIT_CONFLICTS,                     0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 998 "src/core/load-fragment-gperf.gperf"
      {"Swap.TTYRows",                             config_parse_tty_size,                              0,                                  offsetof(Swap, exec_context.tty_rows)},
      {(char*)0}, {(char*)0},
#line 1052 "src/core/load-fragment-gperf.gperf"
      {"Swap.NoExecPaths",                         config_parse_namespace_path_strv,                   0,                                  offsetof(Swap, exec_context.no_exec_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 681 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPAccounting",                        config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.ip_accounting)},
      {(char*)0},
#line 443 "src/core/load-fragment-gperf.gperf"
      {"Socket.KeepAliveTimeSec",                      config_parse_sec,                                   0,                                  offsetof(Socket, keep_alive_time)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 444 "src/core/load-fragment-gperf.gperf"
      {"Socket.KeepAliveIntervalSec",                  config_parse_sec,                                   0,                                  offsetof(Socket, keep_alive_interval)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 940 "src/core/load-fragment-gperf.gperf"
      {"Mount.KillMode",                            config_parse_kill_mode,                             0,                                  offsetof(Mount, kill_context.kill_mode)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1278 "src/core/load-fragment-gperf.gperf"
      {"Scope.AllowedCPUs",                         config_parse_allowed_cpuset,                        0,                                  offsetof(Scope, cgroup_context.cpuset_cpus)},
      {(char*)0}, {(char*)0},
#line 711 "src/core/load-fragment-gperf.gperf"
      {"Mount.TimeoutSec",                             config_parse_sec_fix_0,                             0,                                  offsetof(Mount, timeout_usec)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1356 "src/core/load-fragment-gperf.gperf"
      {"Scope.TimeoutStopSec",                         config_parse_sec,                                   0,                                  offsetof(Scope, timeout_stop_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 382 "src/core/load-fragment-gperf.gperf"
      {"Service.BlockIODeviceWeight",                 config_parse_blockio_device_weight,                 0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 567 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitMSGQUEUE",                       config_parse_rlimit,                                RLIMIT_MSGQUEUE,                    offsetof(Socket, exec_context.rlimit)},
      {(char*)0},
#line 1340 "src/core/load-fragment-gperf.gperf"
      {"Scope.SocketBindAllow",                     config_parse_cgroup_socket_bind,                    0,                                  offsetof(Scope, cgroup_context.socket_bind_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1065 "src/core/load-fragment-gperf.gperf"
      {"Swap.IPCNamespacePath",                    config_parse_unit_path_printf,                      0,                                  offsetof(Swap, exec_context.ipc_namespace_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 413 "src/core/load-fragment-gperf.gperf"
      {"Service.RestartKillSignal",                   config_parse_signal,                                0,                                  offsetof(Service, kill_context.restart_kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1208 "src/core/load-fragment-gperf.gperf"
      {"Slice.AllowedCPUs",                         config_parse_allowed_cpuset,                        0,                                  offsetof(Slice, cgroup_context.cpuset_cpus)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1198 "src/core/load-fragment-gperf.gperf"
      {"Path.PathExistsGlob",                          config_parse_path_spec,                             0,                                  0},
      {(char*)0},
#line 703 "src/core/load-fragment-gperf.gperf"
      {"Socket.KillSignal",                          config_parse_signal,                                0,                                  offsetof(Socket, kill_context.kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1270 "src/core/load-fragment-gperf.gperf"
      {"Slice.SocketBindAllow",                     config_parse_cgroup_socket_bind,                    0,                                  offsetof(Slice, cgroup_context.socket_bind_allow)},
      {(char*)0}, {(char*)0},
#line 717 "src/core/load-fragment-gperf.gperf"
      {"Mount.WorkingDirectory",                    config_parse_working_directory,                     0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1187 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnClockChange",                          config_parse_bool,                                  0,                                  offsetof(Timer, on_clock_change)},
#line 943 "src/core/load-fragment-gperf.gperf"
      {"Mount.FinalKillSignal",                     config_parse_signal,                                0,                                  offsetof(Mount, kill_context.final_kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 582 "src/core/load-fragment-gperf.gperf"
      {"Socket.TemporaryFileSystem",                 config_parse_temporary_filesystems,                 0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1167 "src/core/load-fragment-gperf.gperf"
      {"Swap.SocketBindAllow",                     config_parse_cgroup_socket_bind,                    0,                                  offsetof(Swap, cgroup_context.socket_bind_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 684 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPIngressFilterPath",                 config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Socket, cgroup_context.ip_filters_ingress)},
      {(char*)0}, {(char*)0},
#line 1087 "src/core/load-fragment-gperf.gperf"
      {"Swap.ConfigurationDirectoryMode",          config_parse_mode,                                  0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION].mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1311 "src/core/load-fragment-gperf.gperf"
      {"Scope.IODeviceWeight",                      config_parse_io_device_weight,                      0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1139 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOReadBandwidthMax",                  config_parse_io_limit,                              0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 385 "src/core/load-fragment-gperf.gperf"
      {"Service.TasksAccounting",                     config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.tasks_accounting)},
      {(char*)0}, {(char*)0},
#line 63 "src/core/load-fragment-gperf.gperf"
      {"Unit.JobTimeoutRebootArgument",                config_parse_reboot_parameter,                      0,                                  offsetof(Unit, job_timeout_reboot_arg)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 921 "src/core/load-fragment-gperf.gperf"
      {"Mount.IPAddressDeny",                       config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Mount, cgroup_context.ip_address_deny)},
      {(char*)0}, {(char*)0},
#line 974 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOSchedulingClass",                   config_parse_exec_io_class,                         0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1349 "src/core/load-fragment-gperf.gperf"
      {"Scope.KillMode",                            config_parse_kill_mode,                             0,                                  offsetof(Scope, kill_context.kill_mode)},
      {(char*)0}, {(char*)0},
#line 1241 "src/core/load-fragment-gperf.gperf"
      {"Slice.IODeviceWeight",                      config_parse_io_device_weight,                      0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 146 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecStopPost",                         config_parse_exec,                                  SERVICE_EXEC_STOP_POST,             offsetof(Service, exec_command)},
      {(char*)0},
#line 980 "src/core/load-fragment-gperf.gperf"
      {"Swap.NUMAPolicy",                          config_parse_numa_policy,                           0,                                  offsetof(Swap, exec_context.numa_policy.type)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 539 "src/core/load-fragment-gperf.gperf"
      {"Socket.TimerSlackNSec",                      config_parse_nsec,                                  0,                                  offsetof(Socket, exec_context.timer_slack_nsec)},
#line 907 "src/core/load-fragment-gperf.gperf"
      {"Mount.IODeviceLatencyTargetSec",            config_parse_io_device_latency,                     0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 555 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitCPU",                            config_parse_rlimit,                                RLIMIT_CPU,                         offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 529 "src/core/load-fragment-gperf.gperf"
      {"Socket.SyslogLevelPrefix",                   config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.syslog_level_prefix)},
      {(char*)0},
#line 1018 "src/core/load-fragment-gperf.gperf"
      {"Swap.SystemCallFilter",                    config_parse_syscall_filter,                        0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 726 "src/core/load-fragment-gperf.gperf"
      {"Mount.ExtensionDirectories",                config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.extension_directories)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 277 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitNICE",                           config_parse_rlimit,                                RLIMIT_NICE,                        offsetof(Service, exec_context.rlimit)},
#line 779 "src/core/load-fragment-gperf.gperf"
      {"Mount.KeyringMode",                         config_parse_exec_keyring_mode,                     0,                                  offsetof(Mount, exec_context.keyring_mode)},
      {(char*)0},
#line 1030 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitFSIZE",                          config_parse_rlimit,                                RLIMIT_FSIZE,                       offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 540 "src/core/load-fragment-gperf.gperf"
      {"Socket.NoNewPrivileges",                     config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.no_new_privileges)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 60 "src/core/load-fragment-gperf.gperf"
      {"Unit.JobTimeoutSec",                           config_parse_job_timeout_sec,                       0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1088 "src/core/load-fragment-gperf.gperf"
      {"Swap.ConfigurationDirectory",              config_parse_exec_directories,                      0,                                  offsetof(Swap, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION])},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 828 "src/core/load-fragment-gperf.gperf"
      {"Mount.NetworkNamespacePath",                config_parse_unit_path_printf,                      0,                                  offsetof(Mount, exec_context.network_namespace_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1352 "src/core/load-fragment-gperf.gperf"
      {"Scope.FinalKillSignal",                     config_parse_signal,                                0,                                  offsetof(Scope, kill_context.final_kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 264 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitCPU",                            config_parse_rlimit,                                RLIMIT_CPU,                         offsetof(Service, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 975 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOSchedulingPriority",                config_parse_exec_io_priority,                      0,                                  offsetof(Swap, exec_context)},
      {(char*)0},
#line 1138 "src/core/load-fragment-gperf.gperf"
      {"Swap.IODeviceWeight",                      config_parse_io_device_weight,                      0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 765 "src/core/load-fragment-gperf.gperf"
      {"Mount.SyslogFacility",                      config_parse_log_facility,                          0,                                  offsetof(Mount, exec_context.syslog_priority)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 670 "src/core/load-fragment-gperf.gperf"
      {"Socket.BlockIOAccounting",                   config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.blockio_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 674 "src/core/load-fragment-gperf.gperf"
      {"Socket.BlockIOReadBandwidth",                config_parse_blockio_bandwidth,                     0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 675 "src/core/load-fragment-gperf.gperf"
      {"Socket.BlockIOWriteBandwidth",               config_parse_blockio_bandwidth,                     0,                                  offsetof(Socket, cgroup_context)},
#line 625 "src/core/load-fragment-gperf.gperf"
      {"Socket.SELinuxContext",                      config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
#line 1330 "src/core/load-fragment-gperf.gperf"
      {"Scope.IPAddressDeny",                       config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Scope, cgroup_context.ip_address_deny)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 478 "src/core/load-fragment-gperf.gperf"
      {"Socket.SELinuxContextFromNet",                 config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1193 "src/core/load-fragment-gperf.gperf"
      {"Timer.DeferReactivation",                      config_parse_bool,                                  0,                                  offsetof(Timer, defer_reactivation)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 383 "src/core/load-fragment-gperf.gperf"
      {"Service.BlockIOReadBandwidth",                config_parse_blockio_bandwidth,                     0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 864 "src/core/load-fragment-gperf.gperf"
      {"Mount.AppArmorProfile",                     config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
#line 908 "src/core/load-fragment-gperf.gperf"
      {"Mount.BlockIOAccounting",                   config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.blockio_accounting)},
      {(char*)0}, {(char*)0},
#line 1316 "src/core/load-fragment-gperf.gperf"
      {"Scope.IODeviceLatencyTargetSec",            config_parse_io_device_latency,                     0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 913 "src/core/load-fragment-gperf.gperf"
      {"Mount.BlockIOWriteBandwidth",               config_parse_blockio_bandwidth,                     0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1159 "src/core/load-fragment-gperf.gperf"
      {"Swap.IPEgressFilterPath",                  config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Swap, cgroup_context.ip_filters_egress)},
#line 743 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUAffinity",                         config_parse_exec_cpu_affinity,                     0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1260 "src/core/load-fragment-gperf.gperf"
      {"Slice.IPAddressDeny",                       config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Slice, cgroup_context.ip_address_deny)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 860 "src/core/load-fragment-gperf.gperf"
      {"Mount.IgnoreSIGPIPE",                       config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.ignore_sigpipe)},
      {(char*)0},
#line 463 "src/core/load-fragment-gperf.gperf"
      {"Socket.TCPCongestion",                         config_parse_string,                                0,                                  offsetof(Socket, tcp_congestion)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 912 "src/core/load-fragment-gperf.gperf"
      {"Mount.BlockIOReadBandwidth",                config_parse_blockio_bandwidth,                     0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 742 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUSchedulingResetOnFork",            config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.cpu_sched_reset_on_fork)},
      {(char*)0}, {(char*)0},
#line 374 "src/core/load-fragment-gperf.gperf"
      {"Service.IOReadBandwidthMax",                  config_parse_io_limit,                              0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1178 "src/core/load-fragment-gperf.gperf"
      {"Swap.RestartKillSignal",                   config_parse_signal,                                0,                                  offsetof(Swap, kill_context.restart_kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1246 "src/core/load-fragment-gperf.gperf"
      {"Slice.IODeviceLatencyTargetSec",            config_parse_io_device_latency,                     0,                                  offsetof(Slice, cgroup_context)},
#line 414 "src/core/load-fragment-gperf.gperf"
      {"Service.FinalKillSignal",                     config_parse_signal,                                0,                                  offsetof(Service, kill_context.final_kill_signal)},
      {(char*)0},
#line 700 "src/core/load-fragment-gperf.gperf"
      {"Socket.SendSIGKILL",                         config_parse_bool,                                  0,                                  offsetof(Socket, kill_context.send_sigkill)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 286 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecPaths",                           config_parse_namespace_path_strv,                   0,                                  offsetof(Service, exec_context.exec_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 507 "src/core/load-fragment-gperf.gperf"
      {"Socket.NUMAMask",                            config_parse_numa_mask,                             0,                                  offsetof(Socket, exec_context.numa_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 867 "src/core/load-fragment-gperf.gperf"
      {"Mount.MemoryKSM",                           config_parse_tristate,                              0,                                  offsetof(Mount, exec_context.memory_ksm)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 329 "src/core/load-fragment-gperf.gperf"
      {"Service.TimeoutCleanSec",                     config_parse_sec,                                   0,                                  offsetof(Service, exec_context.timeout_clean_usec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 288 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecSearchPath",                      config_parse_colon_separated_paths,                 0,                                  offsetof(Service, exec_context.exec_search_path)},
#line 1188 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnTimezoneChange",                       config_parse_bool,                                  0,                                  offsetof(Timer, on_timezone_change)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 140 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecCondition",                        config_parse_exec,                                  SERVICE_EXEC_CONDITION,             offsetof(Service, exec_command)},
      {(char*)0},
#line 217 "src/core/load-fragment-gperf.gperf"
      {"Service.UMask",                               config_parse_mode,                                  0,                                  offsetof(Service, exec_context.umask)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1143 "src/core/load-fragment-gperf.gperf"
      {"Swap.IODeviceLatencyTargetSec",            config_parse_io_device_latency,                     0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1166 "src/core/load-fragment-gperf.gperf"
      {"Swap.BPFProgram",                          config_parse_bpf_foreign_program,                   0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 897 "src/core/load-fragment-gperf.gperf"
      {"Mount.DeviceAllow",                         config_parse_device_allow,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 373 "src/core/load-fragment-gperf.gperf"
      {"Service.IODeviceWeight",                      config_parse_io_device_weight,                      0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 591 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPCNamespacePath",                    config_parse_unit_path_printf,                      0,                                  offsetof(Socket, exec_context.ipc_namespace_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 44 "src/core/load-fragment-gperf.gperf"
      {"Unit.JoinsNamespaceOf",                        config_parse_unit_deps,                             UNIT_JOINS_NAMESPACE_OF,            0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1317 "src/core/load-fragment-gperf.gperf"
      {"Scope.BlockIOAccounting",                   config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.blockio_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1322 "src/core/load-fragment-gperf.gperf"
      {"Scope.BlockIOWriteBandwidth",               config_parse_blockio_bandwidth,                     0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1007 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogExtraFields",                      config_parse_log_extra_fields,                      0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1144 "src/core/load-fragment-gperf.gperf"
      {"Swap.BlockIOAccounting",                   config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.blockio_accounting)},
      {(char*)0},
#line 579 "src/core/load-fragment-gperf.gperf"
      {"Socket.ExecSearchPath",                      config_parse_colon_separated_paths,                 0,                                  offsetof(Socket, exec_context.exec_search_path)},
      {(char*)0},
#line 50 "src/core/load-fragment-gperf.gperf"
      {"Unit.RefuseManualStart",                       config_parse_bool,                                  0,                                  offsetof(Unit, refuse_manual_start)},
      {(char*)0},
#line 1135 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOAccounting",                        config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.io_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 179 "src/core/load-fragment-gperf.gperf"
      {"Service.FileDescriptorStorePreserve",          config_parse_exec_preserve_mode,                    0,                                  offsetof(Service, fd_store_preserve_mode)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1321 "src/core/load-fragment-gperf.gperf"
      {"Scope.BlockIOReadBandwidth",                config_parse_blockio_bandwidth,                     0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0},
#line 768 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogLevelMax",                         config_parse_log_level,                             0,                                  offsetof(Mount, exec_context.log_level_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1247 "src/core/load-fragment-gperf.gperf"
      {"Slice.BlockIOAccounting",                   config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.blockio_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 994 "src/core/load-fragment-gperf.gperf"
      {"Swap.TTYPath",                             config_parse_unit_path_printf,                      0,                                  offsetof(Swap, exec_context.tty_path)},
#line 1252 "src/core/load-fragment-gperf.gperf"
      {"Slice.BlockIOWriteBandwidth",               config_parse_blockio_bandwidth,                     0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 622 "src/core/load-fragment-gperf.gperf"
      {"Socket.IgnoreSIGPIPE",                       config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.ignore_sigpipe)},
      {(char*)0}, {(char*)0},
#line 265 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitFSIZE",                          config_parse_rlimit,                                RLIMIT_FSIZE,                       offsetof(Service, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1099 "src/core/load-fragment-gperf.gperf"
      {"Swap.SELinuxContext",                      config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1251 "src/core/load-fragment-gperf.gperf"
      {"Slice.BlockIOReadBandwidth",                config_parse_blockio_bandwidth,                     0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1070 "src/core/load-fragment-gperf.gperf"
      {"Swap.PrivateIPC",                          config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.private_ipc)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 795 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitDATA",                           config_parse_rlimit,                                RLIMIT_DATA,                        offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 665 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOReadBandwidthMax",                  config_parse_io_limit,                              0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1185 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnUnitActiveSec",                        config_parse_timer,                                 TIMER_UNIT_ACTIVE,                  0},
      {(char*)0},
#line 1151 "src/core/load-fragment-gperf.gperf"
      {"Swap.TasksMax",                            config_parse_tasks_max,                             0,                                  offsetof(Swap, cgroup_context.tasks_max)},
      {(char*)0},
#line 407 "src/core/load-fragment-gperf.gperf"
      {"Service.NFTSet",                              config_parse_cgroup_nft_set,                        NFT_SET_PARSE_CGROUP,               offsetof(Service, cgroup_context)},
#line 432 "src/core/load-fragment-gperf.gperf"
      {"Socket.TimeoutSec",                            config_parse_sec_fix_0,                             0,                                  offsetof(Socket, timeout_usec)},
#line 644 "src/core/load-fragment-gperf.gperf"
      {"Socket.DefaultMemoryMin",                    config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 145 "src/core/load-fragment-gperf.gperf"
      {"Service.ExecStop",                             config_parse_exec,                                  SERVICE_EXEC_STOP,                  offsetof(Service, exec_command)},
      {(char*)0},
#line 1008 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogFilterPatterns",                   config_parse_log_filter_patterns,                   0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1306 "src/core/load-fragment-gperf.gperf"
      {"Scope.DeviceAllow",                         config_parse_device_allow,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 502 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUSchedulingPolicy",                 config_parse_exec_cpu_sched_policy,                 0,                                  offsetof(Socket, exec_context)},
      {(char*)0},
#line 503 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUSchedulingPriority",               config_parse_exec_cpu_sched_prio,                   0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 829 "src/core/load-fragment-gperf.gperf"
      {"Mount.IPCNamespacePath",                    config_parse_unit_path_printf,                      0,                                  offsetof(Mount, exec_context.ipc_namespace_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 882 "src/core/load-fragment-gperf.gperf"
      {"Mount.DefaultMemoryMin",                    config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
#line 498 "src/core/load-fragment-gperf.gperf"
      {"Socket.OOMScoreAdjust",                      config_parse_exec_oom_score_adjust,                 0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 667 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOReadIOPSMax",                       config_parse_io_limit,                              0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0},
#line 863 "src/core/load-fragment-gperf.gperf"
      {"Mount.SELinuxContext",                      config_parse_warn_compat,                           DISABLED_CONFIGURATION,             0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 209 "src/core/load-fragment-gperf.gperf"
      {"Service.IOSchedulingClass",                   config_parse_exec_io_class,                         0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 715 "src/core/load-fragment-gperf.gperf"
      {"Mount.ForceUnmount",                           config_parse_bool,                                  0,                                  offsetof(Mount, force_unmount)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 378 "src/core/load-fragment-gperf.gperf"
      {"Service.IODeviceLatencyTargetSec",            config_parse_io_device_latency,                     0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1236 "src/core/load-fragment-gperf.gperf"
      {"Slice.DeviceAllow",                         config_parse_device_allow,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0},
#line 462 "src/core/load-fragment-gperf.gperf"
      {"Socket.Timestamping",                          config_parse_socket_timestamping,                   0,                                  offsetof(Socket, timestamping)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1110 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUWeight",                           config_parse_cg_cpu_weight,                         0,                                  offsetof(Swap, cgroup_context.cpu_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1145 "src/core/load-fragment-gperf.gperf"
      {"Swap.BlockIOWeight",                       config_parse_blockio_weight,                        0,                                  offsetof(Swap, cgroup_context.blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 797 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitCORE",                           config_parse_rlimit,                                RLIMIT_CORE,                        offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1186 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnUnitInactiveSec",                      config_parse_timer,                                 TIMER_UNIT_INACTIVE,                0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 727 "src/core/load-fragment-gperf.gperf"
      {"Mount.ExtensionImages",                     config_parse_extension_images,                      0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 409 "src/core/load-fragment-gperf.gperf"
      {"Service.SendSIGKILL",                         config_parse_bool,                                  0,                                  offsetof(Service, kill_context.send_sigkill)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 214 "src/core/load-fragment-gperf.gperf"
      {"Service.CPUAffinity",                         config_parse_exec_cpu_affinity,                     0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 884 "src/core/load-fragment-gperf.gperf"
      {"Mount.DefaultStartupMemoryLow",             config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 451 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPTOS",                                 config_parse_ip_tos,                                0,                                  offsetof(Socket, ip_tos)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 210 "src/core/load-fragment-gperf.gperf"
      {"Service.IOSchedulingPriority",                config_parse_exec_io_priority,                      0,                                  offsetof(Service, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 873 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUAccounting",                       config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.cpu_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 273 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitMEMLOCK",                        config_parse_rlimit,                                RLIMIT_MEMLOCK,                     offsetof(Service, exec_context.rlimit)},
#line 43 "src/core/load-fragment-gperf.gperf"
      {"Unit.PartOf",                                  config_parse_unit_deps,                             UNIT_PART_OF,                       0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 806 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitNICE",                           config_parse_rlimit,                                RLIMIT_NICE,                        offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1291 "src/core/load-fragment-gperf.gperf"
      {"Scope.DefaultMemoryMin",                    config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 380 "src/core/load-fragment-gperf.gperf"
      {"Service.BlockIOWeight",                       config_parse_blockio_weight,                        0,                                  offsetof(Service, cgroup_context.blockio_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 153 "src/core/load-fragment-gperf.gperf"
      {"Service.TimeoutAbortSec",                      config_parse_service_timeout_abort,                 0,                                  0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 620 "src/core/load-fragment-gperf.gperf"
      {"Socket.TimeoutCleanSec",                     config_parse_sec,                                   0,                                  offsetof(Socket, exec_context.timeout_clean_usec)},
      {(char*)0}, {(char*)0},
#line 728 "src/core/load-fragment-gperf.gperf"
      {"Mount.ExtensionImagePolicy",                config_parse_image_policy,                          0,                                  offsetof(Mount, exec_context.extension_image_policy)},
      {(char*)0},
#line 1221 "src/core/load-fragment-gperf.gperf"
      {"Slice.DefaultMemoryMin",                    config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 919 "src/core/load-fragment-gperf.gperf"
      {"Mount.IPAccounting",                        config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.ip_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 999 "src/core/load-fragment-gperf.gperf"
      {"Swap.TTYColumns",                          config_parse_tty_size,                              0,                                  offsetof(Swap, exec_context.tty_cols)},
      {(char*)0},
#line 180 "src/core/load-fragment-gperf.gperf"
      {"Service.NotifyAccess",                         config_parse_notify_access,                         0,                                  offsetof(Service, notify_access)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 677 "src/core/load-fragment-gperf.gperf"
      {"Socket.TasksMax",                            config_parse_tasks_max,                             0,                                  offsetof(Socket, cgroup_context.tasks_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1149 "src/core/load-fragment-gperf.gperf"
      {"Swap.BlockIOWriteBandwidth",               config_parse_blockio_bandwidth,                     0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1182 "src/core/load-fragment-gperf.gperf"
      {"Timer.OnActiveSec",                            config_parse_timer,                                 TIMER_ACTIVE,                       0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1041 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitMSGQUEUE",                       config_parse_rlimit,                                RLIMIT_MSGQUEUE,                    offsetof(Swap, exec_context.rlimit)},
#line 996 "src/core/load-fragment-gperf.gperf"
      {"Swap.TTYVHangup",                          config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.tty_vhangup)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1293 "src/core/load-fragment-gperf.gperf"
      {"Scope.DefaultStartupMemoryLow",             config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
#line 1067 "src/core/load-fragment-gperf.gperf"
      {"Swap.PrivateNetwork",                      config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.private_network)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 911 "src/core/load-fragment-gperf.gperf"
      {"Mount.BlockIODeviceWeight",                 config_parse_blockio_device_weight,                 0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 923 "src/core/load-fragment-gperf.gperf"
      {"Mount.IPEgressFilterPath",                  config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Mount, cgroup_context.ip_filters_egress)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1282 "src/core/load-fragment-gperf.gperf"
      {"Scope.CPUAccounting",                       config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.cpu_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 805 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitMSGQUEUE",                       config_parse_rlimit,                                RLIMIT_MSGQUEUE,                    offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 839 "src/core/load-fragment-gperf.gperf"
      {"Mount.MountAPIVFS",                         config_parse_tristate,                              0,                                  offsetof(Mount, exec_context.mount_apivfs)},
#line 669 "src/core/load-fragment-gperf.gperf"
      {"Socket.IODeviceLatencyTargetSec",            config_parse_io_device_latency,                     0,                                  offsetof(Socket, cgroup_context)},
#line 1223 "src/core/load-fragment-gperf.gperf"
      {"Slice.DefaultStartupMemoryLow",             config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 874 "src/core/load-fragment-gperf.gperf"
      {"Mount.CPUWeight",                           config_parse_cg_cpu_weight,                         0,                                  offsetof(Mount, cgroup_context.cpu_weight)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 941 "src/core/load-fragment-gperf.gperf"
      {"Mount.KillSignal",                          config_parse_signal,                                0,                                  offsetof(Mount, kill_context.kill_signal)},
#line 1192 "src/core/load-fragment-gperf.gperf"
      {"Timer.FixedRandomDelay",                       config_parse_bool,                                  0,                                  offsetof(Timer, fixed_random_delay)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 645 "src/core/load-fragment-gperf.gperf"
      {"Socket.DefaultMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 51 "src/core/load-fragment-gperf.gperf"
      {"Unit.RefuseManualStop",                        config_parse_bool,                                  0,                                  offsetof(Unit, refuse_manual_stop)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 646 "src/core/load-fragment-gperf.gperf"
      {"Socket.DefaultStartupMemoryLow",             config_parse_memory_limit,                          0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 661 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOAccounting",                        config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.io_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1212 "src/core/load-fragment-gperf.gperf"
      {"Slice.CPUAccounting",                       config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.cpu_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 563 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitNPROC",                          config_parse_rlimit,                                RLIMIT_NPROC,                       offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 883 "src/core/load-fragment-gperf.gperf"
      {"Mount.DefaultMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 744 "src/core/load-fragment-gperf.gperf"
      {"Mount.NUMAPolicy",                          config_parse_numa_policy,                           0,                                  offsetof(Mount, exec_context.numa_policy.type)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1328 "src/core/load-fragment-gperf.gperf"
      {"Scope.IPAccounting",                        config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.ip_accounting)},
      {(char*)0},
#line 920 "src/core/load-fragment-gperf.gperf"
      {"Mount.IPAddressAllow",                      config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Mount, cgroup_context.ip_address_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 61 "src/core/load-fragment-gperf.gperf"
      {"Unit.JobRunningTimeoutSec",                    config_parse_job_running_timeout_sec,               0,                                  0},
      {(char*)0}, {(char*)0},
#line 1258 "src/core/load-fragment-gperf.gperf"
      {"Slice.IPAccounting",                        config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.ip_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 777 "src/core/load-fragment-gperf.gperf"
      {"Mount.TimerSlackNSec",                      config_parse_nsec,                                  0,                                  offsetof(Mount, exec_context.timer_slack_nsec)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 570 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitRTTIME",                         config_parse_rlimit,                                RLIMIT_RTTIME,                      offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1320 "src/core/load-fragment-gperf.gperf"
      {"Scope.BlockIODeviceWeight",                 config_parse_blockio_device_weight,                 0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1332 "src/core/load-fragment-gperf.gperf"
      {"Scope.IPEgressFilterPath",                  config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Scope, cgroup_context.ip_filters_egress)},
      {(char*)0},
#line 1141 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOReadIOPSMax",                       config_parse_io_limit,                              0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 53 "src/core/load-fragment-gperf.gperf"
      {"Unit.DefaultDependencies",                     config_parse_bool,                                  0,                                  offsetof(Unit, default_dependencies)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1283 "src/core/load-fragment-gperf.gperf"
      {"Scope.CPUWeight",                           config_parse_cg_cpu_weight,                         0,                                  offsetof(Scope, cgroup_context.cpu_weight)},
      {(char*)0},
#line 1250 "src/core/load-fragment-gperf.gperf"
      {"Slice.BlockIODeviceWeight",                 config_parse_blockio_device_weight,                 0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0},
#line 1350 "src/core/load-fragment-gperf.gperf"
      {"Scope.KillSignal",                          config_parse_signal,                                0,                                  offsetof(Scope, kill_context.kill_signal)},
      {(char*)0},
#line 1262 "src/core/load-fragment-gperf.gperf"
      {"Slice.IPEgressFilterPath",                  config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Slice, cgroup_context.ip_filters_egress)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 379 "src/core/load-fragment-gperf.gperf"
      {"Service.BlockIOAccounting",                   config_parse_bool,                                  0,                                  offsetof(Service, cgroup_context.blockio_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1292 "src/core/load-fragment-gperf.gperf"
      {"Scope.DefaultMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Scope, cgroup_context)},
#line 662 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOWeight",                            config_parse_cg_weight,                             0,                                  offsetof(Socket, cgroup_context.io_weight)},
      {(char*)0}, {(char*)0},
#line 1118 "src/core/load-fragment-gperf.gperf"
      {"Swap.DefaultMemoryMin",                    config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
#line 1213 "src/core/load-fragment-gperf.gperf"
      {"Slice.CPUWeight",                           config_parse_cg_cpu_weight,                         0,                                  offsetof(Slice, cgroup_context.cpu_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 804 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitSIGPENDING",                     config_parse_rlimit,                                RLIMIT_SIGPENDING,                  offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0},
#line 62 "src/core/load-fragment-gperf.gperf"
      {"Unit.JobTimeoutAction",                        config_parse_emergency_action,                      0,                                  offsetof(Unit, job_timeout_action)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1329 "src/core/load-fragment-gperf.gperf"
      {"Scope.IPAddressAllow",                      config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Scope, cgroup_context.ip_address_allow)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 530 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogLevelMax",                         config_parse_log_level,                             0,                                  offsetof(Socket, exec_context.log_level_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1222 "src/core/load-fragment-gperf.gperf"
      {"Slice.DefaultMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 817 "src/core/load-fragment-gperf.gperf"
      {"Mount.ExecSearchPath",                      config_parse_colon_separated_paths,                 0,                                  offsetof(Mount, exec_context.exec_search_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1259 "src/core/load-fragment-gperf.gperf"
      {"Slice.IPAddressAllow",                      config_parse_in_addr_prefixes,                      AF_UNSPEC,                          offsetof(Slice, cgroup_context.ip_address_allow)},
      {(char*)0},
#line 1031 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitDATA",                           config_parse_rlimit,                                RLIMIT_DATA,                        offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 186 "src/core/load-fragment-gperf.gperf"
      {"Service.OpenFile",                             config_parse_open_file,                             0,                                  offsetof(Service, open_files)},
      {(char*)0}, {(char*)0},
#line 1109 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUAccounting",                       config_parse_bool,                                  0,                                  offsetof(Swap, cgroup_context.cpu_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 533 "src/core/load-fragment-gperf.gperf"
      {"Socket.LogExtraFields",                      config_parse_log_extra_fields,                      0,                                  offsetof(Socket, exec_context)},
#line 676 "src/core/load-fragment-gperf.gperf"
      {"Socket.TasksAccounting",                     config_parse_bool,                                  0,                                  offsetof(Socket, cgroup_context.tasks_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 664 "src/core/load-fragment-gperf.gperf"
      {"Socket.IODeviceWeight",                      config_parse_io_device_weight,                      0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 794 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitFSIZE",                          config_parse_rlimit,                                RLIMIT_FSIZE,                       offsetof(Mount, exec_context.rlimit)},
#line 772 "src/core/load-fragment-gperf.gperf"
      {"Mount.LogFilterPatterns",                   config_parse_log_filter_patterns,                   0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1038 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitMEMLOCK",                        config_parse_rlimit,                                RLIMIT_MEMLOCK,                     offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 557 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitDATA",                           config_parse_rlimit,                                RLIMIT_DATA,                        offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1004 "src/core/load-fragment-gperf.gperf"
      {"Swap.LogLevelMax",                         config_parse_log_level,                             0,                                  offsetof(Swap, exec_context.log_level_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 900 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOWeight",                            config_parse_cg_weight,                             0,                                  offsetof(Mount, cgroup_context.io_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 816 "src/core/load-fragment-gperf.gperf"
      {"Mount.NoExecPaths",                         config_parse_namespace_path_strv,                   0,                                  offsetof(Mount, exec_context.no_exec_paths)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 331 "src/core/load-fragment-gperf.gperf"
      {"Service.IgnoreSIGPIPE",                       config_parse_bool,                                  0,                                  offsetof(Service, exec_context.ignore_sigpipe)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 692 "src/core/load-fragment-gperf.gperf"
      {"Socket.BPFProgram",                          config_parse_bpf_foreign_program,                   0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 851 "src/core/load-fragment-gperf.gperf"
      {"Mount.ConfigurationDirectoryMode",          config_parse_mode,                                  0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION].mode)},
      {(char*)0},
#line 438 "src/core/load-fragment-gperf.gperf"
      {"Socket.FlushPending",                          config_parse_bool,                                  0,                                  offsetof(Socket, flush_pending)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 600 "src/core/load-fragment-gperf.gperf"
      {"Socket.MountFlags",                          config_parse_exec_mount_propagation_flag,           0,                                  offsetof(Socket, exec_context.mount_propagation_flag)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 499 "src/core/load-fragment-gperf.gperf"
      {"Socket.CoredumpFilter",                      config_parse_exec_coredump_filter,                  0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1120 "src/core/load-fragment-gperf.gperf"
      {"Swap.DefaultStartupMemoryLow",             config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 216 "src/core/load-fragment-gperf.gperf"
      {"Service.NUMAMask",                            config_parse_numa_mask,                             0,                                  offsetof(Service, exec_context.numa_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1032 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitSTACK",                          config_parse_rlimit,                                RLIMIT_STACK,                       offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 376 "src/core/load-fragment-gperf.gperf"
      {"Service.IOReadIOPSMax",                       config_parse_io_limit,                              0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 852 "src/core/load-fragment-gperf.gperf"
      {"Mount.ConfigurationDirectory",              config_parse_exec_directories,                      0,                                  offsetof(Mount, exec_context.directories[EXEC_DIRECTORY_CONFIGURATION])},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1309 "src/core/load-fragment-gperf.gperf"
      {"Scope.IOWeight",                            config_parse_cg_weight,                             0,                                  offsetof(Scope, cgroup_context.io_weight)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 377 "src/core/load-fragment-gperf.gperf"
      {"Service.IOWriteIOPSMax",                      config_parse_io_limit,                              0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1239 "src/core/load-fragment-gperf.gperf"
      {"Slice.IOWeight",                            config_parse_cg_weight,                             0,                                  offsetof(Slice, cgroup_context.io_weight)},
#line 1057 "src/core/load-fragment-gperf.gperf"
      {"Swap.PrivateTmp",                          config_parse_private_tmp,                           0,                                  offsetof(Swap, exec_context.private_tmp)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1119 "src/core/load-fragment-gperf.gperf"
      {"Swap.DefaultMemoryLow",                    config_parse_memory_limit,                          0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0},
#line 375 "src/core/load-fragment-gperf.gperf"
      {"Service.IOWriteBandwidthMax",                 config_parse_io_limit,                              0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 504 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUSchedulingResetOnFork",            config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.cpu_sched_reset_on_fork)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 384 "src/core/load-fragment-gperf.gperf"
      {"Service.BlockIOWriteBandwidth",               config_parse_blockio_bandwidth,                     0,                                  offsetof(Service, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 266 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitDATA",                           config_parse_rlimit,                                RLIMIT_DATA,                        offsetof(Service, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 745 "src/core/load-fragment-gperf.gperf"
      {"Mount.NUMAMask",                            config_parse_numa_mask,                             0,                                  offsetof(Mount, exec_context.numa_policy)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 915 "src/core/load-fragment-gperf.gperf"
      {"Mount.TasksMax",                            config_parse_tasks_max,                             0,                                  offsetof(Mount, cgroup_context.tasks_max)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 452 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPTTL",                                 config_parse_int,                                   0,                                  offsetof(Socket, ip_ttl)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 799 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitNOFILE",                         config_parse_rlimit,                                RLIMIT_NOFILE,                      offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 178 "src/core/load-fragment-gperf.gperf"
      {"Service.FileDescriptorStoreMax",               config_parse_unsigned,                              0,                                  offsetof(Service, n_fd_store_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1096 "src/core/load-fragment-gperf.gperf"
      {"Swap.IgnoreSIGPIPE",                       config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.ignore_sigpipe)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 386 "src/core/load-fragment-gperf.gperf"
      {"Service.TasksMax",                            config_parse_tasks_max,                             0,                                  offsetof(Service, cgroup_context.tasks_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 267 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitSTACK",                          config_parse_rlimit,                                RLIMIT_STACK,                       offsetof(Service, exec_context.rlimit)},
      {(char*)0},
#line 903 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOReadBandwidthMax",                  config_parse_io_limit,                              0,                                  offsetof(Mount, cgroup_context)},
#line 162 "src/core/load-fragment-gperf.gperf"
      {"Service.FailureAction",                        config_parse_emergency_action,                      0,                                  offsetof(Unit, failure_action)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 558 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitSTACK",                          config_parse_rlimit,                                RLIMIT_STACK,                       offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1324 "src/core/load-fragment-gperf.gperf"
      {"Scope.TasksMax",                            config_parse_tasks_max,                             0,                                  offsetof(Scope, cgroup_context.tasks_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 904 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOWriteBandwidthMax",                 config_parse_io_limit,                              0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 419 "src/core/load-fragment-gperf.gperf"
      {"Socket.ListenFIFO",                            config_parse_socket_listen,                         SOCKET_FIFO,                        0},
      {(char*)0},
#line 561 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitNOFILE",                         config_parse_rlimit,                                RLIMIT_NOFILE,                      offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 446 "src/core/load-fragment-gperf.gperf"
      {"Socket.DeferAcceptSec",                        config_parse_sec,                                   0,                                  offsetof(Socket, defer_accept)},
      {(char*)0},
#line 1254 "src/core/load-fragment-gperf.gperf"
      {"Slice.TasksMax",                            config_parse_tasks_max,                             0,                                  offsetof(Slice, cgroup_context.tasks_max)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 905 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOReadIOPSMax",                       config_parse_io_limit,                              0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 666 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOWriteBandwidthMax",                 config_parse_io_limit,                              0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 906 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOWriteIOPSMax",                      config_parse_io_limit,                              0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 230 "src/core/load-fragment-gperf.gperf"
      {"Service.TTYReset",                            config_parse_bool,                                  0,                                  offsetof(Service, exec_context.tty_reset)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 279 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitRTTIME",                         config_parse_rlimit,                                RLIMIT_RTTIME,                      offsetof(Service, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 899 "src/core/load-fragment-gperf.gperf"
      {"Mount.IOAccounting",                        config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.io_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 233 "src/core/load-fragment-gperf.gperf"
      {"Service.TTYRows",                             config_parse_tty_size,                              0,                                  offsetof(Service, exec_context.tty_rows)},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 565 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitLOCKS",                          config_parse_rlimit,                                RLIMIT_LOCKS,                       offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 521 "src/core/load-fragment-gperf.gperf"
      {"Socket.TTYReset",                            config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.tty_reset)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 914 "src/core/load-fragment-gperf.gperf"
      {"Mount.TasksAccounting",                     config_parse_bool,                                  0,                                  offsetof(Mount, cgroup_context.tasks_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1312 "src/core/load-fragment-gperf.gperf"
      {"Scope.IOReadBandwidthMax",                  config_parse_io_limit,                              0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1313 "src/core/load-fragment-gperf.gperf"
      {"Scope.IOWriteBandwidthMax",                 config_parse_io_limit,                              0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1242 "src/core/load-fragment-gperf.gperf"
      {"Slice.IOReadBandwidthMax",                  config_parse_io_limit,                              0,                                  offsetof(Slice, cgroup_context)},
#line 1174 "src/core/load-fragment-gperf.gperf"
      {"Swap.SendSIGKILL",                         config_parse_bool,                                  0,                                  offsetof(Swap, kill_context.send_sigkill)},
#line 505 "src/core/load-fragment-gperf.gperf"
      {"Socket.CPUAffinity",                         config_parse_exec_cpu_affinity,                     0,                                  offsetof(Socket, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1314 "src/core/load-fragment-gperf.gperf"
      {"Scope.IOReadIOPSMax",                       config_parse_io_limit,                              0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1243 "src/core/load-fragment-gperf.gperf"
      {"Slice.IOWriteBandwidthMax",                 config_parse_io_limit,                              0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1315 "src/core/load-fragment-gperf.gperf"
      {"Scope.IOWriteIOPSMax",                      config_parse_io_limit,                              0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1097 "src/core/load-fragment-gperf.gperf"
      {"Swap.UtmpIdentifier",                      config_parse_unit_string_printf,                    0,                                  offsetof(Swap, exec_context.utmp_id)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 54 "src/core/load-fragment-gperf.gperf"
      {"Unit.SurviveFinalKillSignal",                  config_parse_bool,                                  0,                                  offsetof(Unit, survive_final_kill_signal)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1244 "src/core/load-fragment-gperf.gperf"
      {"Slice.IOReadIOPSMax",                       config_parse_io_limit,                              0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 559 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitCORE",                           config_parse_rlimit,                                RLIMIT_CORE,                        offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0},
#line 1308 "src/core/load-fragment-gperf.gperf"
      {"Scope.IOAccounting",                        config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.io_accounting)},
      {(char*)0}, {(char*)0},
#line 1245 "src/core/load-fragment-gperf.gperf"
      {"Slice.IOWriteIOPSMax",                      config_parse_io_limit,                              0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 165 "src/core/load-fragment-gperf.gperf"
      {"Service.ExitType",                             config_parse_service_exit_type,                     0,                                  offsetof(Service, exit_type)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 564 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitMEMLOCK",                        config_parse_rlimit,                                RLIMIT_MEMLOCK,                     offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 759 "src/core/load-fragment-gperf.gperf"
      {"Mount.TTYReset",                            config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.tty_reset)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1323 "src/core/load-fragment-gperf.gperf"
      {"Scope.TasksAccounting",                     config_parse_bool,                                  0,                                  offsetof(Scope, cgroup_context.tasks_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1238 "src/core/load-fragment-gperf.gperf"
      {"Slice.IOAccounting",                        config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.io_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 761 "src/core/load-fragment-gperf.gperf"
      {"Mount.TTYVTDisallocate",                    config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.tty_vt_disallocate)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 762 "src/core/load-fragment-gperf.gperf"
      {"Mount.TTYRows",                             config_parse_tty_size,                              0,                                  offsetof(Mount, exec_context.tty_rows)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1253 "src/core/load-fragment-gperf.gperf"
      {"Slice.TasksAccounting",                     config_parse_bool,                                  0,                                  offsetof(Slice, cgroup_context.tasks_accounting)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 930 "src/core/load-fragment-gperf.gperf"
      {"Mount.BPFProgram",                          config_parse_bpf_foreign_program,                   0,                                  offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 568 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitNICE",                           config_parse_rlimit,                                RLIMIT_NICE,                        offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 525 "src/core/load-fragment-gperf.gperf"
      {"Socket.TTYColumns",                          config_parse_tty_size,                              0,                                  offsetof(Socket, exec_context.tty_cols)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 234 "src/core/load-fragment-gperf.gperf"
      {"Service.TTYColumns",                          config_parse_tty_size,                              0,                                  offsetof(Service, exec_context.tty_cols)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1140 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOWriteBandwidthMax",                 config_parse_io_limit,                              0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 270 "src/core/load-fragment-gperf.gperf"
      {"Service.LimitNOFILE",                         config_parse_rlimit,                                RLIMIT_NOFILE,                      offsetof(Service, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1142 "src/core/load-fragment-gperf.gperf"
      {"Swap.IOWriteIOPSMax",                      config_parse_io_limit,                              0,                                  offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 524 "src/core/load-fragment-gperf.gperf"
      {"Socket.TTYRows",                             config_parse_tty_size,                              0,                                  offsetof(Socket, exec_context.tty_rows)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1339 "src/core/load-fragment-gperf.gperf"
      {"Scope.BPFProgram",                          config_parse_bpf_foreign_program,                   0,                                  offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 981 "src/core/load-fragment-gperf.gperf"
      {"Swap.NUMAMask",                            config_parse_numa_mask,                             0,                                  offsetof(Swap, exec_context.numa_policy)},
      {(char*)0}, {(char*)0},
#line 1269 "src/core/load-fragment-gperf.gperf"
      {"Slice.BPFProgram",                          config_parse_bpf_foreign_program,                   0,                                  offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 808 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitRTTIME",                         config_parse_rlimit,                                RLIMIT_RTTIME,                      offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 997 "src/core/load-fragment-gperf.gperf"
      {"Swap.TTYVTDisallocate",                    config_parse_bool,                                  0,                                  offsetof(Swap, exec_context.tty_vt_disallocate)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 556 "src/core/load-fragment-gperf.gperf"
      {"Socket.LimitFSIZE",                          config_parse_rlimit,                                RLIMIT_FSIZE,                       offsetof(Socket, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 523 "src/core/load-fragment-gperf.gperf"
      {"Socket.TTYVTDisallocate",                    config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.tty_vt_disallocate)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 229 "src/core/load-fragment-gperf.gperf"
      {"Service.TTYPath",                             config_parse_unit_path_printf,                      0,                                  offsetof(Service, exec_context.tty_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 520 "src/core/load-fragment-gperf.gperf"
      {"Socket.TTYPath",                             config_parse_unit_path_printf,                      0,                                  offsetof(Socket, exec_context.tty_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 1172 "src/core/load-fragment-gperf.gperf"
      {"Swap.NFTSet",                              config_parse_cgroup_nft_set,                        NFT_SET_PARSE_CGROUP,               offsetof(Swap, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 760 "src/core/load-fragment-gperf.gperf"
      {"Mount.TTYVHangup",                          config_parse_bool,                                  0,                                  offsetof(Mount, exec_context.tty_vhangup)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 979 "src/core/load-fragment-gperf.gperf"
      {"Swap.CPUAffinity",                         config_parse_exec_cpu_affinity,                     0,                                  offsetof(Swap, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 705 "src/core/load-fragment-gperf.gperf"
      {"Socket.FinalKillSignal",                     config_parse_signal,                                0,                                  offsetof(Socket, kill_context.final_kill_signal)},
      {(char*)0},
#line 807 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitRTPRIO",                         config_parse_rlimit,                                RLIMIT_RTPRIO,                      offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 922 "src/core/load-fragment-gperf.gperf"
      {"Mount.IPIngressFilterPath",                 config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Mount, cgroup_context.ip_filters_ingress)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 668 "src/core/load-fragment-gperf.gperf"
      {"Socket.IOWriteIOPSMax",                      config_parse_io_limit,                              0,                                  offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1331 "src/core/load-fragment-gperf.gperf"
      {"Scope.IPIngressFilterPath",                 config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Scope, cgroup_context.ip_filters_ingress)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1044 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitRTTIME",                         config_parse_rlimit,                                RLIMIT_RTTIME,                      offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 231 "src/core/load-fragment-gperf.gperf"
      {"Service.TTYVHangup",                          config_parse_bool,                                  0,                                  offsetof(Service, exec_context.tty_vhangup)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 1261 "src/core/load-fragment-gperf.gperf"
      {"Slice.IPIngressFilterPath",                 config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Slice, cgroup_context.ip_filters_ingress)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 698 "src/core/load-fragment-gperf.gperf"
      {"Socket.NFTSet",                              config_parse_cgroup_nft_set,                        NFT_SET_PARSE_CGROUP,               offsetof(Socket, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 522 "src/core/load-fragment-gperf.gperf"
      {"Socket.TTYVHangup",                          config_parse_bool,                                  0,                                  offsetof(Socket, exec_context.tty_vhangup)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0},
#line 936 "src/core/load-fragment-gperf.gperf"
      {"Mount.NFTSet",                              config_parse_cgroup_nft_set,                        NFT_SET_PARSE_CGROUP,               offsetof(Mount, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 820 "src/core/load-fragment-gperf.gperf"
      {"Mount.TemporaryFileSystem",                 config_parse_temporary_filesystems,                 0,                                  offsetof(Mount, exec_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 685 "src/core/load-fragment-gperf.gperf"
      {"Socket.IPEgressFilterPath",                  config_parse_ip_filter_bpf_progs,                   0,                                  offsetof(Socket, cgroup_context.ip_filters_egress)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 1035 "src/core/load-fragment-gperf.gperf"
      {"Swap.LimitNOFILE",                         config_parse_rlimit,                                RLIMIT_NOFILE,                      offsetof(Swap, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1345 "src/core/load-fragment-gperf.gperf"
      {"Scope.NFTSet",                              config_parse_cgroup_nft_set,                        NFT_SET_PARSE_CGROUP,               offsetof(Scope, cgroup_context)},
      {(char*)0}, {(char*)0},
#line 802 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitMEMLOCK",                        config_parse_rlimit,                                RLIMIT_MEMLOCK,                     offsetof(Mount, exec_context.rlimit)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 758 "src/core/load-fragment-gperf.gperf"
      {"Mount.TTYPath",                             config_parse_unit_path_printf,                      0,                                  offsetof(Mount, exec_context.tty_path)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
#line 1275 "src/core/load-fragment-gperf.gperf"
      {"Slice.NFTSet",                              config_parse_cgroup_nft_set,                        NFT_SET_PARSE_CGROUP,               offsetof(Slice, cgroup_context)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0},
#line 763 "src/core/load-fragment-gperf.gperf"
      {"Mount.TTYColumns",                          config_parse_tty_size,                              0,                                  offsetof(Mount, exec_context.tty_cols)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 232 "src/core/load-fragment-gperf.gperf"
      {"Service.TTYVTDisallocate",                    config_parse_bool,                                  0,                                  offsetof(Service, exec_context.tty_vt_disallocate)},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0}, {(char*)0}, {(char*)0}, {(char*)0},
      {(char*)0},
#line 796 "src/core/load-fragment-gperf.gperf"
      {"Mount.LimitSTACK",                          config_parse_rlimit,                                RLIMIT_STACK,                       offsetof(Mount, exec_context.rlimit)}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register unsigned int key = load_fragment_gperf_hash (str, len);

      if (key <= MAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].section_and_lvalue;

          if (s && *str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}

#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ical" for configuration ""
set_property(TARGET ical APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(ical PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libical.so.3.0.19"
  IMPORTED_SONAME_NOCONFIG "libical.so.3"
  )

list(APPEND _cmake_import_check_targets ical )
list(APPEND _cmake_import_check_files_for_ical "${_IMPORT_PREFIX}/lib/libical.so.3.0.19" )

# Import target "ical_cxx" for configuration ""
set_property(TARGET ical_cxx APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(ical_cxx PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libical_cxx.so.3.0.19"
  IMPORTED_SONAME_NOCONFIG "libical_cxx.so.3"
  )

list(APPEND _cmake_import_check_targets ical_cxx )
list(APPEND _cmake_import_check_files_for_ical_cxx "${_IMPORT_PREFIX}/lib/libical_cxx.so.3.0.19" )

# Import target "icalss" for configuration ""
set_property(TARGET icalss APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(icalss PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libicalss.so.3.0.19"
  IMPORTED_SONAME_NOCONFIG "libicalss.so.3"
  )

list(APPEND _cmake_import_check_targets icalss )
list(APPEND _cmake_import_check_files_for_icalss "${_IMPORT_PREFIX}/lib/libicalss.so.3.0.19" )

# Import target "icalss_cxx" for configuration ""
set_property(TARGET icalss_cxx APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(icalss_cxx PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libicalss_cxx.so.3.0.19"
  IMPORTED_SONAME_NOCONFIG "libicalss_cxx.so.3"
  )

list(APPEND _cmake_import_check_targets icalss_cxx )
list(APPEND _cmake_import_check_files_for_icalss_cxx "${_IMPORT_PREFIX}/lib/libicalss_cxx.so.3.0.19" )

# Import target "icalvcal" for configuration ""
set_property(TARGET icalvcal APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(icalvcal PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libicalvcal.so.3.0.19"
  IMPORTED_SONAME_NOCONFIG "libicalvcal.so.3"
  )

list(APPEND _cmake_import_check_targets icalvcal )
list(APPEND _cmake_import_check_files_for_icalvcal "${_IMPORT_PREFIX}/lib/libicalvcal.so.3.0.19" )

# Import target "ical-glib" for configuration ""
set_property(TARGET ical-glib APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(ical-glib PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "ical"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libical-glib.so.3.0.19"
  IMPORTED_SONAME_NOCONFIG "libical-glib.so.3"
  )

list(APPEND _cmake_import_check_targets ical-glib )
list(APPEND _cmake_import_check_files_for_ical-glib "${_IMPORT_PREFIX}/lib/libical-glib.so.3.0.19" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

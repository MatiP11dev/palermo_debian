/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 32 "policy_parse.y"

#include <sys/types.h>
#include <assert.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>

#include <sepol/policydb/expand.h>
#include <sepol/policydb/policydb.h>
#include <sepol/policydb/services.h>
#include <sepol/policydb/conditional.h>
#include <sepol/policydb/hierarchy.h>
#include <sepol/policydb/polcaps.h>
#include "queue.h"
#include "module_compiler.h"
#include "policy_define.h"

extern policydb_t *policydbp;
extern unsigned int pass;

extern char yytext[];
extern int yylex(void);
extern int yywarn(const char *msg);
extern int yyerror(const char *msg);

typedef int (* require_func_t)(int pass);


#line 106 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    PATH = 258,                    /* PATH  */
    QPATH = 259,                   /* QPATH  */
    FILENAME = 260,                /* FILENAME  */
    COMMON = 261,                  /* COMMON  */
    CLASS = 262,                   /* CLASS  */
    CONSTRAIN = 263,               /* CONSTRAIN  */
    VALIDATETRANS = 264,           /* VALIDATETRANS  */
    INHERITS = 265,                /* INHERITS  */
    SID = 266,                     /* SID  */
    ROLE = 267,                    /* ROLE  */
    ROLEATTRIBUTE = 268,           /* ROLEATTRIBUTE  */
    ATTRIBUTE_ROLE = 269,          /* ATTRIBUTE_ROLE  */
    ROLES = 270,                   /* ROLES  */
    TYPEALIAS = 271,               /* TYPEALIAS  */
    TYPEATTRIBUTE = 272,           /* TYPEATTRIBUTE  */
    TYPEBOUNDS = 273,              /* TYPEBOUNDS  */
    TYPE = 274,                    /* TYPE  */
    TYPES = 275,                   /* TYPES  */
    ALIAS = 276,                   /* ALIAS  */
    ATTRIBUTE = 277,               /* ATTRIBUTE  */
    EXPANDATTRIBUTE = 278,         /* EXPANDATTRIBUTE  */
    BOOL = 279,                    /* BOOL  */
    TUNABLE = 280,                 /* TUNABLE  */
    IF = 281,                      /* IF  */
    ELSE = 282,                    /* ELSE  */
    TYPE_TRANSITION = 283,         /* TYPE_TRANSITION  */
    TYPE_MEMBER = 284,             /* TYPE_MEMBER  */
    TYPE_CHANGE = 285,             /* TYPE_CHANGE  */
    ROLE_TRANSITION = 286,         /* ROLE_TRANSITION  */
    RANGE_TRANSITION = 287,        /* RANGE_TRANSITION  */
    SENSITIVITY = 288,             /* SENSITIVITY  */
    DOMINANCE = 289,               /* DOMINANCE  */
    DOM = 290,                     /* DOM  */
    DOMBY = 291,                   /* DOMBY  */
    INCOMP = 292,                  /* INCOMP  */
    CATEGORY = 293,                /* CATEGORY  */
    LEVEL = 294,                   /* LEVEL  */
    RANGE = 295,                   /* RANGE  */
    MLSCONSTRAIN = 296,            /* MLSCONSTRAIN  */
    MLSVALIDATETRANS = 297,        /* MLSVALIDATETRANS  */
    USER = 298,                    /* USER  */
    NEVERALLOW = 299,              /* NEVERALLOW  */
    ALLOW = 300,                   /* ALLOW  */
    AUDITALLOW = 301,              /* AUDITALLOW  */
    AUDITDENY = 302,               /* AUDITDENY  */
    DONTAUDIT = 303,               /* DONTAUDIT  */
    ALLOWXPERM = 304,              /* ALLOWXPERM  */
    AUDITALLOWXPERM = 305,         /* AUDITALLOWXPERM  */
    DONTAUDITXPERM = 306,          /* DONTAUDITXPERM  */
    NEVERALLOWXPERM = 307,         /* NEVERALLOWXPERM  */
    SOURCE = 308,                  /* SOURCE  */
    TARGET = 309,                  /* TARGET  */
    SAMEUSER = 310,                /* SAMEUSER  */
    FSCON = 311,                   /* FSCON  */
    PORTCON = 312,                 /* PORTCON  */
    NETIFCON = 313,                /* NETIFCON  */
    NODECON = 314,                 /* NODECON  */
    IBPKEYCON = 315,               /* IBPKEYCON  */
    IBENDPORTCON = 316,            /* IBENDPORTCON  */
    PIRQCON = 317,                 /* PIRQCON  */
    IOMEMCON = 318,                /* IOMEMCON  */
    IOPORTCON = 319,               /* IOPORTCON  */
    PCIDEVICECON = 320,            /* PCIDEVICECON  */
    DEVICETREECON = 321,           /* DEVICETREECON  */
    FSUSEXATTR = 322,              /* FSUSEXATTR  */
    FSUSETASK = 323,               /* FSUSETASK  */
    FSUSETRANS = 324,              /* FSUSETRANS  */
    GENFSCON = 325,                /* GENFSCON  */
    U1 = 326,                      /* U1  */
    U2 = 327,                      /* U2  */
    U3 = 328,                      /* U3  */
    R1 = 329,                      /* R1  */
    R2 = 330,                      /* R2  */
    R3 = 331,                      /* R3  */
    T1 = 332,                      /* T1  */
    T2 = 333,                      /* T2  */
    T3 = 334,                      /* T3  */
    L1 = 335,                      /* L1  */
    L2 = 336,                      /* L2  */
    H1 = 337,                      /* H1  */
    H2 = 338,                      /* H2  */
    NOT = 339,                     /* NOT  */
    AND = 340,                     /* AND  */
    OR = 341,                      /* OR  */
    XOR = 342,                     /* XOR  */
    CTRUE = 343,                   /* CTRUE  */
    CFALSE = 344,                  /* CFALSE  */
    IDENTIFIER = 345,              /* IDENTIFIER  */
    NUMBER = 346,                  /* NUMBER  */
    EQUALS = 347,                  /* EQUALS  */
    NOTEQUAL = 348,                /* NOTEQUAL  */
    IPV4_ADDR = 349,               /* IPV4_ADDR  */
    IPV4_CIDR = 350,               /* IPV4_CIDR  */
    IPV6_ADDR = 351,               /* IPV6_ADDR  */
    IPV6_CIDR = 352,               /* IPV6_CIDR  */
    MODULE = 353,                  /* MODULE  */
    VERSION_IDENTIFIER = 354,      /* VERSION_IDENTIFIER  */
    REQUIRE = 355,                 /* REQUIRE  */
    OPTIONAL = 356,                /* OPTIONAL  */
    POLICYCAP = 357,               /* POLICYCAP  */
    PERMISSIVE = 358,              /* PERMISSIVE  */
    FILESYSTEM = 359,              /* FILESYSTEM  */
    DEFAULT_USER = 360,            /* DEFAULT_USER  */
    DEFAULT_ROLE = 361,            /* DEFAULT_ROLE  */
    DEFAULT_TYPE = 362,            /* DEFAULT_TYPE  */
    DEFAULT_RANGE = 363,           /* DEFAULT_RANGE  */
    LOW_HIGH = 364,                /* LOW_HIGH  */
    LOW = 365,                     /* LOW  */
    HIGH = 366,                    /* HIGH  */
    GLBLUB = 367,                  /* GLBLUB  */
    INVALID_CHAR = 368             /* INVALID_CHAR  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define PATH 258
#define QPATH 259
#define FILENAME 260
#define COMMON 261
#define CLASS 262
#define CONSTRAIN 263
#define VALIDATETRANS 264
#define INHERITS 265
#define SID 266
#define ROLE 267
#define ROLEATTRIBUTE 268
#define ATTRIBUTE_ROLE 269
#define ROLES 270
#define TYPEALIAS 271
#define TYPEATTRIBUTE 272
#define TYPEBOUNDS 273
#define TYPE 274
#define TYPES 275
#define ALIAS 276
#define ATTRIBUTE 277
#define EXPANDATTRIBUTE 278
#define BOOL 279
#define TUNABLE 280
#define IF 281
#define ELSE 282
#define TYPE_TRANSITION 283
#define TYPE_MEMBER 284
#define TYPE_CHANGE 285
#define ROLE_TRANSITION 286
#define RANGE_TRANSITION 287
#define SENSITIVITY 288
#define DOMINANCE 289
#define DOM 290
#define DOMBY 291
#define INCOMP 292
#define CATEGORY 293
#define LEVEL 294
#define RANGE 295
#define MLSCONSTRAIN 296
#define MLSVALIDATETRANS 297
#define USER 298
#define NEVERALLOW 299
#define ALLOW 300
#define AUDITALLOW 301
#define AUDITDENY 302
#define DONTAUDIT 303
#define ALLOWXPERM 304
#define AUDITALLOWXPERM 305
#define DONTAUDITXPERM 306
#define NEVERALLOWXPERM 307
#define SOURCE 308
#define TARGET 309
#define SAMEUSER 310
#define FSCON 311
#define PORTCON 312
#define NETIFCON 313
#define NODECON 314
#define IBPKEYCON 315
#define IBENDPORTCON 316
#define PIRQCON 317
#define IOMEMCON 318
#define IOPORTCON 319
#define PCIDEVICECON 320
#define DEVICETREECON 321
#define FSUSEXATTR 322
#define FSUSETASK 323
#define FSUSETRANS 324
#define GENFSCON 325
#define U1 326
#define U2 327
#define U3 328
#define R1 329
#define R2 330
#define R3 331
#define T1 332
#define T2 333
#define T3 334
#define L1 335
#define L2 336
#define H1 337
#define H2 338
#define NOT 339
#define AND 340
#define OR 341
#define XOR 342
#define CTRUE 343
#define CFALSE 344
#define IDENTIFIER 345
#define NUMBER 346
#define EQUALS 347
#define NOTEQUAL 348
#define IPV4_ADDR 349
#define IPV4_CIDR 350
#define IPV6_ADDR 351
#define IPV6_CIDR 352
#define MODULE 353
#define VERSION_IDENTIFIER 354
#define REQUIRE 355
#define OPTIONAL 356
#define POLICYCAP 357
#define PERMISSIVE 358
#define FILESYSTEM 359
#define DEFAULT_USER 360
#define DEFAULT_ROLE 361
#define DEFAULT_TYPE 362
#define DEFAULT_RANGE 363
#define LOW_HIGH 364
#define LOW 365
#define HIGH 366
#define GLBLUB 367
#define INVALID_CHAR 368

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 67 "policy_parse.y"

	unsigned int val;
	uint64_t val64;
	uintptr_t valptr;
	void *ptr;
        require_func_t require_func;

#line 393 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_PATH = 3,                       /* PATH  */
  YYSYMBOL_QPATH = 4,                      /* QPATH  */
  YYSYMBOL_FILENAME = 5,                   /* FILENAME  */
  YYSYMBOL_COMMON = 6,                     /* COMMON  */
  YYSYMBOL_CLASS = 7,                      /* CLASS  */
  YYSYMBOL_CONSTRAIN = 8,                  /* CONSTRAIN  */
  YYSYMBOL_VALIDATETRANS = 9,              /* VALIDATETRANS  */
  YYSYMBOL_INHERITS = 10,                  /* INHERITS  */
  YYSYMBOL_SID = 11,                       /* SID  */
  YYSYMBOL_ROLE = 12,                      /* ROLE  */
  YYSYMBOL_ROLEATTRIBUTE = 13,             /* ROLEATTRIBUTE  */
  YYSYMBOL_ATTRIBUTE_ROLE = 14,            /* ATTRIBUTE_ROLE  */
  YYSYMBOL_ROLES = 15,                     /* ROLES  */
  YYSYMBOL_TYPEALIAS = 16,                 /* TYPEALIAS  */
  YYSYMBOL_TYPEATTRIBUTE = 17,             /* TYPEATTRIBUTE  */
  YYSYMBOL_TYPEBOUNDS = 18,                /* TYPEBOUNDS  */
  YYSYMBOL_TYPE = 19,                      /* TYPE  */
  YYSYMBOL_TYPES = 20,                     /* TYPES  */
  YYSYMBOL_ALIAS = 21,                     /* ALIAS  */
  YYSYMBOL_ATTRIBUTE = 22,                 /* ATTRIBUTE  */
  YYSYMBOL_EXPANDATTRIBUTE = 23,           /* EXPANDATTRIBUTE  */
  YYSYMBOL_BOOL = 24,                      /* BOOL  */
  YYSYMBOL_TUNABLE = 25,                   /* TUNABLE  */
  YYSYMBOL_IF = 26,                        /* IF  */
  YYSYMBOL_ELSE = 27,                      /* ELSE  */
  YYSYMBOL_TYPE_TRANSITION = 28,           /* TYPE_TRANSITION  */
  YYSYMBOL_TYPE_MEMBER = 29,               /* TYPE_MEMBER  */
  YYSYMBOL_TYPE_CHANGE = 30,               /* TYPE_CHANGE  */
  YYSYMBOL_ROLE_TRANSITION = 31,           /* ROLE_TRANSITION  */
  YYSYMBOL_RANGE_TRANSITION = 32,          /* RANGE_TRANSITION  */
  YYSYMBOL_SENSITIVITY = 33,               /* SENSITIVITY  */
  YYSYMBOL_DOMINANCE = 34,                 /* DOMINANCE  */
  YYSYMBOL_DOM = 35,                       /* DOM  */
  YYSYMBOL_DOMBY = 36,                     /* DOMBY  */
  YYSYMBOL_INCOMP = 37,                    /* INCOMP  */
  YYSYMBOL_CATEGORY = 38,                  /* CATEGORY  */
  YYSYMBOL_LEVEL = 39,                     /* LEVEL  */
  YYSYMBOL_RANGE = 40,                     /* RANGE  */
  YYSYMBOL_MLSCONSTRAIN = 41,              /* MLSCONSTRAIN  */
  YYSYMBOL_MLSVALIDATETRANS = 42,          /* MLSVALIDATETRANS  */
  YYSYMBOL_USER = 43,                      /* USER  */
  YYSYMBOL_NEVERALLOW = 44,                /* NEVERALLOW  */
  YYSYMBOL_ALLOW = 45,                     /* ALLOW  */
  YYSYMBOL_AUDITALLOW = 46,                /* AUDITALLOW  */
  YYSYMBOL_AUDITDENY = 47,                 /* AUDITDENY  */
  YYSYMBOL_DONTAUDIT = 48,                 /* DONTAUDIT  */
  YYSYMBOL_ALLOWXPERM = 49,                /* ALLOWXPERM  */
  YYSYMBOL_AUDITALLOWXPERM = 50,           /* AUDITALLOWXPERM  */
  YYSYMBOL_DONTAUDITXPERM = 51,            /* DONTAUDITXPERM  */
  YYSYMBOL_NEVERALLOWXPERM = 52,           /* NEVERALLOWXPERM  */
  YYSYMBOL_SOURCE = 53,                    /* SOURCE  */
  YYSYMBOL_TARGET = 54,                    /* TARGET  */
  YYSYMBOL_SAMEUSER = 55,                  /* SAMEUSER  */
  YYSYMBOL_FSCON = 56,                     /* FSCON  */
  YYSYMBOL_PORTCON = 57,                   /* PORTCON  */
  YYSYMBOL_NETIFCON = 58,                  /* NETIFCON  */
  YYSYMBOL_NODECON = 59,                   /* NODECON  */
  YYSYMBOL_IBPKEYCON = 60,                 /* IBPKEYCON  */
  YYSYMBOL_IBENDPORTCON = 61,              /* IBENDPORTCON  */
  YYSYMBOL_PIRQCON = 62,                   /* PIRQCON  */
  YYSYMBOL_IOMEMCON = 63,                  /* IOMEMCON  */
  YYSYMBOL_IOPORTCON = 64,                 /* IOPORTCON  */
  YYSYMBOL_PCIDEVICECON = 65,              /* PCIDEVICECON  */
  YYSYMBOL_DEVICETREECON = 66,             /* DEVICETREECON  */
  YYSYMBOL_FSUSEXATTR = 67,                /* FSUSEXATTR  */
  YYSYMBOL_FSUSETASK = 68,                 /* FSUSETASK  */
  YYSYMBOL_FSUSETRANS = 69,                /* FSUSETRANS  */
  YYSYMBOL_GENFSCON = 70,                  /* GENFSCON  */
  YYSYMBOL_U1 = 71,                        /* U1  */
  YYSYMBOL_U2 = 72,                        /* U2  */
  YYSYMBOL_U3 = 73,                        /* U3  */
  YYSYMBOL_R1 = 74,                        /* R1  */
  YYSYMBOL_R2 = 75,                        /* R2  */
  YYSYMBOL_R3 = 76,                        /* R3  */
  YYSYMBOL_T1 = 77,                        /* T1  */
  YYSYMBOL_T2 = 78,                        /* T2  */
  YYSYMBOL_T3 = 79,                        /* T3  */
  YYSYMBOL_L1 = 80,                        /* L1  */
  YYSYMBOL_L2 = 81,                        /* L2  */
  YYSYMBOL_H1 = 82,                        /* H1  */
  YYSYMBOL_H2 = 83,                        /* H2  */
  YYSYMBOL_NOT = 84,                       /* NOT  */
  YYSYMBOL_AND = 85,                       /* AND  */
  YYSYMBOL_OR = 86,                        /* OR  */
  YYSYMBOL_XOR = 87,                       /* XOR  */
  YYSYMBOL_CTRUE = 88,                     /* CTRUE  */
  YYSYMBOL_CFALSE = 89,                    /* CFALSE  */
  YYSYMBOL_IDENTIFIER = 90,                /* IDENTIFIER  */
  YYSYMBOL_NUMBER = 91,                    /* NUMBER  */
  YYSYMBOL_EQUALS = 92,                    /* EQUALS  */
  YYSYMBOL_NOTEQUAL = 93,                  /* NOTEQUAL  */
  YYSYMBOL_IPV4_ADDR = 94,                 /* IPV4_ADDR  */
  YYSYMBOL_IPV4_CIDR = 95,                 /* IPV4_CIDR  */
  YYSYMBOL_IPV6_ADDR = 96,                 /* IPV6_ADDR  */
  YYSYMBOL_IPV6_CIDR = 97,                 /* IPV6_CIDR  */
  YYSYMBOL_MODULE = 98,                    /* MODULE  */
  YYSYMBOL_VERSION_IDENTIFIER = 99,        /* VERSION_IDENTIFIER  */
  YYSYMBOL_REQUIRE = 100,                  /* REQUIRE  */
  YYSYMBOL_OPTIONAL = 101,                 /* OPTIONAL  */
  YYSYMBOL_POLICYCAP = 102,                /* POLICYCAP  */
  YYSYMBOL_PERMISSIVE = 103,               /* PERMISSIVE  */
  YYSYMBOL_FILESYSTEM = 104,               /* FILESYSTEM  */
  YYSYMBOL_DEFAULT_USER = 105,             /* DEFAULT_USER  */
  YYSYMBOL_DEFAULT_ROLE = 106,             /* DEFAULT_ROLE  */
  YYSYMBOL_DEFAULT_TYPE = 107,             /* DEFAULT_TYPE  */
  YYSYMBOL_DEFAULT_RANGE = 108,            /* DEFAULT_RANGE  */
  YYSYMBOL_LOW_HIGH = 109,                 /* LOW_HIGH  */
  YYSYMBOL_LOW = 110,                      /* LOW  */
  YYSYMBOL_HIGH = 111,                     /* HIGH  */
  YYSYMBOL_GLBLUB = 112,                   /* GLBLUB  */
  YYSYMBOL_INVALID_CHAR = 113,             /* INVALID_CHAR  */
  YYSYMBOL_114_ = 114,                     /* '{'  */
  YYSYMBOL_115_ = 115,                     /* '}'  */
  YYSYMBOL_116_ = 116,                     /* ';'  */
  YYSYMBOL_117_ = 117,                     /* ':'  */
  YYSYMBOL_118_ = 118,                     /* ','  */
  YYSYMBOL_119_ = 119,                     /* '('  */
  YYSYMBOL_120_ = 120,                     /* ')'  */
  YYSYMBOL_121_ = 121,                     /* '-'  */
  YYSYMBOL_122_ = 122,                     /* '~'  */
  YYSYMBOL_123_ = 123,                     /* '*'  */
  YYSYMBOL_YYACCEPT = 124,                 /* $accept  */
  YYSYMBOL_policy = 125,                   /* policy  */
  YYSYMBOL_base_policy = 126,              /* base_policy  */
  YYSYMBOL_127_1 = 127,                    /* $@1  */
  YYSYMBOL_128_2 = 128,                    /* $@2  */
  YYSYMBOL_129_3 = 129,                    /* $@3  */
  YYSYMBOL_classes = 130,                  /* classes  */
  YYSYMBOL_class_def = 131,                /* class_def  */
  YYSYMBOL_initial_sids = 132,             /* initial_sids  */
  YYSYMBOL_initial_sid_def = 133,          /* initial_sid_def  */
  YYSYMBOL_access_vectors = 134,           /* access_vectors  */
  YYSYMBOL_opt_common_perms = 135,         /* opt_common_perms  */
  YYSYMBOL_common_perms = 136,             /* common_perms  */
  YYSYMBOL_common_perms_def = 137,         /* common_perms_def  */
  YYSYMBOL_av_perms = 138,                 /* av_perms  */
  YYSYMBOL_av_perms_def = 139,             /* av_perms_def  */
  YYSYMBOL_opt_default_rules = 140,        /* opt_default_rules  */
  YYSYMBOL_default_rules = 141,            /* default_rules  */
  YYSYMBOL_default_user_def = 142,         /* default_user_def  */
  YYSYMBOL_default_role_def = 143,         /* default_role_def  */
  YYSYMBOL_default_type_def = 144,         /* default_type_def  */
  YYSYMBOL_default_range_def = 145,        /* default_range_def  */
  YYSYMBOL_opt_mls = 146,                  /* opt_mls  */
  YYSYMBOL_mls = 147,                      /* mls  */
  YYSYMBOL_sensitivities = 148,            /* sensitivities  */
  YYSYMBOL_sensitivity_def = 149,          /* sensitivity_def  */
  YYSYMBOL_alias_def = 150,                /* alias_def  */
  YYSYMBOL_dominance = 151,                /* dominance  */
  YYSYMBOL_opt_categories = 152,           /* opt_categories  */
  YYSYMBOL_categories = 153,               /* categories  */
  YYSYMBOL_category_def = 154,             /* category_def  */
  YYSYMBOL_levels = 155,                   /* levels  */
  YYSYMBOL_level_def = 156,                /* level_def  */
  YYSYMBOL_mlspolicy = 157,                /* mlspolicy  */
  YYSYMBOL_mlspolicy_decl = 158,           /* mlspolicy_decl  */
  YYSYMBOL_mlsconstraint_def = 159,        /* mlsconstraint_def  */
  YYSYMBOL_mlsvalidatetrans_def = 160,     /* mlsvalidatetrans_def  */
  YYSYMBOL_te_rbac = 161,                  /* te_rbac  */
  YYSYMBOL_te_rbac_decl = 162,             /* te_rbac_decl  */
  YYSYMBOL_rbac_decl = 163,                /* rbac_decl  */
  YYSYMBOL_te_decl = 164,                  /* te_decl  */
  YYSYMBOL_attribute_def = 165,            /* attribute_def  */
  YYSYMBOL_expandattribute_def = 166,      /* expandattribute_def  */
  YYSYMBOL_type_def = 167,                 /* type_def  */
  YYSYMBOL_typealias_def = 168,            /* typealias_def  */
  YYSYMBOL_typeattribute_def = 169,        /* typeattribute_def  */
  YYSYMBOL_typebounds_def = 170,           /* typebounds_def  */
  YYSYMBOL_opt_attr_list = 171,            /* opt_attr_list  */
  YYSYMBOL_bool_def = 172,                 /* bool_def  */
  YYSYMBOL_tunable_def = 173,              /* tunable_def  */
  YYSYMBOL_bool_val = 174,                 /* bool_val  */
  YYSYMBOL_cond_stmt_def = 175,            /* cond_stmt_def  */
  YYSYMBOL_cond_else = 176,                /* cond_else  */
  YYSYMBOL_cond_expr = 177,                /* cond_expr  */
  YYSYMBOL_cond_expr_prim = 178,           /* cond_expr_prim  */
  YYSYMBOL_cond_pol_list = 179,            /* cond_pol_list  */
  YYSYMBOL_cond_rule_def = 180,            /* cond_rule_def  */
  YYSYMBOL_cond_transition_def = 181,      /* cond_transition_def  */
  YYSYMBOL_cond_te_avtab_def = 182,        /* cond_te_avtab_def  */
  YYSYMBOL_cond_allow_def = 183,           /* cond_allow_def  */
  YYSYMBOL_cond_auditallow_def = 184,      /* cond_auditallow_def  */
  YYSYMBOL_cond_auditdeny_def = 185,       /* cond_auditdeny_def  */
  YYSYMBOL_cond_dontaudit_def = 186,       /* cond_dontaudit_def  */
  YYSYMBOL_transition_def = 187,           /* transition_def  */
  YYSYMBOL_range_trans_def = 188,          /* range_trans_def  */
  YYSYMBOL_te_avtab_def = 189,             /* te_avtab_def  */
  YYSYMBOL_allow_def = 190,                /* allow_def  */
  YYSYMBOL_auditallow_def = 191,           /* auditallow_def  */
  YYSYMBOL_auditdeny_def = 192,            /* auditdeny_def  */
  YYSYMBOL_dontaudit_def = 193,            /* dontaudit_def  */
  YYSYMBOL_neverallow_def = 194,           /* neverallow_def  */
  YYSYMBOL_xperm_allow_def = 195,          /* xperm_allow_def  */
  YYSYMBOL_xperm_auditallow_def = 196,     /* xperm_auditallow_def  */
  YYSYMBOL_xperm_dontaudit_def = 197,      /* xperm_dontaudit_def  */
  YYSYMBOL_xperm_neverallow_def = 198,     /* xperm_neverallow_def  */
  YYSYMBOL_attribute_role_def = 199,       /* attribute_role_def  */
  YYSYMBOL_role_type_def = 200,            /* role_type_def  */
  YYSYMBOL_role_attr_def = 201,            /* role_attr_def  */
  YYSYMBOL_role_trans_def = 202,           /* role_trans_def  */
  YYSYMBOL_role_allow_def = 203,           /* role_allow_def  */
  YYSYMBOL_roleattribute_def = 204,        /* roleattribute_def  */
  YYSYMBOL_opt_constraints = 205,          /* opt_constraints  */
  YYSYMBOL_constraints = 206,              /* constraints  */
  YYSYMBOL_constraint_decl = 207,          /* constraint_decl  */
  YYSYMBOL_constraint_def = 208,           /* constraint_def  */
  YYSYMBOL_validatetrans_def = 209,        /* validatetrans_def  */
  YYSYMBOL_cexpr = 210,                    /* cexpr  */
  YYSYMBOL_cexpr_prim = 211,               /* cexpr_prim  */
  YYSYMBOL_212_4 = 212,                    /* $@4  */
  YYSYMBOL_213_5 = 213,                    /* $@5  */
  YYSYMBOL_214_6 = 214,                    /* $@6  */
  YYSYMBOL_215_7 = 215,                    /* $@7  */
  YYSYMBOL_216_8 = 216,                    /* $@8  */
  YYSYMBOL_217_9 = 217,                    /* $@9  */
  YYSYMBOL_218_10 = 218,                   /* $@10  */
  YYSYMBOL_219_11 = 219,                   /* $@11  */
  YYSYMBOL_220_12 = 220,                   /* $@12  */
  YYSYMBOL_221_13 = 221,                   /* $@13  */
  YYSYMBOL_222_14 = 222,                   /* $@14  */
  YYSYMBOL_223_15 = 223,                   /* $@15  */
  YYSYMBOL_224_16 = 224,                   /* $@16  */
  YYSYMBOL_op = 225,                       /* op  */
  YYSYMBOL_role_mls_op = 226,              /* role_mls_op  */
  YYSYMBOL_users = 227,                    /* users  */
  YYSYMBOL_user_def = 228,                 /* user_def  */
  YYSYMBOL_opt_mls_user = 229,             /* opt_mls_user  */
  YYSYMBOL_initial_sid_contexts = 230,     /* initial_sid_contexts  */
  YYSYMBOL_initial_sid_context_def = 231,  /* initial_sid_context_def  */
  YYSYMBOL_opt_dev_contexts = 232,         /* opt_dev_contexts  */
  YYSYMBOL_dev_contexts = 233,             /* dev_contexts  */
  YYSYMBOL_dev_context_def = 234,          /* dev_context_def  */
  YYSYMBOL_pirq_context_def = 235,         /* pirq_context_def  */
  YYSYMBOL_iomem_context_def = 236,        /* iomem_context_def  */
  YYSYMBOL_ioport_context_def = 237,       /* ioport_context_def  */
  YYSYMBOL_pci_context_def = 238,          /* pci_context_def  */
  YYSYMBOL_dtree_context_def = 239,        /* dtree_context_def  */
  YYSYMBOL_opt_fs_contexts = 240,          /* opt_fs_contexts  */
  YYSYMBOL_fs_contexts = 241,              /* fs_contexts  */
  YYSYMBOL_fs_context_def = 242,           /* fs_context_def  */
  YYSYMBOL_net_contexts = 243,             /* net_contexts  */
  YYSYMBOL_opt_port_contexts = 244,        /* opt_port_contexts  */
  YYSYMBOL_port_contexts = 245,            /* port_contexts  */
  YYSYMBOL_port_context_def = 246,         /* port_context_def  */
  YYSYMBOL_opt_ibpkey_contexts = 247,      /* opt_ibpkey_contexts  */
  YYSYMBOL_ibpkey_contexts = 248,          /* ibpkey_contexts  */
  YYSYMBOL_ibpkey_context_def = 249,       /* ibpkey_context_def  */
  YYSYMBOL_opt_ibendport_contexts = 250,   /* opt_ibendport_contexts  */
  YYSYMBOL_ibendport_contexts = 251,       /* ibendport_contexts  */
  YYSYMBOL_ibendport_context_def = 252,    /* ibendport_context_def  */
  YYSYMBOL_opt_netif_contexts = 253,       /* opt_netif_contexts  */
  YYSYMBOL_netif_contexts = 254,           /* netif_contexts  */
  YYSYMBOL_netif_context_def = 255,        /* netif_context_def  */
  YYSYMBOL_opt_node_contexts = 256,        /* opt_node_contexts  */
  YYSYMBOL_node_contexts = 257,            /* node_contexts  */
  YYSYMBOL_node_context_def = 258,         /* node_context_def  */
  YYSYMBOL_opt_fs_uses = 259,              /* opt_fs_uses  */
  YYSYMBOL_fs_uses = 260,                  /* fs_uses  */
  YYSYMBOL_fs_use_def = 261,               /* fs_use_def  */
  YYSYMBOL_opt_genfs_contexts = 262,       /* opt_genfs_contexts  */
  YYSYMBOL_genfs_contexts = 263,           /* genfs_contexts  */
  YYSYMBOL_genfs_context_def = 264,        /* genfs_context_def  */
  YYSYMBOL_265_17 = 265,                   /* $@17  */
  YYSYMBOL_ipv4_addr_def = 266,            /* ipv4_addr_def  */
  YYSYMBOL_ipv4_cidr_def = 267,            /* ipv4_cidr_def  */
  YYSYMBOL_xperms = 268,                   /* xperms  */
  YYSYMBOL_nested_xperm_set = 269,         /* nested_xperm_set  */
  YYSYMBOL_nested_xperm_list = 270,        /* nested_xperm_list  */
  YYSYMBOL_nested_xperm_element = 271,     /* nested_xperm_element  */
  YYSYMBOL_272_18 = 272,                   /* $@18  */
  YYSYMBOL_xperm = 273,                    /* xperm  */
  YYSYMBOL_security_context_def = 274,     /* security_context_def  */
  YYSYMBOL_opt_mls_range_def = 275,        /* opt_mls_range_def  */
  YYSYMBOL_mls_range_def = 276,            /* mls_range_def  */
  YYSYMBOL_mls_level_def = 277,            /* mls_level_def  */
  YYSYMBOL_id_comma_list = 278,            /* id_comma_list  */
  YYSYMBOL_tilde = 279,                    /* tilde  */
  YYSYMBOL_asterisk = 280,                 /* asterisk  */
  YYSYMBOL_names = 281,                    /* names  */
  YYSYMBOL_282_19 = 282,                   /* $@19  */
  YYSYMBOL_tilde_push = 283,               /* tilde_push  */
  YYSYMBOL_asterisk_push = 284,            /* asterisk_push  */
  YYSYMBOL_names_push = 285,               /* names_push  */
  YYSYMBOL_identifier_list_push = 286,     /* identifier_list_push  */
  YYSYMBOL_identifier_push = 287,          /* identifier_push  */
  YYSYMBOL_identifier_list = 288,          /* identifier_list  */
  YYSYMBOL_nested_id_set = 289,            /* nested_id_set  */
  YYSYMBOL_nested_id_list = 290,           /* nested_id_list  */
  YYSYMBOL_nested_id_element = 291,        /* nested_id_element  */
  YYSYMBOL_292_20 = 292,                   /* $@20  */
  YYSYMBOL_identifier = 293,               /* identifier  */
  YYSYMBOL_filesystem = 294,               /* filesystem  */
  YYSYMBOL_path = 295,                     /* path  */
  YYSYMBOL_filename = 296,                 /* filename  */
  YYSYMBOL_number = 297,                   /* number  */
  YYSYMBOL_number64 = 298,                 /* number64  */
  YYSYMBOL_ipv6_addr = 299,                /* ipv6_addr  */
  YYSYMBOL_ipv6_cidr = 300,                /* ipv6_cidr  */
  YYSYMBOL_policycap_def = 301,            /* policycap_def  */
  YYSYMBOL_permissive_def = 302,           /* permissive_def  */
  YYSYMBOL_module_policy = 303,            /* module_policy  */
  YYSYMBOL_module_def = 304,               /* module_def  */
  YYSYMBOL_version_identifier = 305,       /* version_identifier  */
  YYSYMBOL_avrules_block = 306,            /* avrules_block  */
  YYSYMBOL_avrule_decls = 307,             /* avrule_decls  */
  YYSYMBOL_avrule_decl = 308,              /* avrule_decl  */
  YYSYMBOL_require_block = 309,            /* require_block  */
  YYSYMBOL_require_list = 310,             /* require_list  */
  YYSYMBOL_require_decl = 311,             /* require_decl  */
  YYSYMBOL_require_class = 312,            /* require_class  */
  YYSYMBOL_require_decl_def = 313,         /* require_decl_def  */
  YYSYMBOL_require_id_list = 314,          /* require_id_list  */
  YYSYMBOL_optional_block = 315,           /* optional_block  */
  YYSYMBOL_316_21 = 316,                   /* $@21  */
  YYSYMBOL_optional_else = 317,            /* optional_else  */
  YYSYMBOL_optional_decl = 318,            /* optional_decl  */
  YYSYMBOL_else_decl = 319,                /* else_decl  */
  YYSYMBOL_avrule_user_defs = 320          /* avrule_user_defs  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  9
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1346

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  124
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  197
/* YYNRULES -- Number of rules.  */
#define YYNRULES  405
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  810

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   368


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     119,   120,   123,     2,   118,   121,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   117,   116,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   114,     2,   115,   122,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   165,   165,   166,   168,   170,   173,   168,   177,   178,
     180,   183,   184,   186,   189,   191,   192,   194,   195,   197,
     200,   201,   203,   205,   207,   210,   211,   213,   214,   215,
     216,   217,   218,   219,   220,   222,   224,   227,   229,   232,
     234,   237,   239,   241,   243,   245,   247,   249,   252,   253,
     255,   257,   258,   260,   262,   265,   267,   269,   272,   273,
     275,   276,   278,   280,   283,   284,   286,   288,   291,   292,
     294,   295,   297,   300,   303,   304,   306,   307,   308,   309,
     310,   311,   313,   314,   315,   316,   317,   318,   320,   321,
     322,   323,   324,   325,   326,   327,   328,   329,   330,   331,
     333,   336,   339,   341,   344,   347,   350,   353,   354,   356,
     359,   362,   364,   367,   370,   373,   375,   377,   380,   383,
     386,   389,   392,   395,   398,   402,   405,   407,   409,   411,
     414,   417,   420,   423,   427,   429,   431,   433,   436,   440,
     444,   448,   453,   455,   457,   459,   462,   464,   467,   468,
     469,   470,   471,   472,   473,   474,   475,   477,   480,   483,
     486,   489,   492,   495,   498,   501,   504,   507,   510,   513,
     515,   518,   521,   524,   525,   527,   528,   530,   531,   533,
     536,   539,   541,   544,   547,   550,   553,   556,   559,   562,
     562,   565,   565,   568,   568,   571,   571,   574,   574,   577,
     577,   580,   580,   583,   583,   586,   586,   589,   592,   592,
     595,   595,   598,   601,   601,   604,   604,   607,   610,   613,
     616,   619,   622,   626,   628,   631,   633,   635,   637,   640,
     641,   643,   646,   647,   649,   650,   652,   655,   655,   657,
     658,   660,   661,   662,   663,   664,   666,   669,   671,   674,
     676,   679,   682,   685,   686,   688,   689,   691,   694,   696,
     697,   699,   700,   702,   704,   707,   708,   710,   711,   713,
     715,   718,   719,   721,   722,   724,   727,   728,   730,   731,
     733,   736,   737,   739,   740,   742,   744,   746,   748,   751,
     752,   754,   755,   757,   759,   761,   764,   765,   767,   768,
     770,   772,   772,   774,   777,   780,   783,   785,   787,   789,
     793,   795,   796,   798,   798,   799,   800,   802,   805,   807,
     808,   810,   812,   815,   817,   820,   821,   823,   825,   827,
     829,   831,   834,   837,   840,   840,   843,   846,   849,   850,
     851,   852,   853,   855,   856,   858,   861,   862,   864,   866,
     866,   868,   868,   868,   868,   870,   873,   875,   878,   880,
     883,   886,   899,   908,   911,   914,   917,   922,   927,   930,
     932,   934,   936,   938,   939,   941,   942,   943,   944,   945,
     946,   948,   950,   951,   953,   954,   956,   959,   960,   961,
     962,   963,   964,   965,   966,   967,   969,   971,   975,   974,
     979,   981,   983,   986,   989,   990
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "PATH", "QPATH",
  "FILENAME", "COMMON", "CLASS", "CONSTRAIN", "VALIDATETRANS", "INHERITS",
  "SID", "ROLE", "ROLEATTRIBUTE", "ATTRIBUTE_ROLE", "ROLES", "TYPEALIAS",
  "TYPEATTRIBUTE", "TYPEBOUNDS", "TYPE", "TYPES", "ALIAS", "ATTRIBUTE",
  "EXPANDATTRIBUTE", "BOOL", "TUNABLE", "IF", "ELSE", "TYPE_TRANSITION",
  "TYPE_MEMBER", "TYPE_CHANGE", "ROLE_TRANSITION", "RANGE_TRANSITION",
  "SENSITIVITY", "DOMINANCE", "DOM", "DOMBY", "INCOMP", "CATEGORY",
  "LEVEL", "RANGE", "MLSCONSTRAIN", "MLSVALIDATETRANS", "USER",
  "NEVERALLOW", "ALLOW", "AUDITALLOW", "AUDITDENY", "DONTAUDIT",
  "ALLOWXPERM", "AUDITALLOWXPERM", "DONTAUDITXPERM", "NEVERALLOWXPERM",
  "SOURCE", "TARGET", "SAMEUSER", "FSCON", "PORTCON", "NETIFCON",
  "NODECON", "IBPKEYCON", "IBENDPORTCON", "PIRQCON", "IOMEMCON",
  "IOPORTCON", "PCIDEVICECON", "DEVICETREECON", "FSUSEXATTR", "FSUSETASK",
  "FSUSETRANS", "GENFSCON", "U1", "U2", "U3", "R1", "R2", "R3", "T1", "T2",
  "T3", "L1", "L2", "H1", "H2", "NOT", "AND", "OR", "XOR", "CTRUE",
  "CFALSE", "IDENTIFIER", "NUMBER", "EQUALS", "NOTEQUAL", "IPV4_ADDR",
  "IPV4_CIDR", "IPV6_ADDR", "IPV6_CIDR", "MODULE", "VERSION_IDENTIFIER",
  "REQUIRE", "OPTIONAL", "POLICYCAP", "PERMISSIVE", "FILESYSTEM",
  "DEFAULT_USER", "DEFAULT_ROLE", "DEFAULT_TYPE", "DEFAULT_RANGE",
  "LOW_HIGH", "LOW", "HIGH", "GLBLUB", "INVALID_CHAR", "'{'", "'}'", "';'",
  "':'", "','", "'('", "')'", "'-'", "'~'", "'*'", "$accept", "policy",
  "base_policy", "$@1", "$@2", "$@3", "classes", "class_def",
  "initial_sids", "initial_sid_def", "access_vectors", "opt_common_perms",
  "common_perms", "common_perms_def", "av_perms", "av_perms_def",
  "opt_default_rules", "default_rules", "default_user_def",
  "default_role_def", "default_type_def", "default_range_def", "opt_mls",
  "mls", "sensitivities", "sensitivity_def", "alias_def", "dominance",
  "opt_categories", "categories", "category_def", "levels", "level_def",
  "mlspolicy", "mlspolicy_decl", "mlsconstraint_def",
  "mlsvalidatetrans_def", "te_rbac", "te_rbac_decl", "rbac_decl",
  "te_decl", "attribute_def", "expandattribute_def", "type_def",
  "typealias_def", "typeattribute_def", "typebounds_def", "opt_attr_list",
  "bool_def", "tunable_def", "bool_val", "cond_stmt_def", "cond_else",
  "cond_expr", "cond_expr_prim", "cond_pol_list", "cond_rule_def",
  "cond_transition_def", "cond_te_avtab_def", "cond_allow_def",
  "cond_auditallow_def", "cond_auditdeny_def", "cond_dontaudit_def",
  "transition_def", "range_trans_def", "te_avtab_def", "allow_def",
  "auditallow_def", "auditdeny_def", "dontaudit_def", "neverallow_def",
  "xperm_allow_def", "xperm_auditallow_def", "xperm_dontaudit_def",
  "xperm_neverallow_def", "attribute_role_def", "role_type_def",
  "role_attr_def", "role_trans_def", "role_allow_def", "roleattribute_def",
  "opt_constraints", "constraints", "constraint_decl", "constraint_def",
  "validatetrans_def", "cexpr", "cexpr_prim", "$@4", "$@5", "$@6", "$@7",
  "$@8", "$@9", "$@10", "$@11", "$@12", "$@13", "$@14", "$@15", "$@16",
  "op", "role_mls_op", "users", "user_def", "opt_mls_user",
  "initial_sid_contexts", "initial_sid_context_def", "opt_dev_contexts",
  "dev_contexts", "dev_context_def", "pirq_context_def",
  "iomem_context_def", "ioport_context_def", "pci_context_def",
  "dtree_context_def", "opt_fs_contexts", "fs_contexts", "fs_context_def",
  "net_contexts", "opt_port_contexts", "port_contexts", "port_context_def",
  "opt_ibpkey_contexts", "ibpkey_contexts", "ibpkey_context_def",
  "opt_ibendport_contexts", "ibendport_contexts", "ibendport_context_def",
  "opt_netif_contexts", "netif_contexts", "netif_context_def",
  "opt_node_contexts", "node_contexts", "node_context_def", "opt_fs_uses",
  "fs_uses", "fs_use_def", "opt_genfs_contexts", "genfs_contexts",
  "genfs_context_def", "$@17", "ipv4_addr_def", "ipv4_cidr_def", "xperms",
  "nested_xperm_set", "nested_xperm_list", "nested_xperm_element", "$@18",
  "xperm", "security_context_def", "opt_mls_range_def", "mls_range_def",
  "mls_level_def", "id_comma_list", "tilde", "asterisk", "names", "$@19",
  "tilde_push", "asterisk_push", "names_push", "identifier_list_push",
  "identifier_push", "identifier_list", "nested_id_set", "nested_id_list",
  "nested_id_element", "$@20", "identifier", "filesystem", "path",
  "filename", "number", "number64", "ipv6_addr", "ipv6_cidr",
  "policycap_def", "permissive_def", "module_policy", "module_def",
  "version_identifier", "avrules_block", "avrule_decls", "avrule_decl",
  "require_block", "require_list", "require_decl", "require_class",
  "require_decl_def", "require_id_list", "optional_block", "$@21",
  "optional_else", "optional_decl", "else_decl", "avrule_user_defs", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-605)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-226)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     -21,    37,   163,  -605,   133,  -605,   604,  -605,   261,  -605,
      37,   255,  -605,    37,    37,    37,    37,    37,    37,    37,
      37,   -39,    37,    37,    -8,   -39,   -39,   -39,   -39,   -39,
     -39,   -39,   -39,   -39,   -39,   -39,   -39,   -39,   -39,    96,
    -605,    37,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,   388,  -605,  -605,  -605,    99,  -605,
    -605,  -605,  -605,  -605,   106,  -605,    37,  -605,    56,  -605,
      12,    37,   116,   218,    37,    37,    13,   189,    90,  -605,
    -605,   -49,  -605,    87,  -605,   215,    87,    87,    -8,    -8,
     240,  -605,  -605,   -39,   -39,   -39,   -39,   -39,   -39,   -39,
     -39,   -39,   -39,   -39,   -39,   -39,   -39,   438,   193,    37,
     310,  -605,  -605,   604,  -605,  -605,    37,  -605,  -605,   418,
     442,  -605,   -39,    37,   335,   248,  -605,  -605,   -39,   342,
     263,   328,   350,   359,  -605,  -605,  -605,    47,  -605,  -605,
    -605,  -605,  -605,  -605,   377,  -605,   381,   392,   228,   114,
      -8,    -8,    -8,    -8,    -8,  -605,   373,   397,   403,   -26,
     103,   409,   241,   410,   411,   412,   413,   414,   415,   416,
      37,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
      23,  -605,   430,    37,  -605,   498,  -605,   420,   433,   291,
      37,   418,  -605,  -605,   432,   431,  -605,  -605,    37,  -605,
    -605,  -605,  -605,   434,  -605,    37,  -605,  -605,  -605,    37,
    -605,  -605,  -605,   228,   225,   182,  -605,  -605,   136,   -39,
     -39,   -39,   -39,   435,   -39,   436,   448,   417,   -39,  -605,
     -39,   -39,   -39,   -39,   -39,   -39,   -39,   -39,   -39,  -605,
    -605,  -605,  -605,   338,   -39,  -605,    37,   -39,   -39,   -39,
     -39,   532,   291,  -605,  -605,  -605,  -605,    -2,  -605,  -605,
    -605,  -605,  -605,  -605,   -39,   -39,   -39,   -39,   -39,   -39,
     -39,   546,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
      37,    37,    37,    37,  -605,    37,  -605,    37,    37,   -39,
     -39,   -39,   -39,   -39,    37,    37,    37,    37,  -605,  -605,
      37,   539,   554,   -35,  -605,   355,   376,   419,   -10,    37,
     809,  -605,   444,  -605,  -605,  -605,  -605,  -605,    37,    37,
     -39,   -39,   -39,   -39,   -39,   -39,   -39,   472,  -605,     5,
     469,   473,   474,   475,  -605,   431,   476,   477,   481,   482,
     483,    94,    94,    94,    94,  -605,    37,   484,  -605,  -605,
     487,  -605,  -605,   486,   488,   490,   491,   495,   496,   279,
     283,   497,    10,    37,  -605,   493,  -605,  -605,  -605,  -605,
    -605,  -605,   -33,  -605,   549,   489,   108,   502,   507,   508,
     514,   520,   521,   522,  -605,  -605,  -605,   499,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,    29,   524,  -605,
    -605,    29,  -605,   525,   526,   527,   548,  -605,   604,  -605,
    -605,  -605,  -605,  -605,  -605,   528,   541,   542,   543,   544,
     545,  -605,  -605,   547,   550,  -605,    80,  -605,    37,  -605,
      37,   569,   549,  -605,    37,  -605,   -39,   -39,   -39,   -39,
     -39,   -39,   -39,   224,  -605,  -605,   220,  -605,   551,  -605,
    -605,  -605,  -605,  -605,  -605,    37,   552,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,   -39,   -39,  -605,   471,  -605,
    -605,  -605,  -605,   115,    25,    37,   320,  -605,  -605,   165,
      37,    37,    37,   -39,   -39,   -39,   -39,  -605,  -605,  -605,
    -605,  -605,  -605,   -39,   296,   603,  -605,  -605,  -605,   553,
     366,   -39,   -39,  -605,   443,  -605,  -605,  -605,  -605,    20,
     555,   557,   560,   561,   565,   566,   571,   296,    17,   141,
     344,  -605,   394,   394,   394,    17,   394,   394,   394,   394,
     394,    17,    17,    17,   296,   296,   -15,  -605,    37,    63,
    -605,  -605,  -605,    37,   -39,   296,  -605,  -605,   567,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,    72,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,   592,  -605,
    -605,   590,   593,  -605,  -605,   606,  -605,  -605,   345,   587,
     378,  -605,    39,   296,   296,  -605,    37,   571,  -605,   374,
     629,  -605,   351,   296,   140,  -605,  -605,   154,   154,   154,
     154,  -605,   154,   154,   154,   154,  -605,   154,   154,  -605,
     154,   154,   154,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,   601,  -605,   570,   571,   169,    37,    37,   618,   374,
    -605,  -605,  -605,   178,  -605,  -605,   599,  -605,  -605,   -11,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,    37,    37,  -605,  -605,    37,
      37,    37,   169,   633,   618,  -605,  -605,  -605,   171,  -605,
     599,  -605,   574,    37,   577,   578,   579,   492,    37,   321,
     638,   633,  -605,  -605,  -605,  -605,   188,    37,  -605,  -605,
    -605,  -605,  -605,  -605,   -17,   571,   571,   607,   571,   571,
     492,   639,   321,  -605,  -605,  -605,  -605,  -605,  -605,    37,
     641,   638,  -605,  -605,  -605,   584,    65,  -605,   124,    37,
    -605,   137,   158,    37,    37,   612,   642,   639,  -605,  -605,
      37,   327,  -605,   641,  -605,  -605,    37,  -605,  -605,    37,
     571,  -605,  -605,   607,  -605,   571,  -605,  -605,  -605,  -605,
     571,    37,  -605,   642,  -605,  -605,    37,  -605,  -605,   608,
      37,   612,    37,  -605,  -605,    37,  -605,    37,    37,    37,
     160,   571,  -605,  -605,    37,  -605,    37,  -605,  -605,  -605,
    -605,  -605,   571,  -605,    37,  -605,  -605,    37,  -605,  -605
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
       4,     0,     0,     2,     0,     3,     0,   355,     0,     1,
       0,     0,     8,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     402,     0,   380,   375,   376,    88,    89,    90,    91,    92,
      93,    94,    95,   377,    96,    97,    98,   148,   149,   150,
     151,   152,   153,   154,   155,   156,    82,    83,    87,    84,
      85,    86,    99,   367,   405,   374,   378,   379,     0,   361,
     304,   369,   371,   370,     0,    10,     0,     9,    16,    11,
     108,     0,     0,     0,     0,     0,   108,     0,     0,   327,
     328,     0,   331,     0,   330,   329,     0,     0,     0,     0,
       0,   123,   124,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     405,   373,   372,     0,   368,    13,     0,    12,     5,     0,
      15,    17,     0,     0,     0,     0,   325,   166,     0,     0,
       0,     0,   108,     0,   100,   352,   354,     0,   349,   351,
     333,   332,   111,   112,     0,   334,     0,     0,   117,     0,
       0,     0,     0,     0,     0,   126,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   387,   390,   388,   389,   392,   393,   394,   395,   391,
       0,   383,     0,     0,   366,     0,   404,     0,     0,    26,
       0,    14,    20,    18,     0,   107,   168,   172,     0,    55,
     104,   105,   106,     0,   103,     0,   348,   350,   101,     0,
     109,   110,   116,   118,   119,   120,   121,   122,     0,     0,
       0,     0,     0,     0,     0,     0,   322,   324,     0,   171,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   381,
     382,   384,   396,     0,     0,   398,     0,     0,     0,     0,
       0,    49,    25,    27,    28,    29,    30,     0,    21,   167,
     326,   102,   353,   335,     0,     0,     0,     0,     0,     0,
       0,   115,   125,   127,   128,   134,   135,   136,   137,   129,
       0,     0,     0,     0,   169,     0,   146,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   386,   385,
       0,   233,   401,     0,   346,     0,     0,     0,     0,     0,
       0,    48,     0,    51,    31,    32,    33,    34,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   113,     0,
       0,     0,     0,     0,   321,   323,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   397,     0,     0,   403,   399,
       0,    19,   347,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    81,     0,    74,    77,    76,    78,
      80,    79,     0,    52,    59,    23,     0,     0,     0,     0,
       0,     0,     0,     0,   126,   360,   143,     0,   144,   145,
     170,   147,   161,   157,   158,   159,   160,     0,     0,   307,
     306,     0,   317,     0,     0,     0,     0,   231,     0,    35,
      36,    37,    38,    39,    40,     0,     0,     0,     0,     0,
       0,    47,    54,     0,     0,    75,   174,   229,     0,    56,
       0,     0,    58,    60,     0,    22,     0,     0,     0,     0,
       0,     0,     0,     0,   142,   316,     0,   311,   315,   162,
     309,   308,   163,   164,   165,     0,     0,    43,    41,    42,
      46,    44,    45,    53,   365,     0,     0,     6,   173,   175,
     177,   178,   230,     0,     0,     0,     0,    64,    61,     0,
       0,     0,     0,     0,     0,     0,     0,   114,   310,   312,
     313,   232,   400,     0,     0,     0,   176,    57,    63,     0,
       0,     0,     0,    65,    50,    68,    70,    71,    24,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   207,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   185,     0,   254,
     234,    62,    67,     0,     0,     0,    69,   131,     0,   132,
     133,   138,   139,   140,   141,   314,     0,   226,   227,   228,
     223,   224,   225,   212,   208,   213,   210,   215,   189,   191,
     193,   195,     0,   197,   199,   201,   203,   205,     0,     0,
       0,   182,     0,     0,     0,   180,     0,     0,   235,   290,
     253,   255,     0,     0,     0,   130,   179,     0,     0,     0,
       0,   186,     0,     0,     0,     0,   187,     0,     0,   188,
       0,     0,     0,   217,   221,   218,   222,   219,   220,   181,
     183,   184,   236,     0,     0,     0,     0,     0,   297,   289,
     291,   256,    66,     0,    73,   345,     0,   336,   337,     0,
     340,   209,   338,   214,   211,   216,   190,   192,   194,   196,
     198,   200,   202,   204,   206,     0,     0,   357,   356,     0,
       0,     0,     0,   260,   296,   298,   292,    72,     0,   343,
       0,   341,     0,     0,     0,     0,     0,     0,     0,   238,
     277,   259,   261,   299,   339,   344,     0,     0,   257,   293,
     294,   295,   358,   359,     0,     0,     0,     0,     0,     0,
       0,   266,   237,   239,   241,   242,   243,   244,   245,     0,
     282,   276,   278,   262,   342,   320,     0,   303,     0,     0,
     362,     0,     0,     0,     0,     0,   272,   265,   267,   240,
       0,     0,   258,   281,   283,   279,     0,   318,   301,     0,
       0,   263,   246,     0,   247,     0,   249,   251,   252,   363,
       0,     0,     7,   271,   273,   268,     0,   305,   364,     0,
       0,     0,     0,   284,   319,     0,   300,     0,     0,     0,
       0,     0,   274,   280,     0,   286,     0,   288,   302,   264,
     248,   250,     0,   269,     0,   285,   287,     0,   275,   270
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -605,  -605,  -605,  -605,  -605,  -605,  -605,   698,  -605,   622,
    -605,  -605,  -605,   572,  -605,   500,  -605,  -605,   445,   451,
     452,   453,  -605,  -605,  -605,   382,   -91,  -605,  -605,  -605,
     264,  -605,   219,  -605,   202,  -605,  -605,  -605,   346,  -272,
    -271,  -605,  -605,  -605,  -605,  -605,  -605,   -47,  -605,  -605,
     396,  -270,  -605,   -22,  -605,   323,  -605,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,  -605,  -605,   242,  -605,  -605,  -459,  -605,  -605,  -605,
    -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,  -605,
    -605,  -202,  -222,  -605,  -347,  -605,  -605,   170,  -605,  -605,
      11,  -605,  -605,  -605,  -605,  -605,  -605,  -605,   122,  -605,
    -605,  -605,    33,  -605,  -605,    -3,  -605,  -605,   -37,  -605,
    -605,     8,  -605,  -605,    -7,  -605,  -605,    98,  -605,  -605,
      61,  -605,  -533,  -605,   102,  -349,  -605,   282,  -605,  -397,
    -547,  -605,  -301,  -268,   -93,  -335,   -64,   782,  -605,  -605,
    -605,   -48,    60,  -469,  -332,   -65,  -605,   594,  -605,    -1,
      70,    34,   227,     3,    -6,  -604,  -605,  -605,  -605,  -605,
    -605,  -605,  -130,  -605,   679,  -232,  -605,   559,  -605,  -605,
    -605,  -267,  -605,  -605,  -605,  -605,   630
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     2,     3,     4,   209,   515,    11,    12,    88,    89,
     138,   139,   140,   141,   211,   212,   271,   272,   273,   274,
     275,   276,   330,   331,   332,   333,   149,   394,   451,   452,
     453,   496,   497,   524,   525,   526,   527,   385,   386,    43,
      44,    45,    46,    47,    48,    49,    50,   144,    51,    52,
     164,    53,   348,   110,   111,   238,   292,   293,   294,   295,
     296,   297,   298,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,   487,   488,   489,   490,   491,   556,   557,   622,   623,
     624,   625,   627,   628,   630,   631,   632,   617,   619,   618,
     620,   582,   583,   446,   130,   367,   559,   560,   721,   722,
     723,   724,   725,   726,   727,   728,   609,   610,   611,   699,
     700,   701,   702,   746,   747,   748,   772,   773,   774,   730,
     731,   732,   752,   753,   754,   648,   649,   650,   683,   684,
     685,   785,    82,   780,   418,   419,   466,   467,   536,   420,
     642,   757,   245,   246,   145,   101,   102,   103,   229,   659,
     660,   661,   688,   662,   323,   104,   157,   158,   225,   105,
     679,   714,   407,   422,   741,   770,   782,   390,    72,     5,
       6,    84,    73,    74,    75,    76,   200,   201,   202,   203,
     263,    77,   322,   369,    78,   370,   132
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
       8,   150,   151,   207,   353,   152,   299,   396,   338,    85,
     405,    83,    90,    91,    92,    93,    94,    95,    96,    97,
     468,   106,   107,   112,   471,   405,   421,   421,   421,   421,
     190,   148,   142,   156,   148,   191,   160,   192,   447,   354,
     128,     7,   193,   379,   380,   194,   148,   195,   196,   153,
     215,     7,   577,   578,   579,     7,   197,     7,   387,   388,
     389,   198,   136,   391,     7,    98,   199,    86,   465,   468,
     603,   604,   470,     7,   558,    98,   108,     1,   576,   655,
     371,   448,     7,    99,   100,   135,   168,   169,   485,   486,
     146,   242,   156,   146,   146,   601,   602,   159,   426,   492,
     161,   605,   381,   690,   736,   223,   614,   112,   112,   580,
     581,   109,   339,   387,   388,   389,   493,   465,   391,   607,
      79,   406,   499,   129,   603,   604,   442,     7,   205,   693,
     143,   143,   694,   695,   696,   208,   567,     7,   259,   575,
      10,   518,   146,   417,   640,   641,   708,   781,   233,   234,
     235,   236,   237,   584,   653,     7,   159,   603,   604,   639,
     585,    98,   226,     9,   284,   285,   286,   737,   155,   112,
     112,   112,   112,   112,   511,   162,   163,   796,   243,   247,
       7,   287,   288,   289,   290,    79,   758,   689,   616,   258,
     691,   761,   762,     7,   764,   766,   767,   768,     7,   170,
     171,   172,   262,   776,    98,     7,   173,   174,   417,   277,
     127,   155,   786,   133,     7,   355,    99,   280,   779,   705,
     244,   689,   134,   455,   282,   603,   604,     7,   283,   793,
     517,   299,   147,   795,   232,   797,    39,   705,   798,   148,
     799,   800,   801,   803,   655,   760,   794,   805,     7,   806,
       7,   291,   284,   285,   286,     7,   654,   808,   763,   677,
     809,   655,    10,   603,   604,   324,    86,   170,   656,   287,
     288,   289,   290,   678,   173,   174,    99,   100,   655,   765,
     528,   802,   657,   657,   657,   657,   704,   657,   657,   657,
     657,   443,   657,   657,   687,   657,   657,   657,   476,   349,
     350,   351,   352,   734,   247,   154,   247,   146,   538,   204,
     170,    79,   172,   361,   362,   363,   364,   173,   174,   365,
     173,   174,   372,   592,    39,   170,   171,   172,   382,   598,
     599,   600,   173,   174,   417,   508,   165,   395,   324,   507,
     588,   589,   590,   591,   593,   594,   595,   596,   597,   539,
     540,   541,    79,   129,   175,    80,   586,   249,   250,   495,
      81,   521,   522,   587,   217,   247,   218,   542,   543,   544,
     545,   546,   547,   548,   549,   550,   551,   552,   553,   221,
     554,   218,   444,   716,   717,   718,   719,   720,   435,   436,
     437,   449,   438,   439,   440,   372,   267,   268,   269,   270,
      13,    14,    15,   519,    16,    17,    18,    19,   373,   374,
      20,    21,    22,    23,    24,   555,    25,    26,    27,    28,
      29,    80,   777,   769,   778,   210,   633,   634,   635,   375,
     376,   129,    30,    31,    32,    33,    34,    35,    36,    37,
      38,   645,   646,   647,   222,   190,   218,   324,   136,   494,
     191,   216,   192,   324,   319,   784,   320,   193,   220,   637,
     194,   638,   195,   196,   423,   424,   425,   652,   143,   218,
     612,   197,   377,   378,   247,   224,   198,   329,   392,   485,
     486,   199,   562,   563,   521,   522,   580,   581,    39,    40,
     239,    41,   372,   228,   520,   712,   713,   230,   372,   529,
     530,   531,   166,   167,    42,    13,    14,    15,   231,    16,
      17,    18,    19,   264,   240,    20,    21,    22,    23,    24,
     241,    25,    26,    27,    28,    29,   248,   251,   252,   253,
     254,   255,   256,   257,   308,   265,   129,    30,    31,    32,
      33,    34,    35,    36,    37,    38,   261,   266,   279,   218,
     281,   304,   306,   658,   658,   658,   658,   606,   658,   658,
     658,   658,   146,   658,   658,   329,   658,   658,   658,   307,
     663,   664,   665,   347,   666,   667,   668,   669,   366,   670,
     671,   368,   672,   673,   674,   408,   404,   450,   475,   409,
     410,   411,   412,   413,    40,   383,    41,   414,   415,   416,
     427,   428,   429,   454,   430,   643,   431,   432,   495,   384,
     644,   433,   434,   441,   558,   464,    13,    14,    15,   456,
      16,    17,    18,    19,   457,   458,    20,    21,    22,    23,
      24,   459,    25,    26,    27,    28,    29,   460,   461,   462,
     469,   472,   473,   474,   477,   680,   681,   676,    30,    31,
      32,    33,    34,    35,    36,    37,    38,   478,   479,   480,
     481,   482,    79,   483,   621,  -225,   484,   512,   626,   561,
     636,   569,   510,   570,   692,   643,   571,   572,   643,   643,
     643,   573,   574,   615,   629,   607,   603,   675,   682,   655,
     698,   707,   643,   709,   710,   711,   729,   715,   740,   745,
     751,   756,    80,   771,    39,    40,   735,    41,   769,    87,
     137,   278,   213,   643,   393,   523,   498,   334,   738,   739,
      42,   742,   743,   335,   336,   337,   566,   463,   750,   608,
     516,   445,   651,   749,   733,   759,   792,   643,   643,   755,
     643,   643,   643,   643,   775,   703,   783,   686,   509,   643,
     706,   227,   697,   131,   744,   247,   568,   788,   643,   260,
     206,     0,     0,   787,     0,     0,     0,     0,   789,     0,
     791,     0,     0,   790,     0,   643,     0,     0,     0,   643,
       0,   643,     0,     0,   643,     0,   643,   643,   643,   643,
       0,     0,     0,   643,   804,   643,     0,     0,     0,     0,
       0,     0,     0,   643,     0,   807,   643,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,    13,    14,    15,     0,    16,    17,    18,    19,     0,
       0,    20,    21,    22,    23,    24,     0,    25,    26,    27,
      28,    29,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    30,    31,    32,    33,    34,    35,    36,
      37,    38,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   176,   177,   178,   179,   180,
     181,   182,   183,   184,   185,   186,   187,   188,   189,     0,
      40,   383,    41,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   214,   384,     0,     0,     0,     0,
     219,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   300,   301,   302,   303,     0,   305,     0,     0,     0,
     309,     0,   310,   311,   312,   313,   314,   315,   316,   317,
     318,     0,     0,     0,     0,     0,   321,     0,     0,   325,
     326,   327,   328,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   340,   341,   342,   343,
     344,   345,   346,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   356,   357,   358,   359,   360,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   397,   398,   399,   400,   401,   402,   403,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   500,   501,
     502,   503,   504,   505,   506,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   513,   514,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   532,   533,   534,   535,     0,
       0,     0,     0,     0,     0,   537,     0,     0,     0,     0,
       0,     0,     0,   564,   565,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   613
};

static const yytype_int16 yycheck[] =
{
       1,    94,    95,   133,   305,    96,   238,   339,    10,    10,
       5,     8,    13,    14,    15,    16,    17,    18,    19,    20,
     417,    22,    23,    24,   421,     5,   361,   362,   363,   364,
       7,    21,    20,    98,    21,    12,   101,    14,   385,   307,
      41,    90,    19,    53,    54,    22,    21,    24,    25,    96,
     143,    90,    35,    36,    37,    90,    33,    90,   330,   330,
     330,    38,     6,   330,    90,   114,    43,    11,   417,   466,
      85,    86,   421,    90,    11,   114,    84,    98,   537,    90,
     115,   114,    90,   122,   123,    86,   108,   109,     8,     9,
      91,   117,   157,    94,    95,   554,   555,    98,   366,   446,
     101,   116,   112,   114,   121,   152,   565,   108,   109,    92,
      93,   119,   114,   385,   385,   385,   448,   466,   385,    56,
      91,   116,   454,    43,    85,    86,   116,    90,   129,   676,
     118,   118,   679,   680,   681,   136,   116,    90,   115,   536,
       7,   116,   143,   114,   603,   604,   693,   751,   170,   171,
     172,   173,   174,    12,   613,    90,   157,    85,    86,   120,
      19,   114,   115,     0,    28,    29,    30,   714,   121,   170,
     171,   172,   173,   174,   475,    88,    89,   781,   179,   180,
      90,    45,    46,    47,    48,    91,   121,   656,   116,   190,
     659,   738,   739,    90,   741,   742,   743,   744,    90,    85,
      86,    87,   203,   750,   114,    90,    92,    93,   114,   210,
     114,   121,   759,   114,    90,   308,   122,   218,   751,   688,
     117,   690,   116,   115,   225,    85,    86,    90,   229,   776,
     115,   463,   116,   780,   120,   782,   100,   706,   785,    21,
     787,   788,   789,   790,    90,   121,   779,   794,    90,   796,
      90,   115,    28,    29,    30,    90,   116,   804,   121,    90,
     807,    90,     7,    85,    86,   266,    11,    85,   114,    45,
      46,    47,    48,   104,    92,    93,   122,   123,    90,   121,
     115,   121,   617,   618,   619,   620,   115,   622,   623,   624,
     625,   382,   627,   628,   116,   630,   631,   632,   428,   300,
     301,   302,   303,   115,   305,   116,   307,   308,    12,   116,
      85,    91,    87,   314,   315,   316,   317,    92,    93,   320,
      92,    93,   323,   545,   100,    85,    86,    87,   329,   551,
     552,   553,    92,    93,   114,   115,   121,   338,   339,   115,
     542,   543,   544,   545,   546,   547,   548,   549,   550,    53,
      54,    55,    91,    43,   114,    94,    12,   116,   117,    39,
      99,    41,    42,    19,   116,   366,   118,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,   116,
      84,   118,   383,    62,    63,    64,    65,    66,   109,   110,
     111,   392,   109,   110,   111,   396,   105,   106,   107,   108,
      12,    13,    14,   494,    16,    17,    18,    19,    53,    54,
      22,    23,    24,    25,    26,   119,    28,    29,    30,    31,
      32,    94,    95,    96,    97,     7,    81,    82,    83,    53,
      54,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    67,    68,    69,   116,     7,   118,   448,     6,   450,
      12,   116,    14,   454,   116,   756,   118,    19,   116,    81,
      22,    83,    24,    25,   362,   363,   364,   116,   118,   118,
     563,    33,    53,    54,   475,   116,    38,    33,    34,     8,
       9,    43,   116,   117,    41,    42,    92,    93,   100,   101,
     117,   103,   493,   116,   495,     3,     4,   116,   499,   500,
     501,   502,   106,   107,   116,    12,    13,    14,   116,    16,
      17,    18,    19,    15,   117,    22,    23,    24,    25,    26,
     117,    28,    29,    30,    31,    32,   117,   117,   117,   117,
     117,   117,   117,   117,   117,   115,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,   116,   114,   116,   118,
     116,   116,   116,   617,   618,   619,   620,   558,   622,   623,
     624,   625,   563,   627,   628,    33,   630,   631,   632,   121,
     618,   619,   620,    27,   622,   623,   624,   625,    39,   627,
     628,    27,   630,   631,   632,   116,   114,    38,    40,   116,
     116,   116,   116,   116,   101,   102,   103,   116,   116,   116,
     116,   114,   116,   114,   116,   606,   116,   116,    39,   116,
     607,   116,   116,   116,    11,   116,    12,    13,    14,   117,
      16,    17,    18,    19,   117,   117,    22,    23,    24,    25,
      26,   117,    28,    29,    30,    31,    32,   117,   117,   117,
     116,   116,   116,   116,   116,   646,   647,   644,    44,    45,
      46,    47,    48,    49,    50,    51,    52,   116,   116,   116,
     116,   116,    91,   116,    72,    75,   116,   115,    75,   116,
      83,   116,   121,   116,   675,   676,   116,   116,   679,   680,
     681,   116,   116,   116,    78,    56,    85,   117,    70,    90,
      57,   117,   693,   116,   116,   116,    58,   698,    91,    60,
      59,   117,    94,    61,   100,   101,   707,   103,    96,    11,
      88,   211,   140,   714,   332,   496,   452,   272,   715,   716,
     116,   718,   719,   272,   272,   272,   524,   404,   729,   559,
     488,   385,   610,   722,   701,   736,   773,   738,   739,   731,
     741,   742,   743,   744,   747,   684,   753,   649,   466,   750,
     690,   157,   682,    74,   720,   756,   529,   763,   759,   200,
     130,    -1,    -1,   760,    -1,    -1,    -1,    -1,   765,    -1,
     771,    -1,    -1,   770,    -1,   776,    -1,    -1,    -1,   780,
      -1,   782,    -1,    -1,   785,    -1,   787,   788,   789,   790,
      -1,    -1,    -1,   794,   791,   796,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   804,    -1,   802,   807,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    12,    13,    14,    -1,    16,    17,    18,    19,    -1,
      -1,    22,    23,    24,    25,    26,    -1,    28,    29,    30,
      31,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   126,    -1,
     101,   102,   103,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   142,   116,    -1,    -1,    -1,    -1,
     148,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   239,   240,   241,   242,    -1,   244,    -1,    -1,    -1,
     248,    -1,   250,   251,   252,   253,   254,   255,   256,   257,
     258,    -1,    -1,    -1,    -1,    -1,   264,    -1,    -1,   267,
     268,   269,   270,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   284,   285,   286,   287,
     288,   289,   290,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   309,   310,   311,   312,   313,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   340,   341,   342,   343,   344,   345,   346,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   456,   457,
     458,   459,   460,   461,   462,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   485,   486,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   503,   504,   505,   506,    -1,
      -1,    -1,    -1,    -1,    -1,   513,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   521,   522,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   564
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,    98,   125,   126,   127,   303,   304,    90,   293,     0,
       7,   130,   131,    12,    13,    14,    16,    17,    18,    19,
      22,    23,    24,    25,    26,    28,    29,    30,    31,    32,
      44,    45,    46,    47,    48,    49,    50,    51,    52,   100,
     101,   103,   116,   163,   164,   165,   166,   167,   168,   169,
     170,   172,   173,   175,   187,   188,   189,   190,   191,   192,
     193,   194,   195,   196,   197,   198,   199,   200,   201,   202,
     203,   204,   302,   306,   307,   308,   309,   315,   318,    91,
      94,    99,   266,   297,   305,   293,    11,   131,   132,   133,
     293,   293,   293,   293,   293,   293,   293,   293,   114,   122,
     123,   279,   280,   281,   289,   293,   293,   293,    84,   119,
     177,   178,   293,   281,   281,   281,   281,   281,   281,   281,
     281,   281,   281,   281,   281,   281,   281,   114,   293,    43,
     228,   308,   320,   114,   116,   293,     6,   133,   134,   135,
     136,   137,    20,   118,   171,   278,   293,   116,    21,   150,
     278,   278,   150,   171,   116,   121,   289,   290,   291,   293,
     289,   293,    88,    89,   174,   121,   174,   174,   177,   177,
      85,    86,    87,    92,    93,   114,   281,   281,   281,   281,
     281,   281,   281,   281,   281,   281,   281,   281,   281,   281,
       7,    12,    14,    19,    22,    24,    25,    33,    38,    43,
     310,   311,   312,   313,   116,   293,   320,   306,   293,   128,
       7,   138,   139,   137,   281,   278,   116,   116,   118,   281,
     116,   116,   116,   171,   116,   292,   115,   291,   116,   282,
     116,   116,   120,   177,   177,   177,   177,   177,   179,   117,
     117,   117,   117,   293,   117,   276,   277,   293,   117,   116,
     117,   117,   117,   117,   117,   117,   117,   117,   293,   115,
     311,   116,   293,   314,    15,   115,   114,   105,   106,   107,
     108,   140,   141,   142,   143,   144,   145,   293,   139,   116,
     293,   116,   293,   293,    28,    29,    30,    45,    46,    47,
      48,   115,   180,   181,   182,   183,   184,   185,   186,   309,
     281,   281,   281,   281,   116,   281,   116,   121,   117,   281,
     281,   281,   281,   281,   281,   281,   281,   281,   281,   116,
     118,   281,   316,   288,   293,   281,   281,   281,   281,    33,
     146,   147,   148,   149,   142,   143,   144,   145,    10,   114,
     281,   281,   281,   281,   281,   281,   281,    27,   176,   293,
     293,   293,   293,   276,   277,   278,   281,   281,   281,   281,
     281,   293,   293,   293,   293,   293,    39,   229,    27,   317,
     319,   115,   293,    53,    54,    53,    54,    53,    54,    53,
      54,   112,   293,   102,   116,   161,   162,   163,   164,   175,
     301,   315,    34,   149,   151,   293,   288,   281,   281,   281,
     281,   281,   281,   281,   114,     5,   116,   296,   116,   116,
     116,   116,   116,   116,   116,   116,   116,   114,   268,   269,
     273,   279,   297,   268,   268,   268,   277,   116,   114,   116,
     116,   116,   116,   116,   116,   109,   110,   111,   109,   110,
     111,   116,   116,   150,   293,   162,   227,   228,   114,   293,
      38,   152,   153,   154,   114,   115,   117,   117,   117,   117,
     117,   117,   117,   179,   116,   269,   270,   271,   273,   116,
     269,   273,   116,   116,   116,    40,   306,   116,   116,   116,
     116,   116,   116,   116,   116,     8,     9,   205,   206,   207,
     208,   209,   228,   288,   293,    39,   155,   156,   154,   288,
     281,   281,   281,   281,   281,   281,   281,   115,   115,   271,
     121,   276,   115,   281,   281,   129,   207,   115,   116,   150,
     293,    41,    42,   156,   157,   158,   159,   160,   115,   293,
     293,   293,   281,   281,   281,   281,   272,   281,    12,    53,
      54,    55,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    84,   119,   210,   211,    11,   230,
     231,   116,   116,   117,   281,   281,   158,   116,   296,   116,
     116,   116,   116,   116,   116,   273,   210,    35,    36,    37,
      92,    93,   225,   226,    12,    19,    12,    19,   225,   225,
     225,   225,   226,   225,   225,   225,   225,   225,   226,   226,
     226,   210,   210,    85,    86,   116,   293,    56,   231,   240,
     241,   242,   278,   281,   210,   116,   116,   221,   223,   222,
     224,    72,   212,   213,   214,   215,    75,   216,   217,    78,
     218,   219,   220,    81,    82,    83,    83,    81,    83,   120,
     210,   210,   274,   293,   297,    67,    68,    69,   259,   260,
     261,   242,   116,   210,   116,    90,   114,   279,   280,   283,
     284,   285,   287,   285,   285,   285,   285,   285,   285,   285,
     285,   285,   285,   285,   285,   117,   297,    90,   104,   294,
     293,   293,    70,   262,   263,   264,   261,   116,   286,   287,
     114,   287,   293,   274,   274,   274,   274,   294,    57,   243,
     244,   245,   246,   264,   115,   287,   286,   117,   274,   116,
     116,   116,     3,     4,   295,   293,    62,    63,    64,    65,
      66,   232,   233,   234,   235,   236,   237,   238,   239,    58,
     253,   254,   255,   246,   115,   293,   121,   274,   297,   297,
      91,   298,   297,   297,   295,    60,   247,   248,   249,   234,
     293,    59,   256,   257,   258,   255,   117,   275,   121,   293,
     121,   274,   274,   121,   274,   121,   274,   274,   274,    96,
     299,    61,   250,   251,   252,   249,   274,    95,    97,   266,
     267,   299,   300,   258,   276,   265,   274,   297,   298,   297,
     297,   293,   252,   274,   266,   274,   299,   274,   274,   274,
     274,   274,   121,   274,   297,   274,   274,   297,   274,   274
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   124,   125,   125,   127,   128,   129,   126,   130,   130,
     131,   132,   132,   133,   134,   135,   135,   136,   136,   137,
     138,   138,   139,   139,   139,   140,   140,   141,   141,   141,
     141,   141,   141,   141,   141,   142,   142,   143,   143,   144,
     144,   145,   145,   145,   145,   145,   145,   145,   146,   146,
     147,   148,   148,   149,   149,   150,   151,   151,   152,   152,
     153,   153,   154,   154,   155,   155,   156,   156,   157,   157,
     158,   158,   159,   160,   161,   161,   162,   162,   162,   162,
     162,   162,   163,   163,   163,   163,   163,   163,   164,   164,
     164,   164,   164,   164,   164,   164,   164,   164,   164,   164,
     165,   166,   167,   167,   168,   169,   170,   171,   171,   172,
     173,   174,   174,   175,   176,   176,   177,   177,   177,   177,
     177,   177,   177,   177,   178,   179,   179,   180,   180,   180,
     181,   181,   181,   181,   182,   182,   182,   182,   183,   184,
     185,   186,   187,   187,   187,   187,   188,   188,   189,   189,
     189,   189,   189,   189,   189,   189,   189,   190,   191,   192,
     193,   194,   195,   196,   197,   198,   199,   200,   201,   202,
     202,   203,   204,   205,   205,   206,   206,   207,   207,   208,
     209,   210,   210,   210,   210,   210,   211,   211,   211,   212,
     211,   213,   211,   214,   211,   215,   211,   216,   211,   217,
     211,   218,   211,   219,   211,   220,   211,   211,   221,   211,
     222,   211,   211,   223,   211,   224,   211,   211,   211,   211,
     211,   211,   211,   225,   225,   226,   226,   226,   226,   227,
     227,   228,   229,   229,   230,   230,   231,   232,   232,   233,
     233,   234,   234,   234,   234,   234,   235,   236,   236,   237,
     237,   238,   239,   240,   240,   241,   241,   242,   243,   244,
     244,   245,   245,   246,   246,   247,   247,   248,   248,   249,
     249,   250,   250,   251,   251,   252,   253,   253,   254,   254,
     255,   256,   256,   257,   257,   258,   258,   258,   258,   259,
     259,   260,   260,   261,   261,   261,   262,   262,   263,   263,
     264,   265,   264,   264,   266,   267,   268,   268,   268,   268,
     269,   270,   270,   272,   271,   271,   271,   273,   274,   275,
     275,   276,   276,   277,   277,   278,   278,   279,   280,   281,
     281,   281,   281,   281,   282,   281,   283,   284,   285,   285,
     285,   285,   285,   286,   286,   287,   288,   288,   289,   290,
     290,   291,   292,   291,   291,   293,   294,   294,   295,   295,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     305,   305,   306,   307,   307,   308,   308,   308,   308,   308,
     308,   309,   310,   310,   311,   311,   312,   313,   313,   313,
     313,   313,   313,   313,   313,   313,   314,   314,   316,   315,
     317,   317,   318,   319,   320,   320
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     0,     0,     0,    19,     1,     2,
       2,     1,     2,     2,     2,     1,     0,     1,     2,     5,
       1,     2,     5,     4,     7,     1,     0,     1,     1,     1,
       1,     2,     2,     2,     2,     4,     4,     4,     4,     4,
       4,     5,     5,     5,     5,     5,     5,     4,     1,     0,
       5,     1,     2,     4,     3,     2,     2,     4,     1,     0,
       1,     2,     4,     3,     1,     2,     5,     3,     1,     2,
       1,     1,     5,     4,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       3,     4,     5,     4,     4,     4,     4,     2,     0,     4,
       4,     1,     1,     6,     4,     0,     3,     2,     3,     3,
       3,     3,     3,     1,     1,     2,     0,     1,     1,     1,
       8,     7,     7,     7,     1,     1,     1,     1,     7,     7,
       7,     7,     8,     7,     7,     7,     5,     7,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     7,     7,     7,
       7,     7,     8,     8,     8,     8,     3,     5,     4,     5,
       7,     4,     4,     1,     0,     1,     2,     1,     1,     5,
       4,     3,     2,     3,     3,     1,     3,     3,     3,     0,
       4,     0,     4,     0,     4,     0,     4,     0,     4,     0,
       4,     0,     4,     0,     4,     0,     4,     1,     0,     4,
       0,     4,     2,     0,     4,     0,     4,     3,     3,     3,
       3,     3,     3,     1,     1,     1,     1,     1,     1,     1,
       2,     6,     4,     0,     1,     2,     3,     1,     0,     1,
       2,     1,     1,     1,     1,     1,     3,     3,     5,     3,
       5,     3,     3,     1,     0,     1,     2,     5,     3,     1,
       0,     1,     2,     4,     6,     1,     0,     1,     2,     4,
       6,     1,     0,     1,     2,     4,     1,     0,     1,     2,
       4,     1,     0,     1,     2,     4,     3,     4,     3,     1,
       0,     1,     2,     4,     4,     4,     1,     0,     1,     2,
       6,     0,     7,     4,     1,     1,     1,     1,     2,     2,
       3,     1,     2,     0,     4,     1,     1,     1,     6,     2,
       0,     3,     1,     3,     1,     1,     3,     1,     1,     1,
       1,     1,     2,     2,     0,     4,     1,     1,     1,     3,
       1,     2,     4,     1,     2,     1,     1,     2,     3,     1,
       2,     1,     0,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     3,     2,     4,     1,
       1,     1,     2,     2,     1,     1,     1,     1,     1,     1,
       1,     4,     2,     1,     2,     3,     3,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     0,     6,
       4,     0,     1,     1,     2,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 4: /* $@1: %empty  */
#line 168 "policy_parse.y"
                          { if (define_policy(pass, 0) == -1) YYABORT; }
#line 2421 "y.tab.c"
    break;

  case 5: /* $@2: %empty  */
#line 170 "policy_parse.y"
                          { if (pass == 1) { if (policydb_index_classes(policydbp)) YYABORT; }
                            else if (pass == 2) { if (policydb_index_others(NULL, policydbp, 0)) YYABORT; }}
#line 2428 "y.tab.c"
    break;

  case 6: /* $@3: %empty  */
#line 173 "policy_parse.y"
                         { if (pass == 1) { if (policydb_index_bools(policydbp)) YYABORT; }
			   else if (pass == 2) { if (policydb_index_others(NULL, policydbp, 0)) YYABORT; }}
#line 2435 "y.tab.c"
    break;

  case 10: /* class_def: CLASS identifier  */
#line 181 "policy_parse.y"
                        {if (define_class()) YYABORT;}
#line 2441 "y.tab.c"
    break;

  case 13: /* initial_sid_def: SID identifier  */
#line 187 "policy_parse.y"
                        {if (define_initial_sid()) YYABORT;}
#line 2447 "y.tab.c"
    break;

  case 19: /* common_perms_def: COMMON identifier '{' identifier_list '}'  */
#line 198 "policy_parse.y"
                        {if (define_common_perms()) YYABORT;}
#line 2453 "y.tab.c"
    break;

  case 22: /* av_perms_def: CLASS identifier '{' identifier_list '}'  */
#line 204 "policy_parse.y"
                        {if (define_av_perms(FALSE)) YYABORT;}
#line 2459 "y.tab.c"
    break;

  case 23: /* av_perms_def: CLASS identifier INHERITS identifier  */
#line 206 "policy_parse.y"
                        {if (define_av_perms(TRUE)) YYABORT;}
#line 2465 "y.tab.c"
    break;

  case 24: /* av_perms_def: CLASS identifier INHERITS identifier '{' identifier_list '}'  */
#line 208 "policy_parse.y"
                        {if (define_av_perms(TRUE)) YYABORT;}
#line 2471 "y.tab.c"
    break;

  case 35: /* default_user_def: DEFAULT_USER names SOURCE ';'  */
#line 223 "policy_parse.y"
                        {if (define_default_user(DEFAULT_SOURCE)) YYABORT; }
#line 2477 "y.tab.c"
    break;

  case 36: /* default_user_def: DEFAULT_USER names TARGET ';'  */
#line 225 "policy_parse.y"
                        {if (define_default_user(DEFAULT_TARGET)) YYABORT; }
#line 2483 "y.tab.c"
    break;

  case 37: /* default_role_def: DEFAULT_ROLE names SOURCE ';'  */
#line 228 "policy_parse.y"
                        {if (define_default_role(DEFAULT_SOURCE)) YYABORT; }
#line 2489 "y.tab.c"
    break;

  case 38: /* default_role_def: DEFAULT_ROLE names TARGET ';'  */
#line 230 "policy_parse.y"
                        {if (define_default_role(DEFAULT_TARGET)) YYABORT; }
#line 2495 "y.tab.c"
    break;

  case 39: /* default_type_def: DEFAULT_TYPE names SOURCE ';'  */
#line 233 "policy_parse.y"
                        {if (define_default_type(DEFAULT_SOURCE)) YYABORT;; }
#line 2501 "y.tab.c"
    break;

  case 40: /* default_type_def: DEFAULT_TYPE names TARGET ';'  */
#line 235 "policy_parse.y"
                        {if (define_default_type(DEFAULT_TARGET)) YYABORT; }
#line 2507 "y.tab.c"
    break;

  case 41: /* default_range_def: DEFAULT_RANGE names SOURCE LOW ';'  */
#line 238 "policy_parse.y"
                        {if (define_default_range(DEFAULT_SOURCE_LOW)) YYABORT; }
#line 2513 "y.tab.c"
    break;

  case 42: /* default_range_def: DEFAULT_RANGE names SOURCE HIGH ';'  */
#line 240 "policy_parse.y"
                        {if (define_default_range(DEFAULT_SOURCE_HIGH)) YYABORT; }
#line 2519 "y.tab.c"
    break;

  case 43: /* default_range_def: DEFAULT_RANGE names SOURCE LOW_HIGH ';'  */
#line 242 "policy_parse.y"
                        {if (define_default_range(DEFAULT_SOURCE_LOW_HIGH)) YYABORT; }
#line 2525 "y.tab.c"
    break;

  case 44: /* default_range_def: DEFAULT_RANGE names TARGET LOW ';'  */
#line 244 "policy_parse.y"
                        {if (define_default_range(DEFAULT_TARGET_LOW)) YYABORT; }
#line 2531 "y.tab.c"
    break;

  case 45: /* default_range_def: DEFAULT_RANGE names TARGET HIGH ';'  */
#line 246 "policy_parse.y"
                        {if (define_default_range(DEFAULT_TARGET_HIGH)) YYABORT; }
#line 2537 "y.tab.c"
    break;

  case 46: /* default_range_def: DEFAULT_RANGE names TARGET LOW_HIGH ';'  */
#line 248 "policy_parse.y"
                        {if (define_default_range(DEFAULT_TARGET_LOW_HIGH)) YYABORT; }
#line 2543 "y.tab.c"
    break;

  case 47: /* default_range_def: DEFAULT_RANGE names GLBLUB ';'  */
#line 250 "policy_parse.y"
                        {if (define_default_range(DEFAULT_GLBLUB)) YYABORT; }
#line 2549 "y.tab.c"
    break;

  case 53: /* sensitivity_def: SENSITIVITY identifier alias_def ';'  */
#line 261 "policy_parse.y"
                        {if (define_sens()) YYABORT;}
#line 2555 "y.tab.c"
    break;

  case 54: /* sensitivity_def: SENSITIVITY identifier ';'  */
#line 263 "policy_parse.y"
                        {if (define_sens()) YYABORT;}
#line 2561 "y.tab.c"
    break;

  case 56: /* dominance: DOMINANCE identifier  */
#line 268 "policy_parse.y"
                        {if (define_dominance()) YYABORT;}
#line 2567 "y.tab.c"
    break;

  case 57: /* dominance: DOMINANCE '{' identifier_list '}'  */
#line 270 "policy_parse.y"
                        {if (define_dominance()) YYABORT;}
#line 2573 "y.tab.c"
    break;

  case 62: /* category_def: CATEGORY identifier alias_def ';'  */
#line 279 "policy_parse.y"
                        {if (define_category()) YYABORT;}
#line 2579 "y.tab.c"
    break;

  case 63: /* category_def: CATEGORY identifier ';'  */
#line 281 "policy_parse.y"
                        {if (define_category()) YYABORT;}
#line 2585 "y.tab.c"
    break;

  case 66: /* level_def: LEVEL identifier ':' id_comma_list ';'  */
#line 287 "policy_parse.y"
                        {if (define_level()) YYABORT;}
#line 2591 "y.tab.c"
    break;

  case 67: /* level_def: LEVEL identifier ';'  */
#line 289 "policy_parse.y"
                        {if (define_level()) YYABORT;}
#line 2597 "y.tab.c"
    break;

  case 72: /* mlsconstraint_def: MLSCONSTRAIN names names cexpr ';'  */
#line 298 "policy_parse.y"
                        { if (define_constraint((constraint_expr_t*)(yyvsp[-1].valptr))) YYABORT; }
#line 2603 "y.tab.c"
    break;

  case 73: /* mlsvalidatetrans_def: MLSVALIDATETRANS names cexpr ';'  */
#line 301 "policy_parse.y"
                        { if (define_validatetrans((constraint_expr_t*)(yyvsp[-1].valptr))) YYABORT; }
#line 2609 "y.tab.c"
    break;

  case 100: /* attribute_def: ATTRIBUTE identifier ';'  */
#line 334 "policy_parse.y"
                        { if (define_attrib()) YYABORT;}
#line 2615 "y.tab.c"
    break;

  case 101: /* expandattribute_def: EXPANDATTRIBUTE names bool_val ';'  */
#line 337 "policy_parse.y"
                        { if (expand_attrib()) YYABORT;}
#line 2621 "y.tab.c"
    break;

  case 102: /* type_def: TYPE identifier alias_def opt_attr_list ';'  */
#line 340 "policy_parse.y"
                        {if (define_type(1)) YYABORT;}
#line 2627 "y.tab.c"
    break;

  case 103: /* type_def: TYPE identifier opt_attr_list ';'  */
#line 342 "policy_parse.y"
                        {if (define_type(0)) YYABORT;}
#line 2633 "y.tab.c"
    break;

  case 104: /* typealias_def: TYPEALIAS identifier alias_def ';'  */
#line 345 "policy_parse.y"
                        {if (define_typealias()) YYABORT;}
#line 2639 "y.tab.c"
    break;

  case 105: /* typeattribute_def: TYPEATTRIBUTE identifier id_comma_list ';'  */
#line 348 "policy_parse.y"
                        {if (define_typeattribute()) YYABORT;}
#line 2645 "y.tab.c"
    break;

  case 106: /* typebounds_def: TYPEBOUNDS identifier id_comma_list ';'  */
#line 351 "policy_parse.y"
                        {if (define_typebounds()) YYABORT;}
#line 2651 "y.tab.c"
    break;

  case 109: /* bool_def: BOOL identifier bool_val ';'  */
#line 357 "policy_parse.y"
                        { if (define_bool_tunable(0)) YYABORT; }
#line 2657 "y.tab.c"
    break;

  case 110: /* tunable_def: TUNABLE identifier bool_val ';'  */
#line 360 "policy_parse.y"
                        { if (define_bool_tunable(1)) YYABORT; }
#line 2663 "y.tab.c"
    break;

  case 111: /* bool_val: CTRUE  */
#line 363 "policy_parse.y"
                        { if (insert_id("T",0)) YYABORT; }
#line 2669 "y.tab.c"
    break;

  case 112: /* bool_val: CFALSE  */
#line 365 "policy_parse.y"
                        { if (insert_id("F",0)) YYABORT; }
#line 2675 "y.tab.c"
    break;

  case 113: /* cond_stmt_def: IF cond_expr '{' cond_pol_list '}' cond_else  */
#line 368 "policy_parse.y"
                        { if (pass == 2) { if (define_conditional((cond_expr_t*)(yyvsp[-4].ptr), (avrule_t*)(yyvsp[-2].ptr), (avrule_t*)(yyvsp[0].ptr)) < 0) YYABORT;  }}
#line 2681 "y.tab.c"
    break;

  case 114: /* cond_else: ELSE '{' cond_pol_list '}'  */
#line 371 "policy_parse.y"
                        { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 2687 "y.tab.c"
    break;

  case 115: /* cond_else: %empty  */
#line 373 "policy_parse.y"
                        { (yyval.ptr) = NULL; }
#line 2693 "y.tab.c"
    break;

  case 116: /* cond_expr: '(' cond_expr ')'  */
#line 376 "policy_parse.y"
                        { (yyval.ptr) = (yyvsp[-1].ptr);}
#line 2699 "y.tab.c"
    break;

  case 117: /* cond_expr: NOT cond_expr  */
#line 378 "policy_parse.y"
                        { (yyval.ptr) = define_cond_expr(COND_NOT, (yyvsp[0].ptr), 0);
			  if ((yyval.ptr) == 0) YYABORT; }
#line 2706 "y.tab.c"
    break;

  case 118: /* cond_expr: cond_expr AND cond_expr  */
#line 381 "policy_parse.y"
                        { (yyval.ptr) = define_cond_expr(COND_AND, (yyvsp[-2].ptr), (yyvsp[0].ptr));
			  if ((yyval.ptr) == 0) YYABORT; }
#line 2713 "y.tab.c"
    break;

  case 119: /* cond_expr: cond_expr OR cond_expr  */
#line 384 "policy_parse.y"
                        { (yyval.ptr) = define_cond_expr(COND_OR, (yyvsp[-2].ptr), (yyvsp[0].ptr));
			  if ((yyval.ptr) == 0) YYABORT; }
#line 2720 "y.tab.c"
    break;

  case 120: /* cond_expr: cond_expr XOR cond_expr  */
#line 387 "policy_parse.y"
                        { (yyval.ptr) = define_cond_expr(COND_XOR, (yyvsp[-2].ptr), (yyvsp[0].ptr));
			  if ((yyval.ptr) == 0) YYABORT; }
#line 2727 "y.tab.c"
    break;

  case 121: /* cond_expr: cond_expr EQUALS cond_expr  */
#line 390 "policy_parse.y"
                        { (yyval.ptr) = define_cond_expr(COND_EQ, (yyvsp[-2].ptr), (yyvsp[0].ptr));
			  if ((yyval.ptr) == 0) YYABORT; }
#line 2734 "y.tab.c"
    break;

  case 122: /* cond_expr: cond_expr NOTEQUAL cond_expr  */
#line 393 "policy_parse.y"
                        { (yyval.ptr) = define_cond_expr(COND_NEQ, (yyvsp[-2].ptr), (yyvsp[0].ptr));
			  if ((yyval.ptr) == 0) YYABORT; }
#line 2741 "y.tab.c"
    break;

  case 123: /* cond_expr: cond_expr_prim  */
#line 396 "policy_parse.y"
                        { (yyval.ptr) = (yyvsp[0].ptr); }
#line 2747 "y.tab.c"
    break;

  case 124: /* cond_expr_prim: identifier  */
#line 399 "policy_parse.y"
                        { (yyval.ptr) = define_cond_expr(COND_BOOL,0, 0);
			  if ((yyval.ptr) == COND_ERR) YYABORT; }
#line 2754 "y.tab.c"
    break;

  case 125: /* cond_pol_list: cond_pol_list cond_rule_def  */
#line 403 "policy_parse.y"
                        { (yyval.ptr) = define_cond_pol_list((avrule_t *)(yyvsp[-1].ptr), (avrule_t *)(yyvsp[0].ptr)); }
#line 2760 "y.tab.c"
    break;

  case 126: /* cond_pol_list: %empty  */
#line 405 "policy_parse.y"
                        { (yyval.ptr) = NULL; }
#line 2766 "y.tab.c"
    break;

  case 127: /* cond_rule_def: cond_transition_def  */
#line 408 "policy_parse.y"
                        { (yyval.ptr) = (yyvsp[0].ptr); }
#line 2772 "y.tab.c"
    break;

  case 128: /* cond_rule_def: cond_te_avtab_def  */
#line 410 "policy_parse.y"
                        { (yyval.ptr) = (yyvsp[0].ptr); }
#line 2778 "y.tab.c"
    break;

  case 129: /* cond_rule_def: require_block  */
#line 412 "policy_parse.y"
                        { (yyval.ptr) = NULL; }
#line 2784 "y.tab.c"
    break;

  case 130: /* cond_transition_def: TYPE_TRANSITION names names ':' names identifier filename ';'  */
#line 415 "policy_parse.y"
                        { (yyval.ptr) = define_cond_filename_trans() ;
                          if ((yyval.ptr) == COND_ERR) YYABORT;}
#line 2791 "y.tab.c"
    break;

  case 131: /* cond_transition_def: TYPE_TRANSITION names names ':' names identifier ';'  */
#line 418 "policy_parse.y"
                        { (yyval.ptr) = define_cond_compute_type(AVRULE_TRANSITION) ;
                          if ((yyval.ptr) == COND_ERR) YYABORT;}
#line 2798 "y.tab.c"
    break;

  case 132: /* cond_transition_def: TYPE_MEMBER names names ':' names identifier ';'  */
#line 421 "policy_parse.y"
                        { (yyval.ptr) = define_cond_compute_type(AVRULE_MEMBER) ;
                          if ((yyval.ptr) ==  COND_ERR) YYABORT;}
#line 2805 "y.tab.c"
    break;

  case 133: /* cond_transition_def: TYPE_CHANGE names names ':' names identifier ';'  */
#line 424 "policy_parse.y"
                        { (yyval.ptr) = define_cond_compute_type(AVRULE_CHANGE) ;
                          if ((yyval.ptr) == COND_ERR) YYABORT;}
#line 2812 "y.tab.c"
    break;

  case 134: /* cond_te_avtab_def: cond_allow_def  */
#line 428 "policy_parse.y"
                          { (yyval.ptr) = (yyvsp[0].ptr); }
#line 2818 "y.tab.c"
    break;

  case 135: /* cond_te_avtab_def: cond_auditallow_def  */
#line 430 "policy_parse.y"
                          { (yyval.ptr) = (yyvsp[0].ptr); }
#line 2824 "y.tab.c"
    break;

  case 136: /* cond_te_avtab_def: cond_auditdeny_def  */
#line 432 "policy_parse.y"
                          { (yyval.ptr) = (yyvsp[0].ptr); }
#line 2830 "y.tab.c"
    break;

  case 137: /* cond_te_avtab_def: cond_dontaudit_def  */
#line 434 "policy_parse.y"
                          { (yyval.ptr) = (yyvsp[0].ptr); }
#line 2836 "y.tab.c"
    break;

  case 138: /* cond_allow_def: ALLOW names names ':' names names ';'  */
#line 437 "policy_parse.y"
                        { (yyval.ptr) = define_cond_te_avtab(AVRULE_ALLOWED) ;
                          if ((yyval.ptr) == COND_ERR) YYABORT; }
#line 2843 "y.tab.c"
    break;

  case 139: /* cond_auditallow_def: AUDITALLOW names names ':' names names ';'  */
#line 441 "policy_parse.y"
                        { (yyval.ptr) = define_cond_te_avtab(AVRULE_AUDITALLOW) ;
                          if ((yyval.ptr) == COND_ERR) YYABORT; }
#line 2850 "y.tab.c"
    break;

  case 140: /* cond_auditdeny_def: AUDITDENY names names ':' names names ';'  */
#line 445 "policy_parse.y"
                        { (yyval.ptr) = define_cond_te_avtab(AVRULE_AUDITDENY) ;
                          if ((yyval.ptr) == COND_ERR) YYABORT; }
#line 2857 "y.tab.c"
    break;

  case 141: /* cond_dontaudit_def: DONTAUDIT names names ':' names names ';'  */
#line 449 "policy_parse.y"
                        { (yyval.ptr) = define_cond_te_avtab(AVRULE_DONTAUDIT);
                          if ((yyval.ptr) == COND_ERR) YYABORT; }
#line 2864 "y.tab.c"
    break;

  case 142: /* transition_def: TYPE_TRANSITION names names ':' names identifier filename ';'  */
#line 454 "policy_parse.y"
                        {if (define_filename_trans()) YYABORT; }
#line 2870 "y.tab.c"
    break;

  case 143: /* transition_def: TYPE_TRANSITION names names ':' names identifier ';'  */
#line 456 "policy_parse.y"
                        {if (define_compute_type(AVRULE_TRANSITION)) YYABORT;}
#line 2876 "y.tab.c"
    break;

  case 144: /* transition_def: TYPE_MEMBER names names ':' names identifier ';'  */
#line 458 "policy_parse.y"
                        {if (define_compute_type(AVRULE_MEMBER)) YYABORT;}
#line 2882 "y.tab.c"
    break;

  case 145: /* transition_def: TYPE_CHANGE names names ':' names identifier ';'  */
#line 460 "policy_parse.y"
                        {if (define_compute_type(AVRULE_CHANGE)) YYABORT;}
#line 2888 "y.tab.c"
    break;

  case 146: /* range_trans_def: RANGE_TRANSITION names names mls_range_def ';'  */
#line 463 "policy_parse.y"
                        { if (define_range_trans(0)) YYABORT; }
#line 2894 "y.tab.c"
    break;

  case 147: /* range_trans_def: RANGE_TRANSITION names names ':' names mls_range_def ';'  */
#line 465 "policy_parse.y"
                        { if (define_range_trans(1)) YYABORT; }
#line 2900 "y.tab.c"
    break;

  case 157: /* allow_def: ALLOW names names ':' names names ';'  */
#line 478 "policy_parse.y"
                        {if (define_te_avtab(AVRULE_ALLOWED)) YYABORT; }
#line 2906 "y.tab.c"
    break;

  case 158: /* auditallow_def: AUDITALLOW names names ':' names names ';'  */
#line 481 "policy_parse.y"
                        {if (define_te_avtab(AVRULE_AUDITALLOW)) YYABORT; }
#line 2912 "y.tab.c"
    break;

  case 159: /* auditdeny_def: AUDITDENY names names ':' names names ';'  */
#line 484 "policy_parse.y"
                        {if (define_te_avtab(AVRULE_AUDITDENY)) YYABORT; }
#line 2918 "y.tab.c"
    break;

  case 160: /* dontaudit_def: DONTAUDIT names names ':' names names ';'  */
#line 487 "policy_parse.y"
                        {if (define_te_avtab(AVRULE_DONTAUDIT)) YYABORT; }
#line 2924 "y.tab.c"
    break;

  case 161: /* neverallow_def: NEVERALLOW names names ':' names names ';'  */
#line 490 "policy_parse.y"
                        {if (define_te_avtab(AVRULE_NEVERALLOW)) YYABORT; }
#line 2930 "y.tab.c"
    break;

  case 162: /* xperm_allow_def: ALLOWXPERM names names ':' names identifier xperms ';'  */
#line 493 "policy_parse.y"
                        {if (define_te_avtab_extended_perms(AVRULE_XPERMS_ALLOWED)) YYABORT; }
#line 2936 "y.tab.c"
    break;

  case 163: /* xperm_auditallow_def: AUDITALLOWXPERM names names ':' names identifier xperms ';'  */
#line 496 "policy_parse.y"
                        {if (define_te_avtab_extended_perms(AVRULE_XPERMS_AUDITALLOW)) YYABORT; }
#line 2942 "y.tab.c"
    break;

  case 164: /* xperm_dontaudit_def: DONTAUDITXPERM names names ':' names identifier xperms ';'  */
#line 499 "policy_parse.y"
                        {if (define_te_avtab_extended_perms(AVRULE_XPERMS_DONTAUDIT)) YYABORT; }
#line 2948 "y.tab.c"
    break;

  case 165: /* xperm_neverallow_def: NEVERALLOWXPERM names names ':' names identifier xperms ';'  */
#line 502 "policy_parse.y"
                        {if (define_te_avtab_extended_perms(AVRULE_XPERMS_NEVERALLOW)) YYABORT; }
#line 2954 "y.tab.c"
    break;

  case 166: /* attribute_role_def: ATTRIBUTE_ROLE identifier ';'  */
#line 505 "policy_parse.y"
                        {if (define_attrib_role()) YYABORT; }
#line 2960 "y.tab.c"
    break;

  case 167: /* role_type_def: ROLE identifier TYPES names ';'  */
#line 508 "policy_parse.y"
                        {if (define_role_types()) YYABORT;}
#line 2966 "y.tab.c"
    break;

  case 168: /* role_attr_def: ROLE identifier opt_attr_list ';'  */
#line 511 "policy_parse.y"
                        {if (define_role_attr()) YYABORT;}
#line 2972 "y.tab.c"
    break;

  case 169: /* role_trans_def: ROLE_TRANSITION names names identifier ';'  */
#line 514 "policy_parse.y"
                        {if (define_role_trans(0)) YYABORT; }
#line 2978 "y.tab.c"
    break;

  case 170: /* role_trans_def: ROLE_TRANSITION names names ':' names identifier ';'  */
#line 516 "policy_parse.y"
                        {if (define_role_trans(1)) YYABORT;}
#line 2984 "y.tab.c"
    break;

  case 171: /* role_allow_def: ALLOW names names ';'  */
#line 519 "policy_parse.y"
                        {if (define_role_allow()) YYABORT; }
#line 2990 "y.tab.c"
    break;

  case 172: /* roleattribute_def: ROLEATTRIBUTE identifier id_comma_list ';'  */
#line 522 "policy_parse.y"
                        {if (define_roleattribute()) YYABORT;}
#line 2996 "y.tab.c"
    break;

  case 179: /* constraint_def: CONSTRAIN names names cexpr ';'  */
#line 534 "policy_parse.y"
                        { if (define_constraint((constraint_expr_t*)(yyvsp[-1].valptr))) YYABORT; }
#line 3002 "y.tab.c"
    break;

  case 180: /* validatetrans_def: VALIDATETRANS names cexpr ';'  */
#line 537 "policy_parse.y"
                        { if (define_validatetrans((constraint_expr_t*)(yyvsp[-1].valptr))) YYABORT; }
#line 3008 "y.tab.c"
    break;

  case 181: /* cexpr: '(' cexpr ')'  */
#line 540 "policy_parse.y"
                        { (yyval.valptr) = (yyvsp[-1].valptr); }
#line 3014 "y.tab.c"
    break;

  case 182: /* cexpr: NOT cexpr  */
#line 542 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NOT, (yyvsp[0].valptr), 0);
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3021 "y.tab.c"
    break;

  case 183: /* cexpr: cexpr AND cexpr  */
#line 545 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_AND, (yyvsp[-2].valptr), (yyvsp[0].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3028 "y.tab.c"
    break;

  case 184: /* cexpr: cexpr OR cexpr  */
#line 548 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_OR, (yyvsp[-2].valptr), (yyvsp[0].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3035 "y.tab.c"
    break;

  case 185: /* cexpr: cexpr_prim  */
#line 551 "policy_parse.y"
                        { (yyval.valptr) = (yyvsp[0].valptr); }
#line 3041 "y.tab.c"
    break;

  case 186: /* cexpr_prim: U1 op U2  */
#line 554 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_USER, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3048 "y.tab.c"
    break;

  case 187: /* cexpr_prim: R1 role_mls_op R2  */
#line 557 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_ROLE, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3055 "y.tab.c"
    break;

  case 188: /* cexpr_prim: T1 op T2  */
#line 560 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_TYPE, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3062 "y.tab.c"
    break;

  case 189: /* $@4: %empty  */
#line 562 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3068 "y.tab.c"
    break;

  case 190: /* cexpr_prim: U1 op $@4 names_push  */
#line 563 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, CEXPR_USER, (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3075 "y.tab.c"
    break;

  case 191: /* $@5: %empty  */
#line 565 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3081 "y.tab.c"
    break;

  case 192: /* cexpr_prim: U2 op $@5 names_push  */
#line 566 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_USER | CEXPR_TARGET), (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3088 "y.tab.c"
    break;

  case 193: /* $@6: %empty  */
#line 568 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3094 "y.tab.c"
    break;

  case 194: /* cexpr_prim: U3 op $@6 names_push  */
#line 569 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_USER | CEXPR_XTARGET), (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3101 "y.tab.c"
    break;

  case 195: /* $@7: %empty  */
#line 571 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3107 "y.tab.c"
    break;

  case 196: /* cexpr_prim: R1 op $@7 names_push  */
#line 572 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, CEXPR_ROLE, (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3114 "y.tab.c"
    break;

  case 197: /* $@8: %empty  */
#line 574 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3120 "y.tab.c"
    break;

  case 198: /* cexpr_prim: R2 op $@8 names_push  */
#line 575 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_ROLE | CEXPR_TARGET), (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3127 "y.tab.c"
    break;

  case 199: /* $@9: %empty  */
#line 577 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3133 "y.tab.c"
    break;

  case 200: /* cexpr_prim: R3 op $@9 names_push  */
#line 578 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_ROLE | CEXPR_XTARGET), (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3140 "y.tab.c"
    break;

  case 201: /* $@10: %empty  */
#line 580 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3146 "y.tab.c"
    break;

  case 202: /* cexpr_prim: T1 op $@10 names_push  */
#line 581 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, CEXPR_TYPE, (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3153 "y.tab.c"
    break;

  case 203: /* $@11: %empty  */
#line 583 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3159 "y.tab.c"
    break;

  case 204: /* cexpr_prim: T2 op $@11 names_push  */
#line 584 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_TYPE | CEXPR_TARGET), (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3166 "y.tab.c"
    break;

  case 205: /* $@12: %empty  */
#line 586 "policy_parse.y"
                                { if (insert_separator(1)) YYABORT; }
#line 3172 "y.tab.c"
    break;

  case 206: /* cexpr_prim: T3 op $@12 names_push  */
#line 587 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_TYPE | CEXPR_XTARGET), (yyvsp[-2].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3179 "y.tab.c"
    break;

  case 207: /* cexpr_prim: SAMEUSER  */
#line 590 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_USER, CEXPR_EQ);
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3186 "y.tab.c"
    break;

  case 208: /* $@13: %empty  */
#line 592 "policy_parse.y"
                                      { if (insert_separator(1)) YYABORT; }
#line 3192 "y.tab.c"
    break;

  case 209: /* cexpr_prim: SOURCE ROLE $@13 names_push  */
#line 593 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, CEXPR_ROLE, CEXPR_EQ);
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3199 "y.tab.c"
    break;

  case 210: /* $@14: %empty  */
#line 595 "policy_parse.y"
                                      { if (insert_separator(1)) YYABORT; }
#line 3205 "y.tab.c"
    break;

  case 211: /* cexpr_prim: TARGET ROLE $@14 names_push  */
#line 596 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_ROLE | CEXPR_TARGET), CEXPR_EQ);
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3212 "y.tab.c"
    break;

  case 212: /* cexpr_prim: ROLE role_mls_op  */
#line 599 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_ROLE, (yyvsp[0].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3219 "y.tab.c"
    break;

  case 213: /* $@15: %empty  */
#line 601 "policy_parse.y"
                                      { if (insert_separator(1)) YYABORT; }
#line 3225 "y.tab.c"
    break;

  case 214: /* cexpr_prim: SOURCE TYPE $@15 names_push  */
#line 602 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, CEXPR_TYPE, CEXPR_EQ);
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3232 "y.tab.c"
    break;

  case 215: /* $@16: %empty  */
#line 604 "policy_parse.y"
                                      { if (insert_separator(1)) YYABORT; }
#line 3238 "y.tab.c"
    break;

  case 216: /* cexpr_prim: TARGET TYPE $@16 names_push  */
#line 605 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_NAMES, (CEXPR_TYPE | CEXPR_TARGET), CEXPR_EQ);
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3245 "y.tab.c"
    break;

  case 217: /* cexpr_prim: L1 role_mls_op L2  */
#line 608 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_L1L2, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3252 "y.tab.c"
    break;

  case 218: /* cexpr_prim: L1 role_mls_op H2  */
#line 611 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_L1H2, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3259 "y.tab.c"
    break;

  case 219: /* cexpr_prim: H1 role_mls_op L2  */
#line 614 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_H1L2, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3266 "y.tab.c"
    break;

  case 220: /* cexpr_prim: H1 role_mls_op H2  */
#line 617 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_H1H2, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3273 "y.tab.c"
    break;

  case 221: /* cexpr_prim: L1 role_mls_op H1  */
#line 620 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_L1H1, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3280 "y.tab.c"
    break;

  case 222: /* cexpr_prim: L2 role_mls_op H2  */
#line 623 "policy_parse.y"
                        { (yyval.valptr) = define_cexpr(CEXPR_ATTR, CEXPR_L2H2, (yyvsp[-1].valptr));
			  if ((yyval.valptr) == 0) YYABORT; }
#line 3287 "y.tab.c"
    break;

  case 223: /* op: EQUALS  */
#line 627 "policy_parse.y"
                        { (yyval.valptr) = CEXPR_EQ; }
#line 3293 "y.tab.c"
    break;

  case 224: /* op: NOTEQUAL  */
#line 629 "policy_parse.y"
                        { (yyval.valptr) = CEXPR_NEQ; }
#line 3299 "y.tab.c"
    break;

  case 225: /* role_mls_op: op  */
#line 632 "policy_parse.y"
                        { (yyval.valptr) = (yyvsp[0].valptr); }
#line 3305 "y.tab.c"
    break;

  case 226: /* role_mls_op: DOM  */
#line 634 "policy_parse.y"
                        { (yyval.valptr) = CEXPR_DOM; }
#line 3311 "y.tab.c"
    break;

  case 227: /* role_mls_op: DOMBY  */
#line 636 "policy_parse.y"
                        { (yyval.valptr) = CEXPR_DOMBY; }
#line 3317 "y.tab.c"
    break;

  case 228: /* role_mls_op: INCOMP  */
#line 638 "policy_parse.y"
                        { (yyval.valptr) = CEXPR_INCOMP; }
#line 3323 "y.tab.c"
    break;

  case 231: /* user_def: USER identifier ROLES names opt_mls_user ';'  */
#line 644 "policy_parse.y"
                        {if (define_user()) YYABORT;}
#line 3329 "y.tab.c"
    break;

  case 236: /* initial_sid_context_def: SID identifier security_context_def  */
#line 653 "policy_parse.y"
                        {if (define_initial_sid_context()) YYABORT;}
#line 3335 "y.tab.c"
    break;

  case 246: /* pirq_context_def: PIRQCON number security_context_def  */
#line 667 "policy_parse.y"
                        {if (define_pirq_context((yyvsp[-1].val))) YYABORT;}
#line 3341 "y.tab.c"
    break;

  case 247: /* iomem_context_def: IOMEMCON number64 security_context_def  */
#line 670 "policy_parse.y"
                        {if (define_iomem_context((yyvsp[-1].val64),(yyvsp[-1].val64))) YYABORT;}
#line 3347 "y.tab.c"
    break;

  case 248: /* iomem_context_def: IOMEMCON number64 '-' number64 security_context_def  */
#line 672 "policy_parse.y"
                        {if (define_iomem_context((yyvsp[-3].val64),(yyvsp[-1].val64))) YYABORT;}
#line 3353 "y.tab.c"
    break;

  case 249: /* ioport_context_def: IOPORTCON number security_context_def  */
#line 675 "policy_parse.y"
                        {if (define_ioport_context((yyvsp[-1].val),(yyvsp[-1].val))) YYABORT;}
#line 3359 "y.tab.c"
    break;

  case 250: /* ioport_context_def: IOPORTCON number '-' number security_context_def  */
#line 677 "policy_parse.y"
                        {if (define_ioport_context((yyvsp[-3].val),(yyvsp[-1].val))) YYABORT;}
#line 3365 "y.tab.c"
    break;

  case 251: /* pci_context_def: PCIDEVICECON number security_context_def  */
#line 680 "policy_parse.y"
                        {if (define_pcidevice_context((yyvsp[-1].val))) YYABORT;}
#line 3371 "y.tab.c"
    break;

  case 252: /* dtree_context_def: DEVICETREECON path security_context_def  */
#line 683 "policy_parse.y"
                        {if (define_devicetree_context()) YYABORT;}
#line 3377 "y.tab.c"
    break;

  case 257: /* fs_context_def: FSCON number number security_context_def security_context_def  */
#line 692 "policy_parse.y"
                        {if (define_fs_context((yyvsp[-3].val),(yyvsp[-2].val))) YYABORT;}
#line 3383 "y.tab.c"
    break;

  case 263: /* port_context_def: PORTCON identifier number security_context_def  */
#line 703 "policy_parse.y"
                        {if (define_port_context((yyvsp[-1].val),(yyvsp[-1].val))) YYABORT;}
#line 3389 "y.tab.c"
    break;

  case 264: /* port_context_def: PORTCON identifier number '-' number security_context_def  */
#line 705 "policy_parse.y"
                        {if (define_port_context((yyvsp[-3].val),(yyvsp[-1].val))) YYABORT;}
#line 3395 "y.tab.c"
    break;

  case 269: /* ibpkey_context_def: IBPKEYCON ipv6_addr number security_context_def  */
#line 714 "policy_parse.y"
                        {if (define_ibpkey_context((yyvsp[-1].val),(yyvsp[-1].val))) YYABORT;}
#line 3401 "y.tab.c"
    break;

  case 270: /* ibpkey_context_def: IBPKEYCON ipv6_addr number '-' number security_context_def  */
#line 716 "policy_parse.y"
                        {if (define_ibpkey_context((yyvsp[-3].val),(yyvsp[-1].val))) YYABORT;}
#line 3407 "y.tab.c"
    break;

  case 275: /* ibendport_context_def: IBENDPORTCON identifier number security_context_def  */
#line 725 "policy_parse.y"
                        {if (define_ibendport_context((yyvsp[-1].val))) YYABORT;}
#line 3413 "y.tab.c"
    break;

  case 280: /* netif_context_def: NETIFCON identifier security_context_def security_context_def  */
#line 734 "policy_parse.y"
                        {if (define_netif_context()) YYABORT;}
#line 3419 "y.tab.c"
    break;

  case 285: /* node_context_def: NODECON ipv4_addr_def ipv4_addr_def security_context_def  */
#line 743 "policy_parse.y"
                        {if (define_ipv4_node_context()) YYABORT;}
#line 3425 "y.tab.c"
    break;

  case 286: /* node_context_def: NODECON ipv4_cidr_def security_context_def  */
#line 745 "policy_parse.y"
                        {if (define_ipv4_cidr_node_context()) YYABORT;}
#line 3431 "y.tab.c"
    break;

  case 287: /* node_context_def: NODECON ipv6_addr ipv6_addr security_context_def  */
#line 747 "policy_parse.y"
                        {if (define_ipv6_node_context()) YYABORT;}
#line 3437 "y.tab.c"
    break;

  case 288: /* node_context_def: NODECON ipv6_cidr security_context_def  */
#line 749 "policy_parse.y"
                        {if (define_ipv6_cidr_node_context()) YYABORT;}
#line 3443 "y.tab.c"
    break;

  case 293: /* fs_use_def: FSUSEXATTR filesystem security_context_def ';'  */
#line 758 "policy_parse.y"
                        {if (define_fs_use(SECURITY_FS_USE_XATTR)) YYABORT;}
#line 3449 "y.tab.c"
    break;

  case 294: /* fs_use_def: FSUSETASK identifier security_context_def ';'  */
#line 760 "policy_parse.y"
                        {if (define_fs_use(SECURITY_FS_USE_TASK)) YYABORT;}
#line 3455 "y.tab.c"
    break;

  case 295: /* fs_use_def: FSUSETRANS identifier security_context_def ';'  */
#line 762 "policy_parse.y"
                        {if (define_fs_use(SECURITY_FS_USE_TRANS)) YYABORT;}
#line 3461 "y.tab.c"
    break;

  case 300: /* genfs_context_def: GENFSCON filesystem path '-' identifier security_context_def  */
#line 771 "policy_parse.y"
                        {if (define_genfs_context(1)) YYABORT;}
#line 3467 "y.tab.c"
    break;

  case 301: /* $@17: %empty  */
#line 772 "policy_parse.y"
                                                           {insert_id("-", 0);}
#line 3473 "y.tab.c"
    break;

  case 302: /* genfs_context_def: GENFSCON filesystem path '-' '-' $@17 security_context_def  */
#line 773 "policy_parse.y"
                        {if (define_genfs_context(1)) YYABORT;}
#line 3479 "y.tab.c"
    break;

  case 303: /* genfs_context_def: GENFSCON filesystem path security_context_def  */
#line 775 "policy_parse.y"
                        {if (define_genfs_context(0)) YYABORT;}
#line 3485 "y.tab.c"
    break;

  case 304: /* ipv4_addr_def: IPV4_ADDR  */
#line 778 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3491 "y.tab.c"
    break;

  case 305: /* ipv4_cidr_def: IPV4_CIDR  */
#line 781 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3497 "y.tab.c"
    break;

  case 306: /* xperms: xperm  */
#line 784 "policy_parse.y"
                        { if (insert_separator(0)) YYABORT; }
#line 3503 "y.tab.c"
    break;

  case 307: /* xperms: nested_xperm_set  */
#line 786 "policy_parse.y"
                        { if (insert_separator(0)) YYABORT; }
#line 3509 "y.tab.c"
    break;

  case 308: /* xperms: tilde xperm  */
#line 788 "policy_parse.y"
                        { if (insert_id("~", 0)) YYABORT; }
#line 3515 "y.tab.c"
    break;

  case 309: /* xperms: tilde nested_xperm_set  */
#line 790 "policy_parse.y"
                        { if (insert_id("~", 0)) YYABORT;
			  if (insert_separator(0)) YYABORT; }
#line 3522 "y.tab.c"
    break;

  case 313: /* $@18: %empty  */
#line 798 "policy_parse.y"
                                { if (insert_id("-", 0)) YYABORT; }
#line 3528 "y.tab.c"
    break;

  case 317: /* xperm: number  */
#line 803 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3534 "y.tab.c"
    break;

  case 321: /* mls_range_def: mls_level_def '-' mls_level_def  */
#line 811 "policy_parse.y"
                        {if (insert_separator(0)) YYABORT;}
#line 3540 "y.tab.c"
    break;

  case 322: /* mls_range_def: mls_level_def  */
#line 813 "policy_parse.y"
                        {if (insert_separator(0)) YYABORT;}
#line 3546 "y.tab.c"
    break;

  case 323: /* mls_level_def: identifier ':' id_comma_list  */
#line 816 "policy_parse.y"
                        {if (insert_separator(0)) YYABORT;}
#line 3552 "y.tab.c"
    break;

  case 324: /* mls_level_def: identifier  */
#line 818 "policy_parse.y"
                        {if (insert_separator(0)) YYABORT;}
#line 3558 "y.tab.c"
    break;

  case 329: /* names: identifier  */
#line 828 "policy_parse.y"
                        { if (insert_separator(0)) YYABORT; }
#line 3564 "y.tab.c"
    break;

  case 330: /* names: nested_id_set  */
#line 830 "policy_parse.y"
                        { if (insert_separator(0)) YYABORT; }
#line 3570 "y.tab.c"
    break;

  case 331: /* names: asterisk  */
#line 832 "policy_parse.y"
                        { if (insert_id("*", 0)) YYABORT;
			  if (insert_separator(0)) YYABORT; }
#line 3577 "y.tab.c"
    break;

  case 332: /* names: tilde identifier  */
#line 835 "policy_parse.y"
                        { if (insert_id("~", 0)) YYABORT;
			  if (insert_separator(0)) YYABORT; }
#line 3584 "y.tab.c"
    break;

  case 333: /* names: tilde nested_id_set  */
#line 838 "policy_parse.y"
                        { if (insert_id("~", 0)) YYABORT;
			  if (insert_separator(0)) YYABORT; }
#line 3591 "y.tab.c"
    break;

  case 334: /* $@19: %empty  */
#line 840 "policy_parse.y"
                                         { if (insert_id("-", 0)) YYABORT; }
#line 3597 "y.tab.c"
    break;

  case 335: /* names: identifier '-' $@19 identifier  */
#line 841 "policy_parse.y"
                        { if (insert_separator(0)) YYABORT; }
#line 3603 "y.tab.c"
    break;

  case 336: /* tilde_push: tilde  */
#line 844 "policy_parse.y"
                        { if (insert_id("~", 1)) YYABORT; }
#line 3609 "y.tab.c"
    break;

  case 337: /* asterisk_push: asterisk  */
#line 847 "policy_parse.y"
                        { if (insert_id("*", 1)) YYABORT; }
#line 3615 "y.tab.c"
    break;

  case 345: /* identifier_push: IDENTIFIER  */
#line 859 "policy_parse.y"
                        { if (insert_id(yytext, 1)) YYABORT; }
#line 3621 "y.tab.c"
    break;

  case 352: /* $@20: %empty  */
#line 868 "policy_parse.y"
                                           { if (insert_id("-", 0)) YYABORT; }
#line 3627 "y.tab.c"
    break;

  case 355: /* identifier: IDENTIFIER  */
#line 871 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3633 "y.tab.c"
    break;

  case 356: /* filesystem: FILESYSTEM  */
#line 874 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3639 "y.tab.c"
    break;

  case 357: /* filesystem: IDENTIFIER  */
#line 876 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3645 "y.tab.c"
    break;

  case 358: /* path: PATH  */
#line 879 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3651 "y.tab.c"
    break;

  case 359: /* path: QPATH  */
#line 881 "policy_parse.y"
                        { yytext[strlen(yytext) - 1] = '\0'; if (insert_id(yytext + 1,0)) YYABORT; }
#line 3657 "y.tab.c"
    break;

  case 360: /* filename: FILENAME  */
#line 884 "policy_parse.y"
                        { yytext[strlen(yytext) - 1] = '\0'; if (insert_id(yytext + 1,0)) YYABORT; }
#line 3663 "y.tab.c"
    break;

  case 361: /* number: NUMBER  */
#line 887 "policy_parse.y"
                        { unsigned long x;
			  errno = 0;
			  x = strtoul(yytext, NULL, 0);
			  if (errno)
			      YYABORT;
#if ULONG_MAX > UINT_MAX
			  if (x > UINT_MAX)
			      YYABORT;
#endif
			  (yyval.val) = (unsigned int) x;
			}
#line 3679 "y.tab.c"
    break;

  case 362: /* number64: NUMBER  */
#line 900 "policy_parse.y"
                        { unsigned long long x;
			  errno = 0;
			  x = strtoull(yytext, NULL, 0);
			  if (errno)
			      YYABORT;
			  (yyval.val64) = (uint64_t) x;
			}
#line 3691 "y.tab.c"
    break;

  case 363: /* ipv6_addr: IPV6_ADDR  */
#line 909 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3697 "y.tab.c"
    break;

  case 364: /* ipv6_cidr: IPV6_CIDR  */
#line 912 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3703 "y.tab.c"
    break;

  case 365: /* policycap_def: POLICYCAP identifier ';'  */
#line 915 "policy_parse.y"
                        {if (define_polcap()) YYABORT;}
#line 3709 "y.tab.c"
    break;

  case 366: /* permissive_def: PERMISSIVE identifier ';'  */
#line 918 "policy_parse.y"
                        {if (define_permissive()) YYABORT;}
#line 3715 "y.tab.c"
    break;

  case 367: /* module_policy: module_def avrules_block  */
#line 923 "policy_parse.y"
                        { if (end_avrule_block(pass) == -1) YYABORT;
                          if (policydb_index_others(NULL, policydbp, 0)) YYABORT;
                        }
#line 3723 "y.tab.c"
    break;

  case 368: /* module_def: MODULE identifier version_identifier ';'  */
#line 928 "policy_parse.y"
                        { if (define_policy(pass, 1) == -1) YYABORT; }
#line 3729 "y.tab.c"
    break;

  case 369: /* version_identifier: VERSION_IDENTIFIER  */
#line 931 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3735 "y.tab.c"
    break;

  case 370: /* version_identifier: number  */
#line 933 "policy_parse.y"
                        { if (insert_id(yytext,0)) YYABORT; }
#line 3741 "y.tab.c"
    break;

  case 386: /* require_class: CLASS identifier names  */
#line 957 "policy_parse.y"
                        { if (require_class(pass)) YYABORT; }
#line 3747 "y.tab.c"
    break;

  case 387: /* require_decl_def: ROLE  */
#line 959 "policy_parse.y"
                                      { (yyval.require_func) = require_role; }
#line 3753 "y.tab.c"
    break;

  case 388: /* require_decl_def: TYPE  */
#line 960 "policy_parse.y"
                                      { (yyval.require_func) = require_type; }
#line 3759 "y.tab.c"
    break;

  case 389: /* require_decl_def: ATTRIBUTE  */
#line 961 "policy_parse.y"
                                      { (yyval.require_func) = require_attribute; }
#line 3765 "y.tab.c"
    break;

  case 390: /* require_decl_def: ATTRIBUTE_ROLE  */
#line 962 "policy_parse.y"
                                           { (yyval.require_func) = require_attribute_role; }
#line 3771 "y.tab.c"
    break;

  case 391: /* require_decl_def: USER  */
#line 963 "policy_parse.y"
                                      { (yyval.require_func) = require_user; }
#line 3777 "y.tab.c"
    break;

  case 392: /* require_decl_def: BOOL  */
#line 964 "policy_parse.y"
                                      { (yyval.require_func) = require_bool; }
#line 3783 "y.tab.c"
    break;

  case 393: /* require_decl_def: TUNABLE  */
#line 965 "policy_parse.y"
                                      { (yyval.require_func) = require_tunable; }
#line 3789 "y.tab.c"
    break;

  case 394: /* require_decl_def: SENSITIVITY  */
#line 966 "policy_parse.y"
                                      { (yyval.require_func) = require_sens; }
#line 3795 "y.tab.c"
    break;

  case 395: /* require_decl_def: CATEGORY  */
#line 967 "policy_parse.y"
                                      { (yyval.require_func) = require_cat; }
#line 3801 "y.tab.c"
    break;

  case 396: /* require_id_list: identifier  */
#line 970 "policy_parse.y"
                        { if ((yyvsp[-1].require_func) (pass)) YYABORT; }
#line 3807 "y.tab.c"
    break;

  case 397: /* require_id_list: require_id_list ',' identifier  */
#line 972 "policy_parse.y"
                        { if ((yyvsp[-3].require_func) (pass)) YYABORT; }
#line 3813 "y.tab.c"
    break;

  case 398: /* $@21: %empty  */
#line 975 "policy_parse.y"
                        { if (end_avrule_block(pass) == -1) YYABORT; }
#line 3819 "y.tab.c"
    break;

  case 399: /* optional_block: optional_decl '{' avrules_block '}' $@21 optional_else  */
#line 977 "policy_parse.y"
                        { if (end_optional(pass) == -1) YYABORT; }
#line 3825 "y.tab.c"
    break;

  case 400: /* optional_else: else_decl '{' avrules_block '}'  */
#line 980 "policy_parse.y"
                        { if (end_avrule_block(pass) == -1) YYABORT; }
#line 3831 "y.tab.c"
    break;

  case 402: /* optional_decl: OPTIONAL  */
#line 984 "policy_parse.y"
                        { if (begin_optional(pass) == -1) YYABORT; }
#line 3837 "y.tab.c"
    break;

  case 403: /* else_decl: ELSE  */
#line 987 "policy_parse.y"
                        { if (begin_optional_else(pass) == -1) YYABORT; }
#line 3843 "y.tab.c"
    break;


#line 3847 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}


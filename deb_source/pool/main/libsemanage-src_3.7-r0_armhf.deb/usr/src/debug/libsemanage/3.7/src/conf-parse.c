/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1


/* Substitute the variable and function names.  */
#define yyparse         semanage_parse
#define yylex           semanage_lex
#define yyerror         semanage_error
#define yydebug         semanage_debug
#define yynerrs         semanage_nerrs
#define yylval          semanage_lval
#define yychar          semanage_char

/* First part of user prologue.  */
#line 21 "conf-parse.y"


#include "semanage_conf.h"

#include <sepol/policydb.h>
#include <selinux/selinux.h>
#include <semanage/handle.h>

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int semanage_lex(void);                /* defined in conf-scan.c */
extern int semanage_lex_destroy(void);        /* defined in conf-scan.c */
int semanage_error(const char *msg);

extern FILE *semanage_in;
extern char *semanage_text;

static int parse_module_store(char *arg);
static int parse_store_root_path(char *arg);
static int parse_compiler_path(char *arg);
static void semanage_conf_external_prog_destroy(external_prog_t *ep);
static int new_external_prog(external_prog_t **chain);

static semanage_conf_t *current_conf;
static external_prog_t *new_external;
static int parse_errors;

#define PASSIGN(p1,p2) { free(p1); p1 = p2; }


#line 112 "conf-parse.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "conf-parse.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_MODULE_STORE = 3,               /* MODULE_STORE  */
  YYSYMBOL_VERSION = 4,                    /* VERSION  */
  YYSYMBOL_EXPAND_CHECK = 5,               /* EXPAND_CHECK  */
  YYSYMBOL_FILE_MODE = 6,                  /* FILE_MODE  */
  YYSYMBOL_SAVE_PREVIOUS = 7,              /* SAVE_PREVIOUS  */
  YYSYMBOL_SAVE_LINKED = 8,                /* SAVE_LINKED  */
  YYSYMBOL_TARGET_PLATFORM = 9,            /* TARGET_PLATFORM  */
  YYSYMBOL_COMPILER_DIR = 10,              /* COMPILER_DIR  */
  YYSYMBOL_IGNORE_MODULE_CACHE = 11,       /* IGNORE_MODULE_CACHE  */
  YYSYMBOL_STORE_ROOT = 12,                /* STORE_ROOT  */
  YYSYMBOL_OPTIMIZE_POLICY = 13,           /* OPTIMIZE_POLICY  */
  YYSYMBOL_LOAD_POLICY_START = 14,         /* LOAD_POLICY_START  */
  YYSYMBOL_SETFILES_START = 15,            /* SETFILES_START  */
  YYSYMBOL_SEFCONTEXT_COMPILE_START = 16,  /* SEFCONTEXT_COMPILE_START  */
  YYSYMBOL_DISABLE_GENHOMEDIRCON = 17,     /* DISABLE_GENHOMEDIRCON  */
  YYSYMBOL_HANDLE_UNKNOWN = 18,            /* HANDLE_UNKNOWN  */
  YYSYMBOL_USEPASSWD = 19,                 /* USEPASSWD  */
  YYSYMBOL_IGNOREDIRS = 20,                /* IGNOREDIRS  */
  YYSYMBOL_BZIP_BLOCKSIZE = 21,            /* BZIP_BLOCKSIZE  */
  YYSYMBOL_BZIP_SMALL = 22,                /* BZIP_SMALL  */
  YYSYMBOL_REMOVE_HLL = 23,                /* REMOVE_HLL  */
  YYSYMBOL_VERIFY_MOD_START = 24,          /* VERIFY_MOD_START  */
  YYSYMBOL_VERIFY_LINKED_START = 25,       /* VERIFY_LINKED_START  */
  YYSYMBOL_VERIFY_KERNEL_START = 26,       /* VERIFY_KERNEL_START  */
  YYSYMBOL_BLOCK_END = 27,                 /* BLOCK_END  */
  YYSYMBOL_PROG_PATH = 28,                 /* PROG_PATH  */
  YYSYMBOL_PROG_ARGS = 29,                 /* PROG_ARGS  */
  YYSYMBOL_ARG = 30,                       /* ARG  */
  YYSYMBOL_31_ = 31,                       /* '='  */
  YYSYMBOL_YYACCEPT = 32,                  /* $accept  */
  YYSYMBOL_config_file = 33,               /* config_file  */
  YYSYMBOL_config_line = 34,               /* config_line  */
  YYSYMBOL_single_opt = 35,                /* single_opt  */
  YYSYMBOL_module_store = 36,              /* module_store  */
  YYSYMBOL_store_root = 37,                /* store_root  */
  YYSYMBOL_compiler_dir = 38,              /* compiler_dir  */
  YYSYMBOL_ignore_module_cache = 39,       /* ignore_module_cache  */
  YYSYMBOL_version = 40,                   /* version  */
  YYSYMBOL_target_platform = 41,           /* target_platform  */
  YYSYMBOL_expand_check = 42,              /* expand_check  */
  YYSYMBOL_file_mode = 43,                 /* file_mode  */
  YYSYMBOL_save_previous = 44,             /* save_previous  */
  YYSYMBOL_save_linked = 45,               /* save_linked  */
  YYSYMBOL_disable_genhomedircon = 46,     /* disable_genhomedircon  */
  YYSYMBOL_usepasswd = 47,                 /* usepasswd  */
  YYSYMBOL_ignoredirs = 48,                /* ignoredirs  */
  YYSYMBOL_handle_unknown = 49,            /* handle_unknown  */
  YYSYMBOL_bzip_blocksize = 50,            /* bzip_blocksize  */
  YYSYMBOL_bzip_small = 51,                /* bzip_small  */
  YYSYMBOL_remove_hll = 52,                /* remove_hll  */
  YYSYMBOL_optimize_policy = 53,           /* optimize_policy  */
  YYSYMBOL_command_block = 54,             /* command_block  */
  YYSYMBOL_command_start = 55,             /* command_start  */
  YYSYMBOL_verify_block = 56,              /* verify_block  */
  YYSYMBOL_verify_start = 57,              /* verify_start  */
  YYSYMBOL_verify_start_tok = 58,          /* verify_start_tok  */
  YYSYMBOL_external_opts = 59,             /* external_opts  */
  YYSYMBOL_external_opt = 60               /* external_opt  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  69
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   73

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  32
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  29
/* YYNRULES -- Number of rules.  */
#define YYNRULES  55
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  101

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   285


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    31,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    72,    72,    73,    76,    77,    78,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    96,    97,    98,   101,   111,   120,   129,   141,
     152,   164,   170,   176,   189,   201,   212,   223,   228,   241,
     250,   261,   272,   284,   293,   301,   309,   319,   327,   335,
     336,   337,   340,   341,   344,   345
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "MODULE_STORE",
  "VERSION", "EXPAND_CHECK", "FILE_MODE", "SAVE_PREVIOUS", "SAVE_LINKED",
  "TARGET_PLATFORM", "COMPILER_DIR", "IGNORE_MODULE_CACHE", "STORE_ROOT",
  "OPTIMIZE_POLICY", "LOAD_POLICY_START", "SETFILES_START",
  "SEFCONTEXT_COMPILE_START", "DISABLE_GENHOMEDIRCON", "HANDLE_UNKNOWN",
  "USEPASSWD", "IGNOREDIRS", "BZIP_BLOCKSIZE", "BZIP_SMALL", "REMOVE_HLL",
  "VERIFY_MOD_START", "VERIFY_LINKED_START", "VERIFY_KERNEL_START",
  "BLOCK_END", "PROG_PATH", "PROG_ARGS", "ARG", "'='", "$accept",
  "config_file", "config_line", "single_opt", "module_store", "store_root",
  "compiler_dir", "ignore_module_cache", "version", "target_platform",
  "expand_check", "file_mode", "save_previous", "save_linked",
  "disable_genhomedircon", "usepasswd", "ignoredirs", "handle_unknown",
  "bzip_blocksize", "bzip_small", "remove_hll", "optimize_policy",
  "command_block", "command_start", "verify_block", "verify_start",
  "verify_start_tok", "external_opts", "external_opt", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-50)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int8 yypact[] =
{
      -2,    -5,     0,     1,     2,     3,     4,     5,     6,     7,
       8,     9,   -50,   -50,   -50,    10,    11,    12,    13,    14,
      15,    16,   -50,   -50,   -50,    29,    -2,   -50,   -50,   -50,
     -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,
     -50,   -50,   -50,   -50,   -50,   -50,   -50,    -1,   -50,    -1,
     -50,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    30,    31,    32,    33,    34,    35,    36,   -50,
     -50,    37,    38,    40,    -1,    43,   -50,   -50,   -50,   -50,
     -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,
     -50,   -50,   -50,   -50,    41,    42,   -50,   -50,   -50,   -50,
     -50
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       3,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    44,    45,    46,     0,     0,     0,     0,     0,
       0,     0,    49,    50,    51,     0,     3,     4,     7,    10,
      11,    12,     8,     9,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,     5,    53,     6,    53,
      48,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     1,
       2,     0,     0,     0,    53,     0,    25,    29,    31,    32,
      33,    34,    30,    27,    28,    26,    42,    35,    38,    36,
      37,    39,    40,    41,     0,     0,    43,    52,    47,    54,
      55
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int8 yypgoto[] =
{
     -50,    47,   -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,
     -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,   -50,
     -50,   -50,   -50,   -50,   -50,   -50,   -50,   -49,   -50
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
       0,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    73,    74
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int8 yytable[] =
{
      75,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    97,    51,    71,    72,    69,
       0,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,     0,
      87,    88,    89,    90,    91,    92,    93,    96,    94,    95,
      98,    99,   100,    70
};

static const yytype_int8 yycheck[] =
{
      49,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    74,    31,    28,    29,     0,
      -1,    31,    31,    31,    31,    31,    31,    31,    31,    31,
      31,    31,    31,    31,    31,    31,    31,    31,    30,    30,
      30,    30,    30,    30,    30,    30,    30,    30,    30,    -1,
      30,    30,    30,    30,    30,    30,    30,    27,    31,    31,
      27,    30,    30,    26
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    31,    31,    31,    31,    31,    31,    31,    31,    31,
      31,    31,    31,    31,    31,    31,    31,    31,    31,     0,
      33,    28,    29,    59,    60,    59,    30,    30,    30,    30,
      30,    30,    30,    30,    30,    30,    30,    30,    30,    30,
      30,    30,    30,    30,    31,    31,    27,    59,    27,    30,
      30
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    32,    33,    33,    34,    34,    34,    35,    35,    35,
      35,    35,    35,    35,    35,    35,    35,    35,    35,    35,
      35,    35,    35,    35,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    55,    55,    56,    57,    58,
      58,    58,    59,    59,    60,    60
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     0,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     1,     1,     1,     3,     1,     1,
       1,     1,     2,     0,     3,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 25: /* module_store: MODULE_STORE '=' ARG  */
#line 101 "conf-parse.y"
                                     {
                        if (parse_module_store((yyvsp[0].s)) != 0) {
                                parse_errors++;
                                YYABORT;
                        }
                        free((yyvsp[0].s));
                }
#line 1230 "conf-parse.c"
    break;

  case 26: /* store_root: STORE_ROOT '=' ARG  */
#line 111 "conf-parse.y"
                                    {
                        if (parse_store_root_path((yyvsp[0].s)) != 0) {
                                parse_errors++;
                                YYABORT;
                        }
                        free((yyvsp[0].s));
                }
#line 1242 "conf-parse.c"
    break;

  case 27: /* compiler_dir: COMPILER_DIR '=' ARG  */
#line 120 "conf-parse.y"
                                          {
                        if (parse_compiler_path((yyvsp[0].s)) != 0) {
                                parse_errors++;
                                YYABORT;
                        }
                        free((yyvsp[0].s));
                }
#line 1254 "conf-parse.c"
    break;

  case 28: /* ignore_module_cache: IGNORE_MODULE_CACHE '=' ARG  */
#line 129 "conf-parse.y"
                                                     {
							if (strcasecmp((yyvsp[0].s), "true") == 0)
								current_conf->ignore_module_cache = 1;
							else if (strcasecmp((yyvsp[0].s), "false") == 0)
								current_conf->ignore_module_cache = 0;
							else {
								yyerror("disable-caching can only be 'true' or 'false'");
							}
							free((yyvsp[0].s));
						}
#line 1269 "conf-parse.c"
    break;

  case 29: /* version: VERSION '=' ARG  */
#line 141 "conf-parse.y"
                                 {
                        current_conf->policyvers = atoi((yyvsp[0].s));
                        free((yyvsp[0].s));
                        if (current_conf->policyvers < sepol_policy_kern_vers_min() ||
                            current_conf->policyvers > sepol_policy_kern_vers_max()) {
                                parse_errors++;
                                YYABORT;
                        }
                }
#line 1283 "conf-parse.c"
    break;

  case 30: /* target_platform: TARGET_PLATFORM '=' ARG  */
#line 152 "conf-parse.y"
                                          {
                        if (strcasecmp((yyvsp[0].s), "selinux") == 0)
                                current_conf->target_platform = SEPOL_TARGET_SELINUX;
                        else if (strcasecmp((yyvsp[0].s), "xen") == 0)
                                current_conf->target_platform = SEPOL_TARGET_XEN;
                        else {
                                yyerror("target_platform can only be 'selinux' or 'xen'");
                        }
                        free((yyvsp[0].s));
                }
#line 1298 "conf-parse.c"
    break;

  case 31: /* expand_check: EXPAND_CHECK '=' ARG  */
#line 164 "conf-parse.y"
                                      {
                        current_conf->expand_check = atoi((yyvsp[0].s));
                        free((yyvsp[0].s));
                }
#line 1307 "conf-parse.c"
    break;

  case 32: /* file_mode: FILE_MODE '=' ARG  */
#line 170 "conf-parse.y"
                                {
                        current_conf->file_mode = strtoul((yyvsp[0].s), NULL, 8);
                        free((yyvsp[0].s));
                }
#line 1316 "conf-parse.c"
    break;

  case 33: /* save_previous: SAVE_PREVIOUS '=' ARG  */
#line 176 "conf-parse.y"
                                        {
	                if (strcasecmp((yyvsp[0].s), "true") == 0)
		                current_conf->save_previous = 1;
			else if (strcasecmp((yyvsp[0].s), "false") == 0)
				current_conf->save_previous = 0;		
			else {
				yyerror("save-previous can only be 'true' or 'false'");
			}
			free((yyvsp[0].s));
                }
#line 1331 "conf-parse.c"
    break;

  case 34: /* save_linked: SAVE_LINKED '=' ARG  */
#line 189 "conf-parse.y"
                                    {
	                if (strcasecmp((yyvsp[0].s), "true") == 0)
		                current_conf->save_linked = 1;
			else if (strcasecmp((yyvsp[0].s), "false") == 0)
				current_conf->save_linked = 0;		
			else {
				yyerror("save-linked can only be 'true' or 'false'");
			}
			free((yyvsp[0].s));
                }
#line 1346 "conf-parse.c"
    break;

  case 35: /* disable_genhomedircon: DISABLE_GENHOMEDIRCON '=' ARG  */
#line 201 "conf-parse.y"
                                                     {
	if (strcasecmp((yyvsp[0].s), "false") == 0) {
		current_conf->disable_genhomedircon = 0;
	} else if (strcasecmp((yyvsp[0].s), "true") == 0) {
		current_conf->disable_genhomedircon = 1;
	} else {
		yyerror("disable-genhomedircon can only be 'true' or 'false'");
	}
	free((yyvsp[0].s));
 }
#line 1361 "conf-parse.c"
    break;

  case 36: /* usepasswd: USEPASSWD '=' ARG  */
#line 212 "conf-parse.y"
                             {
	if (strcasecmp((yyvsp[0].s), "false") == 0) {
		current_conf->usepasswd = 0;
	} else if (strcasecmp((yyvsp[0].s), "true") == 0) {
		current_conf->usepasswd = 1;
	} else {
		yyerror("usepasswd can only be 'true' or 'false'");
	}
	free((yyvsp[0].s));
 }
#line 1376 "conf-parse.c"
    break;

  case 37: /* ignoredirs: IGNOREDIRS '=' ARG  */
#line 223 "conf-parse.y"
                               {
	current_conf->ignoredirs = strdup((yyvsp[0].s));
	free((yyvsp[0].s));
 }
#line 1385 "conf-parse.c"
    break;

  case 38: /* handle_unknown: HANDLE_UNKNOWN '=' ARG  */
#line 228 "conf-parse.y"
                                       {
	if (strcasecmp((yyvsp[0].s), "deny") == 0) {
		current_conf->handle_unknown = SEPOL_DENY_UNKNOWN;
	} else if (strcasecmp((yyvsp[0].s), "reject") == 0) {
		current_conf->handle_unknown = SEPOL_REJECT_UNKNOWN;
	} else if (strcasecmp((yyvsp[0].s), "allow") == 0) {
		current_conf->handle_unknown = SEPOL_ALLOW_UNKNOWN;
	} else {
		yyerror("handle-unknown can only be 'deny', 'reject' or 'allow'");
	}
	free((yyvsp[0].s));
 }
#line 1402 "conf-parse.c"
    break;

  case 39: /* bzip_blocksize: BZIP_BLOCKSIZE '=' ARG  */
#line 241 "conf-parse.y"
                                        {
	int blocksize = atoi((yyvsp[0].s));
	free((yyvsp[0].s));
	if (blocksize > 9)
		yyerror("bzip-blocksize can only be in the range 0-9");
	else
		current_conf->bzip_blocksize = blocksize;
}
#line 1415 "conf-parse.c"
    break;

  case 40: /* bzip_small: BZIP_SMALL '=' ARG  */
#line 250 "conf-parse.y"
                                {
	if (strcasecmp((yyvsp[0].s), "false") == 0) {
		current_conf->bzip_small = 0;
	} else if (strcasecmp((yyvsp[0].s), "true") == 0) {
		current_conf->bzip_small = 1;
	} else {
		yyerror("bzip-small can only be 'true' or 'false'");
	}
	free((yyvsp[0].s));
}
#line 1430 "conf-parse.c"
    break;

  case 41: /* remove_hll: REMOVE_HLL '=' ARG  */
#line 261 "conf-parse.y"
                               {
	if (strcasecmp((yyvsp[0].s), "false") == 0) {
		current_conf->remove_hll = 0;
	} else if (strcasecmp((yyvsp[0].s), "true") == 0) {
		current_conf->remove_hll = 1;
	} else {
		yyerror("remove-hll can only be 'true' or 'false'");
	}
	free((yyvsp[0].s));
}
#line 1445 "conf-parse.c"
    break;

  case 42: /* optimize_policy: OPTIMIZE_POLICY '=' ARG  */
#line 272 "conf-parse.y"
                                          {
	if (strcasecmp((yyvsp[0].s), "false") == 0) {
		current_conf->optimize_policy = 0;
	} else if (strcasecmp((yyvsp[0].s), "true") == 0) {
		current_conf->optimize_policy = 1;
	} else {
		yyerror("optimize-policy can only be 'true' or 'false'");
	}
	free((yyvsp[0].s));
}
#line 1460 "conf-parse.c"
    break;

  case 43: /* command_block: command_start external_opts BLOCK_END  */
#line 284 "conf-parse.y"
                                                       {
                        if (new_external->path == NULL) {
                                parse_errors++;
                                YYABORT;
                        }
                }
#line 1471 "conf-parse.c"
    break;

  case 44: /* command_start: LOAD_POLICY_START  */
#line 293 "conf-parse.y"
                                  {
                        semanage_conf_external_prog_destroy(current_conf->load_policy);
                        current_conf->load_policy = NULL;
                        if (new_external_prog(&current_conf->load_policy) == -1) {
                                parse_errors++;
                                YYABORT;
                        }
                }
#line 1484 "conf-parse.c"
    break;

  case 45: /* command_start: SETFILES_START  */
#line 301 "conf-parse.y"
                               {
                        semanage_conf_external_prog_destroy(current_conf->setfiles);
                        current_conf->setfiles = NULL;
                        if (new_external_prog(&current_conf->setfiles) == -1) {
                                parse_errors++;
                                YYABORT;
                        }
                }
#line 1497 "conf-parse.c"
    break;

  case 46: /* command_start: SEFCONTEXT_COMPILE_START  */
#line 309 "conf-parse.y"
                                         {
                        semanage_conf_external_prog_destroy(current_conf->sefcontext_compile);
                        current_conf->sefcontext_compile = NULL;
                        if (new_external_prog(&current_conf->sefcontext_compile) == -1) {
                                parse_errors++;
                                YYABORT;
                        }
                }
#line 1510 "conf-parse.c"
    break;

  case 47: /* verify_block: verify_start external_opts BLOCK_END  */
#line 319 "conf-parse.y"
                                                      {
                        if (new_external->path == NULL) {
                                parse_errors++;
                                YYABORT;
                        }
                }
#line 1521 "conf-parse.c"
    break;

  case 48: /* verify_start: verify_start_tok  */
#line 327 "conf-parse.y"
                                 {
                        if ((yyvsp[0].d) == -1) {
                                parse_errors++;
                                YYABORT;
                        }
                }
#line 1532 "conf-parse.c"
    break;

  case 49: /* verify_start_tok: VERIFY_MOD_START  */
#line 335 "conf-parse.y"
                                    {(yyval.d) = new_external_prog(&current_conf->mod_prog);}
#line 1538 "conf-parse.c"
    break;

  case 50: /* verify_start_tok: VERIFY_LINKED_START  */
#line 336 "conf-parse.y"
                                    {(yyval.d) = new_external_prog(&current_conf->linked_prog);}
#line 1544 "conf-parse.c"
    break;

  case 51: /* verify_start_tok: VERIFY_KERNEL_START  */
#line 337 "conf-parse.y"
                                    {(yyval.d) = new_external_prog(&current_conf->kernel_prog);}
#line 1550 "conf-parse.c"
    break;

  case 54: /* external_opt: PROG_PATH '=' ARG  */
#line 344 "conf-parse.y"
                                   { PASSIGN(new_external->path, (yyvsp[0].s)); }
#line 1556 "conf-parse.c"
    break;

  case 55: /* external_opt: PROG_ARGS '=' ARG  */
#line 345 "conf-parse.y"
                                   { PASSIGN(new_external->args, (yyvsp[0].s)); }
#line 1562 "conf-parse.c"
    break;


#line 1566 "conf-parse.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 348 "conf-parse.y"


static int semanage_conf_init(semanage_conf_t * conf)
{
	conf->store_type = SEMANAGE_CON_DIRECT;
	conf->store_path = strdup(basename(selinux_policy_root()));
	conf->ignoredirs = NULL;
	conf->store_root_path = strdup("/var/lib/selinux");
	conf->compiler_directory_path = strdup("/usr/libexec/selinux/hll");
	conf->policyvers = sepol_policy_kern_vers_max();
	conf->target_platform = SEPOL_TARGET_SELINUX;
	conf->expand_check = 1;
	conf->handle_unknown = -1;
	conf->usepasswd = 1;
	conf->file_mode = 0644;
	conf->bzip_blocksize = 9;
	conf->bzip_small = 0;
	conf->ignore_module_cache = 0;
	conf->remove_hll = 0;
	conf->optimize_policy = 0;

	conf->save_previous = 0;
	conf->save_linked = 0;

	if ((conf->load_policy =
	     calloc(1, sizeof(*(current_conf->load_policy)))) == NULL) {
		return -1;
	}

	if (access("/sbin/load_policy", X_OK) == 0) {
		conf->load_policy->path = strdup("/sbin/load_policy");
	} else {
		conf->load_policy->path = strdup("/usr/sbin/load_policy");
	}
	if (conf->load_policy->path == NULL) {
		return -1;
	}
	conf->load_policy->args = NULL;

	if ((conf->setfiles =
	     calloc(1, sizeof(*(current_conf->setfiles)))) == NULL) {
		return -1;
	}
	if (access("/sbin/setfiles", X_OK) == 0) {
		conf->setfiles->path = strdup("/sbin/setfiles");
	} else {
		conf->setfiles->path = strdup("/usr/sbin/setfiles");
	}
	if ((conf->setfiles->path == NULL) ||
	    (conf->setfiles->args = strdup("-q -c $@ $<")) == NULL) {
		return -1;
	}

	if ((conf->sefcontext_compile =
	     calloc(1, sizeof(*(current_conf->sefcontext_compile)))) == NULL) {
		return -1;
	}
	if (access("/sbin/sefcontext_compile", X_OK) == 0) {
		conf->sefcontext_compile->path = strdup("/sbin/sefcontext_compile");
	} else {
		conf->sefcontext_compile->path = strdup("/usr/sbin/sefcontext_compile");
	}
	if ((conf->sefcontext_compile->path == NULL) ||
	    (conf->sefcontext_compile->args = strdup("$@")) == NULL) {
		return -1;
	}

	return 0;
}

/* Parse a libsemanage configuration file.  THIS FUNCTION IS NOT
 * THREAD-SAFE!	 Return a newly allocated semanage_conf_t *.  If the
 * configuration file could be read, parse it; otherwise rely upon
 * default values.  If the file could not be parsed correctly or if
 * out of memory return NULL.
 */
semanage_conf_t *semanage_conf_parse(const char *config_filename)
{
	if ((current_conf = calloc(1, sizeof(*current_conf))) == NULL) {
		return NULL;
	}
	if (semanage_conf_init(current_conf) == -1) {
		goto cleanup;
	}
	if ((semanage_in = fopen(config_filename, "r")) == NULL) {
		/* configuration file does not exist or could not be
		 * read.  THIS IS NOT AN ERROR.  just rely on the
		 * defaults. */
		return current_conf;
	}
	parse_errors = 0;
	semanage_parse();
	fclose(semanage_in);
	semanage_lex_destroy();
	if (parse_errors != 0) {
		goto cleanup;
	}
	return current_conf;
      cleanup:
	semanage_conf_destroy(current_conf);
	return NULL;
}

static void semanage_conf_external_prog_destroy(external_prog_t * ep)
{
	while (ep != NULL) {
		external_prog_t *next = ep->next;
		free(ep->path);
		free(ep->args);
		free(ep);
		ep = next;
	}
}

/* Deallocates all space associated with a configuration struct,
 * including the pointer itself. */
void semanage_conf_destroy(semanage_conf_t * conf)
{
	if (conf != NULL) {
		free(conf->store_path);
		free(conf->ignoredirs);
		free(conf->store_root_path);
		free(conf->compiler_directory_path);
		semanage_conf_external_prog_destroy(conf->load_policy);
		semanage_conf_external_prog_destroy(conf->setfiles);
		semanage_conf_external_prog_destroy(conf->sefcontext_compile);
		semanage_conf_external_prog_destroy(conf->mod_prog);
		semanage_conf_external_prog_destroy(conf->linked_prog);
		semanage_conf_external_prog_destroy(conf->kernel_prog);
		free(conf);
	}
}

int semanage_error(const char *msg)
{
	fprintf(stderr, "error parsing semanage configuration file: %s\n", msg);
	parse_errors++;
	return 0;
}

/* Take the string argument for a module store.	 If it is exactly the
 * word "direct" then have libsemanage directly manipulate the module
 * store. The policy path will default to the active policy directory.
 * Otherwise if it begins with a forward slash interpret it as
 * an absolute path to a named socket, to which a policy server is
 * listening on the other end.	Otherwise treat it as the host name to
 * an external server; if there is a colon in the name then everything
 * after gives a port number.  The default port number is 4242.
 * Returns 0 on success, -1 if out of memory, -2 if a port number is
 * illegal.
 */
static int parse_module_store(char *arg)
{
	/* arg is already a strdup()ed copy of yytext */
	if (arg == NULL) {
		return -1;
	}
	free(current_conf->store_path);
	if (strcmp(arg, "direct") == 0) {
		current_conf->store_type = SEMANAGE_CON_DIRECT;
		current_conf->store_path =
		    strdup(basename(selinux_policy_root()));
		current_conf->server_port = -1;
	} else if (*arg == '/') {
		current_conf->store_type = SEMANAGE_CON_POLSERV_LOCAL;
		current_conf->store_path = strdup(arg);
		current_conf->server_port = -1;
	} else {
		char *s;
		current_conf->store_type = SEMANAGE_CON_POLSERV_REMOTE;
		if ((s = strchr(arg, ':')) == NULL) {
			current_conf->store_path = strdup(arg);
			current_conf->server_port = 4242;
		} else {
			char *endptr;
			*s = '\0';
			current_conf->store_path = strdup(arg);
			current_conf->server_port = strtol(s + 1, &endptr, 10);
			if (*(s + 1) == '\0' || *endptr != '\0') {
				return -2;
			}
		}
	}
	return 0;
}

static int parse_store_root_path(char *arg)
{
	if (arg == NULL) {
		return -1;
	}

	free(current_conf->store_root_path);
	current_conf->store_root_path = strdup(arg);
	return 0;
}

static int parse_compiler_path(char *arg)
{
	if (arg == NULL) {
		return -1;
	}
	free(current_conf->compiler_directory_path);
	current_conf->compiler_directory_path = strdup(arg);
	return 0;
}

/* Helper function; called whenever configuration file specifies
 * another external program.  Returns 0 on success, -1 if out of
 * memory.
 */
static int new_external_prog(external_prog_t ** chain)
{
	if ((new_external = calloc(1, sizeof(*new_external))) == NULL) {
		return -1;
	}
	/* hook this new external program to the end of the chain */
	if (*chain == NULL) {
		*chain = new_external;
	} else {
		external_prog_t *prog = *chain;
		while (prog->next != NULL) {
			prog = prog->next;
		}
		prog->next = new_external;
	}
	return 0;
}

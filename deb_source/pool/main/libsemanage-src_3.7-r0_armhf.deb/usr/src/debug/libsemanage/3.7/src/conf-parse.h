/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_SEMANAGE_CONF_PARSE_H_INCLUDED
# define YY_SEMANAGE_CONF_PARSE_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int semanage_debug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    MODULE_STORE = 258,            /* MODULE_STORE  */
    VERSION = 259,                 /* VERSION  */
    EXPAND_CHECK = 260,            /* EXPAND_CHECK  */
    FILE_MODE = 261,               /* FILE_MODE  */
    SAVE_PREVIOUS = 262,           /* SAVE_PREVIOUS  */
    SAVE_LINKED = 263,             /* SAVE_LINKED  */
    TARGET_PLATFORM = 264,         /* TARGET_PLATFORM  */
    COMPILER_DIR = 265,            /* COMPILER_DIR  */
    IGNORE_MODULE_CACHE = 266,     /* IGNORE_MODULE_CACHE  */
    STORE_ROOT = 267,              /* STORE_ROOT  */
    OPTIMIZE_POLICY = 268,         /* OPTIMIZE_POLICY  */
    LOAD_POLICY_START = 269,       /* LOAD_POLICY_START  */
    SETFILES_START = 270,          /* SETFILES_START  */
    SEFCONTEXT_COMPILE_START = 271, /* SEFCONTEXT_COMPILE_START  */
    DISABLE_GENHOMEDIRCON = 272,   /* DISABLE_GENHOMEDIRCON  */
    HANDLE_UNKNOWN = 273,          /* HANDLE_UNKNOWN  */
    USEPASSWD = 274,               /* USEPASSWD  */
    IGNOREDIRS = 275,              /* IGNOREDIRS  */
    BZIP_BLOCKSIZE = 276,          /* BZIP_BLOCKSIZE  */
    BZIP_SMALL = 277,              /* BZIP_SMALL  */
    REMOVE_HLL = 278,              /* REMOVE_HLL  */
    VERIFY_MOD_START = 279,        /* VERIFY_MOD_START  */
    VERIFY_LINKED_START = 280,     /* VERIFY_LINKED_START  */
    VERIFY_KERNEL_START = 281,     /* VERIFY_KERNEL_START  */
    BLOCK_END = 282,               /* BLOCK_END  */
    PROG_PATH = 283,               /* PROG_PATH  */
    PROG_ARGS = 284,               /* PROG_ARGS  */
    ARG = 285                      /* ARG  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 57 "conf-parse.y"

        int d;
        char *s;

#line 99 "conf-parse.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE semanage_lval;


int semanage_parse (void);


#endif /* !YY_SEMANAGE_CONF_PARSE_H_INCLUDED  */

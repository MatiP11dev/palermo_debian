extern encode_t shiftjis_encoding;

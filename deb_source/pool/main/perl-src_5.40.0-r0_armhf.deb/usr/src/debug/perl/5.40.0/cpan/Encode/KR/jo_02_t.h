extern encode_t johab_encoding;

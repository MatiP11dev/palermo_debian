extern encode_t jis0201_raw_encoding;

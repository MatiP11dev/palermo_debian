extern encode_t cp950_encoding;

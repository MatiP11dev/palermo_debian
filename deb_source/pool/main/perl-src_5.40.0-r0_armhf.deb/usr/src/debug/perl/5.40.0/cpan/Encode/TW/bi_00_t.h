extern encode_t big5_eten_encoding;

extern encode_t cp1026_encoding;
extern encode_t cp1047_encoding;
extern encode_t cp37_encoding;
extern encode_t cp500_encoding;
extern encode_t cp875_encoding;
extern encode_t posix_bc_encoding;

#include "encode.h"

#ifdef __cplusplus
extern encpage_t utf8_AdobeSymbol[18];
#else
static const encpage_t utf8_AdobeSymbol[18];
#endif
#ifdef __cplusplus
extern encpage_t utf8_AdobeZdingbat[5];
#else
static const encpage_t utf8_AdobeZdingbat[5];
#endif
#ifdef __cplusplus
extern encpage_t utf8_MacDingbats[3];
#else
static const encpage_t utf8_MacDingbats[3];
#endif
#ifdef __cplusplus
extern encpage_t utf8_MacSymbol[19];
#else
static const encpage_t utf8_MacSymbol[19];
#endif
#ifdef __cplusplus
extern encpage_t utf8_dingbats[5];
#else
static const encpage_t utf8_dingbats[5];
#endif
#ifdef __cplusplus
extern encpage_t utf8_symbol[19];
#else
static const encpage_t utf8_symbol[19];
#endif

static const U8 enctable[1859] = { 226,156,129,226,156,130,226,156,131,226,
156,132,226,152,142,226,156,134,226,156,135,226,156,136,226,156,137,226,152,
155,226,152,158,226,156,140,226,156,141,226,156,142,226,156,143,226,156,144,
226,156,145,226,156,146,226,156,147,226,156,148,226,156,149,226,156,150,226,
156,151,226,156,152,226,156,153,226,156,154,226,156,155,226,156,156,226,156,
157,226,156,158,226,156,159,226,156,160,226,156,161,226,156,162,226,156,163,
226,156,164,226,156,165,226,156,166,226,156,167,226,152,133,226,156,169,226,
156,170,226,156,171,226,156,172,226,156,173,226,156,174,226,156,175,226,156,
176,226,156,177,226,156,178,226,156,179,226,156,180,226,156,181,226,156,182,
226,156,183,226,156,184,226,156,185,226,156,186,226,156,187,226,156,188,226,
156,189,226,156,190,226,156,191,226,157,128,226,157,129,226,157,130,226,157,
131,226,157,132,226,157,133,226,157,134,226,157,135,226,157,136,226,157,137,
226,157,138,226,157,139,226,151,143,226,157,141,226,150,160,226,157,143,226,
157,144,226,157,145,226,157,146,226,150,178,226,150,188,226,151,134,226,157,
150,226,151,151,226,157,152,226,157,153,226,157,154,226,157,155,226,157,156,
226,157,157,226,157,158,226,157,161,226,157,162,226,157,163,226,157,164,226,
157,165,226,157,166,226,157,167,226,153,163,226,153,166,226,153,165,226,153,
160,226,145,160,226,145,161,226,145,162,226,145,163,226,145,164,226,145,165,
226,145,166,226,145,167,226,145,168,226,145,169,226,157,182,226,157,183,226,
157,184,226,157,185,226,157,186,226,157,187,226,157,188,226,157,189,226,157,
190,226,157,191,226,158,128,226,158,129,226,158,130,226,158,131,226,158,132,
226,158,133,226,158,134,226,158,135,226,158,136,226,158,137,226,158,138,226,
158,139,226,158,140,226,158,141,226,158,142,226,158,143,226,158,144,226,158,
145,226,158,146,226,158,147,226,158,148,226,134,146,226,134,148,226,134,149,
226,158,152,226,158,153,226,158,154,226,158,155,226,158,156,226,158,157,226,
158,158,226,158,159,226,158,160,226,158,161,226,158,162,226,158,163,226,158,
164,226,158,165,226,158,166,226,158,167,226,158,168,226,158,169,226,158,170,
226,158,171,226,158,172,226,158,173,226,158,174,226,158,175,226,136,167,226,
136,168,226,135,148,226,135,144,226,135,145,226,135,146,226,135,147,226,139,
132,226,140,169,239,163,168,239,163,169,239,163,170,226,136,145,239,163,171,
239,163,172,239,163,173,239,163,174,239,163,175,239,163,176,239,163,177,239,
163,178,239,163,179,239,163,180,239,163,191,226,140,170,226,136,171,226,140,
160,239,163,181,226,140,161,239,163,182,239,163,183,239,163,184,239,163,185,
239,163,186,239,163,187,239,163,188,239,163,189,239,163,190,226,137,160,226,
137,161,226,137,136,226,128,166,239,163,166,239,163,167,226,134,181,226,132,
181,226,132,145,226,132,156,226,132,152,226,138,151,226,138,149,226,136,133,
226,136,169,226,136,170,226,138,131,226,138,135,226,138,132,226,138,130,226,
138,134,226,136,136,226,136,137,226,136,160,226,136,135,239,155,154,239,155,
153,239,155,155,226,136,143,226,136,154,226,139,133,226,136,145,226,142,155,
226,142,156,226,142,157,226,142,161,226,142,162,226,142,163,226,142,167,226,
142,168,226,142,169,226,142,170,239,163,191,227,128,137,226,136,171,226,140,
160,226,142,174,226,140,161,226,142,158,226,142,159,226,142,160,226,142,164,
226,142,165,226,142,166,226,142,171,226,142,172,226,142,173,226,137,160,226,
137,161,226,137,136,226,128,166,239,163,166,226,142,175,226,134,181,226,132,
181,226,132,145,226,132,156,226,132,152,226,138,151,226,138,149,226,136,133,
226,136,169,226,136,170,226,138,131,226,138,135,226,138,132,226,138,130,226,
138,134,226,136,136,226,136,137,226,136,160,226,136,135,226,136,167,226,136,
168,226,135,148,226,135,144,226,135,145,226,135,146,226,135,147,226,151,138,
226,140,169,239,163,168,239,163,169,239,163,170,226,136,145,239,163,171,239,
163,172,239,163,173,239,163,174,239,163,175,239,163,176,239,163,177,239,163,
178,239,163,179,239,163,180,194,128,194,129,194,130,194,131,194,132,194,133,
194,134,194,135,194,136,194,137,194,138,194,139,194,140,194,141,194,142,194,
143,194,144,194,145,194,146,194,147,194,148,194,149,194,150,194,151,194,152,
194,153,194,154,194,155,194,156,194,157,194,158,194,159,206,145,206,146,206,
167,206,148,206,149,206,166,206,147,206,151,206,153,207,145,206,154,206,155,
206,156,206,157,206,159,206,160,206,152,206,161,206,163,206,164,206,165,207,
130,206,169,206,158,206,168,206,150,206,177,206,178,207,135,206,180,206,181,
207,134,206,179,206,183,206,185,207,149,206,186,206,187,194,181,206,189,206,
191,207,128,206,184,207,129,207,131,207,132,207,133,207,150,207,137,206,190,
207,136,206,182,206,177,206,178,207,135,206,180,206,181,207,134,206,179,206,
183,206,185,207,149,206,186,206,187,206,188,206,189,206,191,207,128,206,184,
207,129,207,131,207,132,207,133,207,150,207,137,206,190,207,136,206,182,226,
157,168,226,157,169,226,157,170,226,157,171,226,157,172,226,157,173,226,157,
174,226,157,175,226,157,176,226,157,177,226,157,178,226,157,179,226,157,180,
226,157,181,226,158,177,226,158,178,226,158,179,226,158,180,226,158,181,226,
158,182,226,158,183,226,158,184,226,158,185,226,158,186,226,158,187,226,158,
188,226,158,189,226,158,190,239,163,151,239,163,152,239,163,153,239,163,154,
239,163,155,239,163,156,239,163,157,239,163,158,239,163,159,239,163,160,239,
163,161,239,163,162,239,163,163,239,163,164,0,1,2,3,4,5,6,7,8,9,10,11,12,13,
14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,128,129,130,131,
132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,
151,152,153,154,155,156,157,158,159,161,162,163,164,165,166,167,128,129,130,
131,132,133,134,135,136,137,138,139,140,141,182,183,184,185,186,187,188,189,
190,191,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,
67,68,69,70,71,96,189,190,226,227,228,230,231,232,233,234,235,236,237,238,239,
244,246,247,248,249,250,251,252,253,254,240,226,136,167,226,136,168,226,135,
148,226,135,144,226,135,145,226,135,146,226,135,147,226,139,132,227,128,136,
226,153,163,226,153,166,226,153,165,226,153,160,226,134,148,226,134,144,226,
134,145,226,134,146,226,134,147,216,217,218,219,220,221,222,223,224,225,226,
227,228,229,230,231,232,233,234,235,236,237,238,239,73,74,75,76,77,78,79,80,
81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,192,193,194,195,196,197,198,199,
200,201,202,203,204,205,206,207,208,209,210,211,212,230,231,232,246,247,248,
233,234,235,249,250,251,236,237,238,239,252,253,254,244,190,65,66,71,68,69,90,
72,81,73,75,76,77,78,88,79,80,82,97,98,103,100,101,122,104,113,105,107,108,
109,110,120,111,241,242,243,244,245,246,247,248,249,250,251,252,253,254,96,97,
98,99,100,101,102,103,104,105,106,107,226,128,178,226,137,164,226,129,132,226,
136,158,226,132,162,226,136,143,226,136,154,226,139,133,112,114,86,115,116,
117,102,99,121,119,172,173,174,175,176,177,178,179,180,181,194,174,239,161,
191,194,169,239,161,191,226,136,157,226,136,130,226,128,162,83,84,85,70,67,89,
87,120,121,122,123,124,125,126,226,128,179,226,137,165,226,132,162,239,161,
191,172,173,174,175,171,217,218,199,200,242,220,221,222,223,219,33,34,35,36,
38,39,40,41,111,112,113,114,194,174,194,169,194,176,194,177,204,201,203,209,
206,207,211,210,212,226,130,172,226,136,128,226,136,131,226,136,139,226,136,
141,226,136,146,226,136,151,226,136,180,226,136,188,226,137,133,226,138,165,
239,163,165,37,38,43,44,74,161,106,118,162,178,169,168,170,169,181,165,182,36,
194,172,195,151,195,183,198,146,205,202,207,146,214,215,224,215,225,241,229,
45,243,245,42,127,213 };
#ifdef __cplusplus
encpage_t AdobeSymbol_utf8[37] = {
#else
static const encpage_t AdobeSymbol_utf8[37] = {
#endif
{enctable + 1294,AdobeSymbol_utf8,0x00,0x21,1,1},
{enctable + 1783,AdobeSymbol_utf8,0x22,0x22,3,1},
{enctable + 1753,AdobeSymbol_utf8,0x23,0x23,1,1},
{enctable + 1786,AdobeSymbol_utf8,0x24,0x24,3,1},
{enctable + 1816,AdobeSymbol_utf8,0x25,0x26,1,1},
{enctable + 1789,AdobeSymbol_utf8,0x27,0x27,3,1},
{enctable + 1757,AdobeSymbol_utf8,0x28,0x29,1,1},
{enctable + 1798,AdobeSymbol_utf8,0x2a,0x2a,3,1},
{enctable + 1818,AdobeSymbol_utf8,0x2b,0x2c,1,1},
{enctable + 1795,AdobeSymbol_utf8,0x2d,0x2d,3,1},
{enctable + 1393,AdobeSymbol_utf8,0x2e,0x3f,1,1},
{enctable + 1807,AdobeSymbol_utf8,0x40,0x40,3,1},
{enctable + 1012,AdobeSymbol_utf8,0x41,0x5a,2,1},
{enctable + 1542,AdobeSymbol_utf8,0x5b,0x5b,1,1},
{enctable + 1801,AdobeSymbol_utf8,0x5c,0x5c,3,1},
{enctable + 1544,AdobeSymbol_utf8,0x5d,0x5d,1,1},
{enctable + 1810,AdobeSymbol_utf8,0x5e,0x5e,3,1},
{enctable + 1546,AdobeSymbol_utf8,0x5f,0x5f,1,1},
{enctable + 1813,AdobeSymbol_utf8,0x60,0x60,3,1},
{enctable + 1064,AdobeSymbol_utf8,0x61,0x7a,2,1},
{enctable + 1720,AdobeSymbol_utf8,0x7b,0x7d,1,1},
{enctable + 1804,AdobeSymbol_utf8,0x7e,0x7e,3,1},
{enctable + 1780,AdobeSymbol_utf8,0xa0,0xa0,3,1},
{enctable + 1844,AdobeSymbol_utf8,0xa1,0xa1,2,1},
{enctable + 1647,AdobeSymbol_utf8,0xa2,0xa5,3,1},
{enctable + 1840,AdobeSymbol_utf8,0xa6,0xa6,2,1},
{enctable + 1473,AdobeSymbol_utf8,0xa7,0xaf,3,1},
{enctable + 1767,AdobeSymbol_utf8,0xb0,0xb1,2,1},
{enctable + 1724,AdobeSymbol_utf8,0xb2,0xb3,3,1},
{enctable + 1836,AdobeSymbol_utf8,0xb4,0xb4,2,1},
{enctable + 1701,AdobeSymbol_utf8,0xb5,0xb7,3,1},
{enctable + 1838,AdobeSymbol_utf8,0xb8,0xb8,2,1},
{enctable + 633,AdobeSymbol_utf8,0xb9,0xd7,3,1},
{enctable + 1834,AdobeSymbol_utf8,0xd8,0xd8,2,1},
{enctable + 879,AdobeSymbol_utf8,0xd9,0xef,3,1},
{enctable + 591,AdobeSymbol_utf8,0xf1,0xfe,3,1},
{0,AdobeSymbol_utf8,0xff,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_c2[5] = {
#else
static const encpage_t utf8_AdobeSymbol_c2[5] = {
#endif
{enctable + 1326,utf8_AdobeSymbol,0xa0,0xa0,1,1},
{enctable + 1500,utf8_AdobeSymbol,0xac,0xac,1,1},
{enctable + 1685,utf8_AdobeSymbol,0xb0,0xb1,1,1},
{enctable + 1617,utf8_AdobeSymbol,0xb5,0xb5,1,1},
{0,utf8_AdobeSymbol_c2,0xb6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_c3[3] = {
#else
static const encpage_t utf8_AdobeSymbol_c3[3] = {
#endif
{enctable + 155,utf8_AdobeSymbol,0x97,0x97,1,1},
{enctable + 167,utf8_AdobeSymbol,0xb7,0xb7,1,1},
{0,utf8_AdobeSymbol_c3,0xb8,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_c6[2] = {
#else
static const encpage_t utf8_AdobeSymbol_c6[2] = {
#endif
{enctable + 113,utf8_AdobeSymbol,0x92,0x92,1,1},
{0,utf8_AdobeSymbol_c6,0x93,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_ce[6] = {
#else
static const encpage_t utf8_AdobeSymbol_ce[6] = {
#endif
{enctable + 1589,utf8_AdobeSymbol,0x91,0xa1,1,1},
{enctable + 1710,utf8_AdobeSymbol,0xa3,0xa9,1,1},
{enctable + 1606,utf8_AdobeSymbol,0xb1,0xbb,1,1},
{enctable + 1617,utf8_AdobeSymbol,0xbc,0xbc,1,1},
{enctable + 1618,utf8_AdobeSymbol,0xbd,0xbf,1,1},
{0,utf8_AdobeSymbol_ce,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_cf[4] = {
#else
static const encpage_t utf8_AdobeSymbol_cf[4] = {
#endif
{enctable + 1671,utf8_AdobeSymbol,0x80,0x89,1,1},
{enctable + 1820,utf8_AdobeSymbol,0x91,0x92,1,1},
{enctable + 1822,utf8_AdobeSymbol,0x95,0x96,1,1},
{0,utf8_AdobeSymbol_cf,0x97,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_80[4] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_80[4] = {
#endif
{enctable + 164,utf8_AdobeSymbol,0xa2,0xa2,1,1},
{enctable + 179,utf8_AdobeSymbol,0xa6,0xa6,1,1},
{enctable + 1824,utf8_AdobeSymbol,0xb2,0xb3,1,1},
{0,utf8_AdobeSymbol_e2_80,0xb4,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_81[2] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_81[2] = {
#endif
{enctable + 107,utf8_AdobeSymbol,0x84,0x84,1,1},
{0,utf8_AdobeSymbol_e2_81,0x85,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_82[2] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_82[2] = {
#endif
{enctable + 95,utf8_AdobeSymbol,0xac,0xac,1,1},
{0,utf8_AdobeSymbol_e2_82,0xad,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_84[6] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_84[6] = {
#endif
{enctable + 1548,utf8_AdobeSymbol,0x91,0x91,1,1},
{enctable + 1550,utf8_AdobeSymbol,0x98,0x98,1,1},
{enctable + 948,utf8_AdobeSymbol,0x9c,0x9c,1,1},
{enctable + 1538,utf8_AdobeSymbol,0xa6,0xa6,1,1},
{enctable + 1547,utf8_AdobeSymbol,0xb5,0xb5,1,1},
{0,utf8_AdobeSymbol_e2_84,0xb6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_86[3] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_86[3] = {
#endif
{enctable + 1736,utf8_AdobeSymbol,0x90,0x94,1,1},
{enctable + 188,utf8_AdobeSymbol,0xb5,0xb5,1,1},
{0,utf8_AdobeSymbol_e2_86,0xb6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_87[2] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_87[2] = {
#endif
{enctable + 1746,utf8_AdobeSymbol,0x90,0x94,1,1},
{0,utf8_AdobeSymbol_e2_87,0x95,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_88[17] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_88[17] = {
#endif
{enctable + 1752,utf8_AdobeSymbol,0x80,0x80,1,1},
{enctable + 1832,utf8_AdobeSymbol,0x82,0x83,1,1},
{enctable + 1553,utf8_AdobeSymbol,0x85,0x85,1,1},
{enctable + 1415,utf8_AdobeSymbol,0x86,0x86,1,1},
{enctable + 1774,utf8_AdobeSymbol,0x87,0x89,1,1},
{enctable + 1756,utf8_AdobeSymbol,0x8b,0x8b,1,1},
{enctable + 1858,utf8_AdobeSymbol,0x8f,0x8f,1,1},
{enctable + 1852,utf8_AdobeSymbol,0x91,0x92,1,1},
{enctable + 107,utf8_AdobeSymbol,0x95,0x95,1,1},
{enctable + 1856,utf8_AdobeSymbol,0x97,0x97,1,1},
{enctable + 1846,utf8_AdobeSymbol,0x9a,0x9a,1,1},
{enctable + 1830,utf8_AdobeSymbol,0x9d,0x9e,1,1},
{enctable + 1563,utf8_AdobeSymbol,0xa0,0xa0,1,1},
{enctable + 1741,utf8_AdobeSymbol,0xa7,0xab,1,1},
{enctable + 1543,utf8_AdobeSymbol,0xb4,0xb4,1,1},
{enctable + 1723,utf8_AdobeSymbol,0xbc,0xbc,1,1},
{0,utf8_AdobeSymbol_e2_88,0xbd,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_89[5] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_89[5] = {
#endif
{enctable + 1411,utf8_AdobeSymbol,0x85,0x85,1,1},
{enctable + 176,utf8_AdobeSymbol,0x88,0x88,1,1},
{enctable + 1384,utf8_AdobeSymbol,0xa0,0xa1,1,1},
{enctable + 583,utf8_AdobeSymbol,0xa4,0xa5,1,1},
{0,utf8_AdobeSymbol_e2_89,0xa6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_8a[6] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_8a[6] = {
#endif
{enctable + 1771,utf8_AdobeSymbol,0x82,0x84,1,1},
{enctable + 1842,utf8_AdobeSymbol,0x86,0x87,1,1},
{enctable + 1552,utf8_AdobeSymbol,0x95,0x95,1,1},
{enctable + 1551,utf8_AdobeSymbol,0x97,0x97,1,1},
{enctable + 1545,utf8_AdobeSymbol,0xa5,0xa5,1,1},
{0,utf8_AdobeSymbol_e2_8a,0xa6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_8b[2] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_8b[2] = {
#endif
{enctable + 1847,utf8_AdobeSymbol,0x85,0x85,1,1},
{0,utf8_AdobeSymbol_e2_8b,0x86,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_8c[3] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_8c[3] = {
#endif
{enctable + 1854,utf8_AdobeSymbol,0xa0,0xa1,1,1},
{enctable + 1850,utf8_AdobeSymbol,0xa9,0xaa,1,1},
{0,utf8_AdobeSymbol_e2_8c,0xab,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_97[2] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_97[2] = {
#endif
{enctable + 1508,utf8_AdobeSymbol,0x8a,0x8a,1,1},
{0,utf8_AdobeSymbol_e2_97,0x8b,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2_99[4] = {
#else
static const encpage_t utf8_AdobeSymbol_e2_99[4] = {
#endif
{enctable + 125,utf8_AdobeSymbol,0xa0,0xa0,1,1},
{enctable + 116,utf8_AdobeSymbol,0xa3,0xa3,1,1},
{enctable + 1826,utf8_AdobeSymbol,0xa5,0xa6,1,1},
{0,utf8_AdobeSymbol_e2_99,0xa7,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_e2[14] = {
#else
static const encpage_t utf8_AdobeSymbol_e2[14] = {
#endif
{0,utf8_AdobeSymbol_e2_80,0x80,0x80,0,2},
{0,utf8_AdobeSymbol_e2_81,0x81,0x81,0,2},
{0,utf8_AdobeSymbol_e2_82,0x82,0x82,0,2},
{0,utf8_AdobeSymbol_e2_84,0x84,0x84,0,2},
{0,utf8_AdobeSymbol_e2_86,0x86,0x86,0,2},
{0,utf8_AdobeSymbol_e2_87,0x87,0x87,0,2},
{0,utf8_AdobeSymbol_e2_88,0x88,0x88,0,2},
{0,utf8_AdobeSymbol_e2_89,0x89,0x89,0,2},
{0,utf8_AdobeSymbol_e2_8a,0x8a,0x8a,0,2},
{0,utf8_AdobeSymbol_e2_8b,0x8b,0x8b,0,2},
{0,utf8_AdobeSymbol_e2_8c,0x8c,0x8c,0,2},
{0,utf8_AdobeSymbol_e2_97,0x97,0x97,0,2},
{0,utf8_AdobeSymbol_e2_99,0x99,0x99,0,2},
{0,utf8_AdobeSymbol_e2,0x9a,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_ef_9b[2] = {
#else
static const encpage_t utf8_AdobeSymbol_ef_9b[2] = {
#endif
{enctable + 1777,utf8_AdobeSymbol,0x99,0x9b,1,1},
{0,utf8_AdobeSymbol_ef_9b,0x9c,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_ef_a3[2] = {
#else
static const encpage_t utf8_AdobeSymbol_ef_a3[2] = {
#endif
{enctable + 1419,utf8_AdobeSymbol,0xa5,0xbe,1,1},
{0,utf8_AdobeSymbol_ef_a3,0xbf,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol_ef[3] = {
#else
static const encpage_t utf8_AdobeSymbol_ef[3] = {
#endif
{0,utf8_AdobeSymbol_ef_9b,0x9b,0x9b,0,2},
{0,utf8_AdobeSymbol_ef_a3,0xa3,0xa3,0,2},
{0,utf8_AdobeSymbol_ef,0xa4,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeSymbol[18] = {
#else
static const encpage_t utf8_AdobeSymbol[18] = {
#endif
{enctable + 1294,utf8_AdobeSymbol,0x00,0x21,1,1},
{enctable + 1753,utf8_AdobeSymbol,0x23,0x23,1,1},
{enctable + 1816,utf8_AdobeSymbol,0x25,0x26,1,1},
{enctable + 1757,utf8_AdobeSymbol,0x28,0x29,1,1},
{enctable + 1818,utf8_AdobeSymbol,0x2b,0x2c,1,1},
{enctable + 1393,utf8_AdobeSymbol,0x2e,0x3f,1,1},
{enctable + 1542,utf8_AdobeSymbol,0x5b,0x5b,1,1},
{enctable + 1544,utf8_AdobeSymbol,0x5d,0x5d,1,1},
{enctable + 1546,utf8_AdobeSymbol,0x5f,0x5f,1,1},
{enctable + 1720,utf8_AdobeSymbol,0x7b,0x7d,1,1},
{0,utf8_AdobeSymbol_c2,0xc2,0xc2,0,2},
{0,utf8_AdobeSymbol_c3,0xc3,0xc3,0,2},
{0,utf8_AdobeSymbol_c6,0xc6,0xc6,0,2},
{0,utf8_AdobeSymbol_ce,0xce,0xce,0,2},
{0,utf8_AdobeSymbol_cf,0xcf,0xcf,0,2},
{0,utf8_AdobeSymbol_e2,0xe2,0xe2,0,3},
{0,utf8_AdobeSymbol_ef,0xef,0xef,0,3},
{0,utf8_AdobeSymbol,0xf0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t AdobeZdingbat_utf8[6] = {
#else
static const encpage_t AdobeZdingbat_utf8[6] = {
#endif
{enctable + 1294,AdobeZdingbat_utf8,0x00,0x20,1,1},
{enctable + 0,AdobeZdingbat_utf8,0x21,0x7e,3,1},
{enctable + 1252,AdobeZdingbat_utf8,0x80,0x8d,3,1},
{enctable + 282,AdobeZdingbat_utf8,0xa1,0xef,3,1},
{enctable + 1210,AdobeZdingbat_utf8,0xf1,0xfe,3,1},
{0,AdobeZdingbat_utf8,0xff,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_c2[2] = {
#else
static const encpage_t utf8_AdobeZdingbat_c2[2] = {
#endif
{enctable + 1326,utf8_AdobeZdingbat,0xa0,0xa0,1,1},
{0,utf8_AdobeZdingbat_c2,0xa1,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_86[3] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_86[3] = {
#endif
{enctable + 1858,utf8_AdobeZdingbat,0x92,0x92,1,1},
{enctable + 1846,utf8_AdobeZdingbat,0x94,0x95,1,1},
{0,utf8_AdobeZdingbat_e2_86,0x96,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_91[2] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_91[2] = {
#endif
{enctable + 1681,utf8_AdobeZdingbat,0xa0,0xa9,1,1},
{0,utf8_AdobeZdingbat_e2_91,0xaa,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_96[4] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_96[4] = {
#endif
{enctable + 1618,utf8_AdobeZdingbat,0xa0,0xa0,1,1},
{enctable + 1674,utf8_AdobeZdingbat,0xb2,0xb2,1,1},
{enctable + 1675,utf8_AdobeZdingbat,0xbc,0xbc,1,1},
{0,utf8_AdobeZdingbat_e2_96,0xbd,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_97[4] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_97[4] = {
#endif
{enctable + 1676,utf8_AdobeZdingbat,0x86,0x86,1,1},
{enctable + 1616,utf8_AdobeZdingbat,0x8f,0x8f,1,1},
{enctable + 1680,utf8_AdobeZdingbat,0x97,0x97,1,1},
{0,utf8_AdobeZdingbat_e2_97,0x98,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_98[5] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_98[5] = {
#endif
{enctable + 1595,utf8_AdobeZdingbat,0x85,0x85,1,1},
{enctable + 1816,utf8_AdobeZdingbat,0x8e,0x8e,1,1},
{enctable + 1856,utf8_AdobeZdingbat,0x9b,0x9b,1,1},
{enctable + 1818,utf8_AdobeZdingbat,0x9e,0x9e,1,1},
{0,utf8_AdobeZdingbat_e2_98,0x9f,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_99[4] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_99[4] = {
#endif
{enctable + 128,utf8_AdobeZdingbat,0xa0,0xa0,1,1},
{enctable + 341,utf8_AdobeZdingbat,0xa3,0xa3,1,1},
{enctable + 1828,utf8_AdobeZdingbat,0xa5,0xa6,1,1},
{0,utf8_AdobeZdingbat_e2_99,0xa7,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_9c[5] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_9c[5] = {
#endif
{enctable + 1751,utf8_AdobeZdingbat,0x81,0x84,1,1},
{enctable + 1755,utf8_AdobeZdingbat,0x86,0x89,1,1},
{enctable + 1391,utf8_AdobeZdingbat,0x8c,0xa7,1,1},
{enctable + 1524,utf8_AdobeZdingbat,0xa9,0xbf,1,1},
{0,utf8_AdobeZdingbat_e2_9c,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_9d[8] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_9d[8] = {
#endif
{enctable + 1635,utf8_AdobeZdingbat,0x80,0x8b,1,1},
{enctable + 1617,utf8_AdobeZdingbat,0x8d,0x8d,1,1},
{enctable + 1759,utf8_AdobeZdingbat,0x8f,0x92,1,1},
{enctable + 1823,utf8_AdobeZdingbat,0x96,0x96,1,1},
{enctable + 1717,utf8_AdobeZdingbat,0x98,0x9e,1,1},
{enctable + 1360,utf8_AdobeZdingbat,0xa1,0xa7,1,1},
{enctable + 1381,utf8_AdobeZdingbat,0xb6,0xbf,1,1},
{0,utf8_AdobeZdingbat_e2_9d,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2_9e[4] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2_9e[4] = {
#endif
{enctable + 1547,utf8_AdobeZdingbat,0x80,0x94,1,1},
{enctable + 1500,utf8_AdobeZdingbat,0x98,0xaf,1,1},
{enctable + 1621,utf8_AdobeZdingbat,0xb1,0xbe,1,1},
{0,utf8_AdobeZdingbat_e2_9e,0xbf,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_e2[10] = {
#else
static const encpage_t utf8_AdobeZdingbat_e2[10] = {
#endif
{0,utf8_AdobeZdingbat_e2_86,0x86,0x86,0,2},
{0,utf8_AdobeZdingbat_e2_91,0x91,0x91,0,2},
{0,utf8_AdobeZdingbat_e2_96,0x96,0x96,0,2},
{0,utf8_AdobeZdingbat_e2_97,0x97,0x97,0,2},
{0,utf8_AdobeZdingbat_e2_98,0x98,0x98,0,2},
{0,utf8_AdobeZdingbat_e2_99,0x99,0x99,0,2},
{0,utf8_AdobeZdingbat_e2_9c,0x9c,0x9c,0,2},
{0,utf8_AdobeZdingbat_e2_9d,0x9d,0x9d,0,2},
{0,utf8_AdobeZdingbat_e2_9e,0x9e,0x9e,0,2},
{0,utf8_AdobeZdingbat_e2,0x9f,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_ef_a3[2] = {
#else
static const encpage_t utf8_AdobeZdingbat_ef_a3[2] = {
#endif
{enctable + 1328,utf8_AdobeZdingbat,0x97,0xa4,1,1},
{0,utf8_AdobeZdingbat_ef_a3,0xa5,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat_ef[2] = {
#else
static const encpage_t utf8_AdobeZdingbat_ef[2] = {
#endif
{0,utf8_AdobeZdingbat_ef_a3,0xa3,0xa3,0,2},
{0,utf8_AdobeZdingbat_ef,0xa4,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_AdobeZdingbat[5] = {
#else
static const encpage_t utf8_AdobeZdingbat[5] = {
#endif
{enctable + 1294,utf8_AdobeZdingbat,0x00,0x20,1,1},
{0,utf8_AdobeZdingbat_c2,0xc2,0xc2,0,2},
{0,utf8_AdobeZdingbat_e2,0xe2,0xe2,0,3},
{0,utf8_AdobeZdingbat_ef,0xef,0xef,0,3},
{0,utf8_AdobeZdingbat,0xf0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t MacDingbats_utf8[6] = {
#else
static const encpage_t MacDingbats_utf8[6] = {
#endif
{enctable + 1294,MacDingbats_utf8,0x00,0x20,1,1},
{enctable + 0,MacDingbats_utf8,0x21,0x7e,3,1},
{enctable + 1168,MacDingbats_utf8,0x80,0x8d,3,1},
{enctable + 282,MacDingbats_utf8,0xa1,0xef,3,1},
{enctable + 1210,MacDingbats_utf8,0xf1,0xfe,3,1},
{0,MacDingbats_utf8,0xff,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_86[3] = {
#else
static const encpage_t utf8_MacDingbats_e2_86[3] = {
#endif
{enctable + 1858,utf8_MacDingbats,0x92,0x92,1,1},
{enctable + 1846,utf8_MacDingbats,0x94,0x95,1,1},
{0,utf8_MacDingbats_e2_86,0x96,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_91[2] = {
#else
static const encpage_t utf8_MacDingbats_e2_91[2] = {
#endif
{enctable + 1681,utf8_MacDingbats,0xa0,0xa9,1,1},
{0,utf8_MacDingbats_e2_91,0xaa,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_96[4] = {
#else
static const encpage_t utf8_MacDingbats_e2_96[4] = {
#endif
{enctable + 1618,utf8_MacDingbats,0xa0,0xa0,1,1},
{enctable + 1674,utf8_MacDingbats,0xb2,0xb2,1,1},
{enctable + 1675,utf8_MacDingbats,0xbc,0xbc,1,1},
{0,utf8_MacDingbats_e2_96,0xbd,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_97[4] = {
#else
static const encpage_t utf8_MacDingbats_e2_97[4] = {
#endif
{enctable + 1676,utf8_MacDingbats,0x86,0x86,1,1},
{enctable + 1616,utf8_MacDingbats,0x8f,0x8f,1,1},
{enctable + 1680,utf8_MacDingbats,0x97,0x97,1,1},
{0,utf8_MacDingbats_e2_97,0x98,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_98[5] = {
#else
static const encpage_t utf8_MacDingbats_e2_98[5] = {
#endif
{enctable + 1595,utf8_MacDingbats,0x85,0x85,1,1},
{enctable + 1816,utf8_MacDingbats,0x8e,0x8e,1,1},
{enctable + 1856,utf8_MacDingbats,0x9b,0x9b,1,1},
{enctable + 1818,utf8_MacDingbats,0x9e,0x9e,1,1},
{0,utf8_MacDingbats_e2_98,0x9f,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_99[4] = {
#else
static const encpage_t utf8_MacDingbats_e2_99[4] = {
#endif
{enctable + 128,utf8_MacDingbats,0xa0,0xa0,1,1},
{enctable + 341,utf8_MacDingbats,0xa3,0xa3,1,1},
{enctable + 1828,utf8_MacDingbats,0xa5,0xa6,1,1},
{0,utf8_MacDingbats_e2_99,0xa7,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_9c[5] = {
#else
static const encpage_t utf8_MacDingbats_e2_9c[5] = {
#endif
{enctable + 1751,utf8_MacDingbats,0x81,0x84,1,1},
{enctable + 1755,utf8_MacDingbats,0x86,0x89,1,1},
{enctable + 1391,utf8_MacDingbats,0x8c,0xa7,1,1},
{enctable + 1524,utf8_MacDingbats,0xa9,0xbf,1,1},
{0,utf8_MacDingbats_e2_9c,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_9d[7] = {
#else
static const encpage_t utf8_MacDingbats_e2_9d[7] = {
#endif
{enctable + 1635,utf8_MacDingbats,0x80,0x8b,1,1},
{enctable + 1617,utf8_MacDingbats,0x8d,0x8d,1,1},
{enctable + 1759,utf8_MacDingbats,0x8f,0x92,1,1},
{enctable + 1823,utf8_MacDingbats,0x96,0x96,1,1},
{enctable + 1717,utf8_MacDingbats,0x98,0x9e,1,1},
{enctable + 1360,utf8_MacDingbats,0xa1,0xbf,1,1},
{0,utf8_MacDingbats_e2_9d,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2_9e[4] = {
#else
static const encpage_t utf8_MacDingbats_e2_9e[4] = {
#endif
{enctable + 1547,utf8_MacDingbats,0x80,0x94,1,1},
{enctable + 1500,utf8_MacDingbats,0x98,0xaf,1,1},
{enctable + 1621,utf8_MacDingbats,0xb1,0xbe,1,1},
{0,utf8_MacDingbats_e2_9e,0xbf,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats_e2[10] = {
#else
static const encpage_t utf8_MacDingbats_e2[10] = {
#endif
{0,utf8_MacDingbats_e2_86,0x86,0x86,0,2},
{0,utf8_MacDingbats_e2_91,0x91,0x91,0,2},
{0,utf8_MacDingbats_e2_96,0x96,0x96,0,2},
{0,utf8_MacDingbats_e2_97,0x97,0x97,0,2},
{0,utf8_MacDingbats_e2_98,0x98,0x98,0,2},
{0,utf8_MacDingbats_e2_99,0x99,0x99,0,2},
{0,utf8_MacDingbats_e2_9c,0x9c,0x9c,0,2},
{0,utf8_MacDingbats_e2_9d,0x9d,0x9d,0,2},
{0,utf8_MacDingbats_e2_9e,0x9e,0x9e,0,2},
{0,utf8_MacDingbats_e2,0x9f,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacDingbats[3] = {
#else
static const encpage_t utf8_MacDingbats[3] = {
#endif
{enctable + 1294,utf8_MacDingbats,0x00,0x20,1,1},
{0,utf8_MacDingbats_e2,0xe2,0xe2,0,3},
{0,utf8_MacDingbats,0xe3,0xff,0,0},
};
#ifdef __cplusplus
encpage_t MacSymbol_utf8[41] = {
#else
static const encpage_t MacSymbol_utf8[41] = {
#endif
{enctable + 1294,MacSymbol_utf8,0x00,0x21,1,1},
{enctable + 1783,MacSymbol_utf8,0x22,0x22,3,1},
{enctable + 1753,MacSymbol_utf8,0x23,0x23,1,1},
{enctable + 1786,MacSymbol_utf8,0x24,0x24,3,1},
{enctable + 1816,MacSymbol_utf8,0x25,0x26,1,1},
{enctable + 1792,MacSymbol_utf8,0x27,0x27,3,1},
{enctable + 1757,MacSymbol_utf8,0x28,0x29,1,1},
{enctable + 1798,MacSymbol_utf8,0x2a,0x2a,3,1},
{enctable + 1818,MacSymbol_utf8,0x2b,0x2c,1,1},
{enctable + 1795,MacSymbol_utf8,0x2d,0x2d,3,1},
{enctable + 1393,MacSymbol_utf8,0x2e,0x3f,1,1},
{enctable + 1807,MacSymbol_utf8,0x40,0x40,3,1},
{enctable + 1012,MacSymbol_utf8,0x41,0x5a,2,1},
{enctable + 1542,MacSymbol_utf8,0x5b,0x5b,1,1},
{enctable + 1801,MacSymbol_utf8,0x5c,0x5c,3,1},
{enctable + 1544,MacSymbol_utf8,0x5d,0x5d,1,1},
{enctable + 1810,MacSymbol_utf8,0x5e,0x5e,3,1},
{enctable + 1546,MacSymbol_utf8,0x5f,0x5f,1,1},
{enctable + 1813,MacSymbol_utf8,0x60,0x60,3,1},
{enctable + 1116,MacSymbol_utf8,0x61,0x7a,2,1},
{enctable + 1720,MacSymbol_utf8,0x7b,0x7d,1,1},
{enctable + 1804,MacSymbol_utf8,0x7e,0x7e,3,1},
{enctable + 1780,MacSymbol_utf8,0xa0,0xa0,3,1},
{enctable + 1844,MacSymbol_utf8,0xa1,0xa1,2,1},
{enctable + 1647,MacSymbol_utf8,0xa2,0xa5,3,1},
{enctable + 1840,MacSymbol_utf8,0xa6,0xa6,2,1},
{enctable + 1473,MacSymbol_utf8,0xa7,0xaf,3,1},
{enctable + 1767,MacSymbol_utf8,0xb0,0xb1,2,1},
{enctable + 1724,MacSymbol_utf8,0xb2,0xb3,3,1},
{enctable + 1836,MacSymbol_utf8,0xb4,0xb4,2,1},
{enctable + 1701,MacSymbol_utf8,0xb5,0xb7,3,1},
{enctable + 1838,MacSymbol_utf8,0xb8,0xb8,2,1},
{enctable + 804,MacSymbol_utf8,0xb9,0xd1,3,1},
{enctable + 1763,MacSymbol_utf8,0xd2,0xd3,2,1},
{enctable + 1659,MacSymbol_utf8,0xd4,0xd7,3,1},
{enctable + 1834,MacSymbol_utf8,0xd8,0xd8,2,1},
{enctable + 1446,MacSymbol_utf8,0xd9,0xe1,3,1},
{enctable + 1691,MacSymbol_utf8,0xe2,0xe3,5,1},
{enctable + 1730,MacSymbol_utf8,0xe4,0xe4,6,1},
{enctable + 726,MacSymbol_utf8,0xe5,0xfe,3,1},
{0,MacSymbol_utf8,0xff,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_c2[5] = {
#else
static const encpage_t utf8_MacSymbol_c2[5] = {
#endif
{enctable + 1566,utf8_MacSymbol,0xa9,0xa9,1,1},
{enctable + 1500,utf8_MacSymbol,0xac,0xac,1,1},
{enctable + 1565,utf8_MacSymbol,0xae,0xae,1,1},
{enctable + 1685,utf8_MacSymbol,0xb0,0xb1,1,1},
{0,utf8_MacSymbol_c2,0xb2,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_c3[3] = {
#else
static const encpage_t utf8_MacSymbol_c3[3] = {
#endif
{enctable + 155,utf8_MacSymbol,0x97,0x97,1,1},
{enctable + 167,utf8_MacSymbol,0xb7,0xb7,1,1},
{0,utf8_MacSymbol_c3,0xb8,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_c6[2] = {
#else
static const encpage_t utf8_MacSymbol_c6[2] = {
#endif
{enctable + 113,utf8_MacSymbol,0x92,0x92,1,1},
{0,utf8_MacSymbol_c6,0x93,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_ce[4] = {
#else
static const encpage_t utf8_MacSymbol_ce[4] = {
#endif
{enctable + 1589,utf8_MacSymbol,0x91,0xa1,1,1},
{enctable + 1710,utf8_MacSymbol,0xa3,0xa9,1,1},
{enctable + 1606,utf8_MacSymbol,0xb1,0xbf,1,1},
{0,utf8_MacSymbol_ce,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_cf[4] = {
#else
static const encpage_t utf8_MacSymbol_cf[4] = {
#endif
{enctable + 1671,utf8_MacSymbol,0x80,0x89,1,1},
{enctable + 1820,utf8_MacSymbol,0x91,0x92,1,1},
{enctable + 1822,utf8_MacSymbol,0x95,0x96,1,1},
{0,utf8_MacSymbol_cf,0x97,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_80[4] = {
#else
static const encpage_t utf8_MacSymbol_e2_80[4] = {
#endif
{enctable + 164,utf8_MacSymbol,0xa2,0xa2,1,1},
{enctable + 179,utf8_MacSymbol,0xa6,0xa6,1,1},
{enctable + 1824,utf8_MacSymbol,0xb2,0xb3,1,1},
{0,utf8_MacSymbol_e2_80,0xb4,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_81[2] = {
#else
static const encpage_t utf8_MacSymbol_e2_81[2] = {
#endif
{enctable + 107,utf8_MacSymbol,0x84,0x84,1,1},
{0,utf8_MacSymbol_e2_81,0x85,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_82[2] = {
#else
static const encpage_t utf8_MacSymbol_e2_82[2] = {
#endif
{enctable + 95,utf8_MacSymbol,0xac,0xac,1,1},
{0,utf8_MacSymbol_e2_82,0xad,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_84[6] = {
#else
static const encpage_t utf8_MacSymbol_e2_84[6] = {
#endif
{enctable + 1548,utf8_MacSymbol,0x91,0x91,1,1},
{enctable + 1550,utf8_MacSymbol,0x98,0x98,1,1},
{enctable + 948,utf8_MacSymbol,0x9c,0x9c,1,1},
{enctable + 1567,utf8_MacSymbol,0xa2,0xa2,1,1},
{enctable + 1547,utf8_MacSymbol,0xb5,0xb5,1,1},
{0,utf8_MacSymbol_e2_84,0xb6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_86[3] = {
#else
static const encpage_t utf8_MacSymbol_e2_86[3] = {
#endif
{enctable + 1736,utf8_MacSymbol,0x90,0x94,1,1},
{enctable + 188,utf8_MacSymbol,0xb5,0xb5,1,1},
{0,utf8_MacSymbol_e2_86,0xb6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_87[2] = {
#else
static const encpage_t utf8_MacSymbol_e2_87[2] = {
#endif
{enctable + 1746,utf8_MacSymbol,0x90,0x94,1,1},
{0,utf8_MacSymbol_e2_87,0x95,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_88[15] = {
#else
static const encpage_t utf8_MacSymbol_e2_88[15] = {
#endif
{enctable + 1752,utf8_MacSymbol,0x80,0x80,1,1},
{enctable + 1832,utf8_MacSymbol,0x82,0x83,1,1},
{enctable + 1553,utf8_MacSymbol,0x85,0x85,1,1},
{enctable + 1774,utf8_MacSymbol,0x87,0x89,1,1},
{enctable + 1756,utf8_MacSymbol,0x8d,0x8d,1,1},
{enctable + 1858,utf8_MacSymbol,0x8f,0x8f,1,1},
{enctable + 1852,utf8_MacSymbol,0x91,0x92,1,1},
{enctable + 1856,utf8_MacSymbol,0x97,0x97,1,1},
{enctable + 1846,utf8_MacSymbol,0x9a,0x9a,1,1},
{enctable + 1830,utf8_MacSymbol,0x9d,0x9e,1,1},
{enctable + 1563,utf8_MacSymbol,0xa0,0xa0,1,1},
{enctable + 1741,utf8_MacSymbol,0xa7,0xab,1,1},
{enctable + 1543,utf8_MacSymbol,0xb4,0xb4,1,1},
{enctable + 1723,utf8_MacSymbol,0xbc,0xbc,1,1},
{0,utf8_MacSymbol_e2_88,0xbd,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_89[5] = {
#else
static const encpage_t utf8_MacSymbol_e2_89[5] = {
#endif
{enctable + 1411,utf8_MacSymbol,0x85,0x85,1,1},
{enctable + 176,utf8_MacSymbol,0x88,0x88,1,1},
{enctable + 1384,utf8_MacSymbol,0xa0,0xa1,1,1},
{enctable + 583,utf8_MacSymbol,0xa4,0xa5,1,1},
{0,utf8_MacSymbol_e2_89,0xa6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_8a[6] = {
#else
static const encpage_t utf8_MacSymbol_e2_8a[6] = {
#endif
{enctable + 1771,utf8_MacSymbol,0x82,0x84,1,1},
{enctable + 1842,utf8_MacSymbol,0x86,0x87,1,1},
{enctable + 1552,utf8_MacSymbol,0x95,0x95,1,1},
{enctable + 1551,utf8_MacSymbol,0x97,0x97,1,1},
{enctable + 1545,utf8_MacSymbol,0xa5,0xa5,1,1},
{0,utf8_MacSymbol_e2_8a,0xa6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_8b[2] = {
#else
static const encpage_t utf8_MacSymbol_e2_8b[2] = {
#endif
{enctable + 1848,utf8_MacSymbol,0x84,0x85,1,1},
{0,utf8_MacSymbol_e2_8b,0x86,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_8c[2] = {
#else
static const encpage_t utf8_MacSymbol_e2_8c[2] = {
#endif
{enctable + 1854,utf8_MacSymbol,0xa0,0xa1,1,1},
{0,utf8_MacSymbol_e2_8c,0xa2,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_8e[2] = {
#else
static const encpage_t utf8_MacSymbol_e2_8e[2] = {
#endif
{enctable + 1568,utf8_MacSymbol,0x9b,0xaf,1,1},
{0,utf8_MacSymbol_e2_8e,0xb0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2_99[4] = {
#else
static const encpage_t utf8_MacSymbol_e2_99[4] = {
#endif
{enctable + 125,utf8_MacSymbol,0xa0,0xa0,1,1},
{enctable + 116,utf8_MacSymbol,0xa3,0xa3,1,1},
{enctable + 1826,utf8_MacSymbol,0xa5,0xa6,1,1},
{0,utf8_MacSymbol_e2_99,0xa7,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e2[14] = {
#else
static const encpage_t utf8_MacSymbol_e2[14] = {
#endif
{0,utf8_MacSymbol_e2_80,0x80,0x80,0,2},
{0,utf8_MacSymbol_e2_81,0x81,0x81,0,2},
{0,utf8_MacSymbol_e2_82,0x82,0x82,0,2},
{0,utf8_MacSymbol_e2_84,0x84,0x84,0,2},
{0,utf8_MacSymbol_e2_86,0x86,0x86,0,2},
{0,utf8_MacSymbol_e2_87,0x87,0x87,0,2},
{0,utf8_MacSymbol_e2_88,0x88,0x88,0,2},
{0,utf8_MacSymbol_e2_89,0x89,0x89,0,2},
{0,utf8_MacSymbol_e2_8a,0x8a,0x8a,0,2},
{0,utf8_MacSymbol_e2_8b,0x8b,0x8b,0,2},
{0,utf8_MacSymbol_e2_8c,0x8c,0x8c,0,2},
{0,utf8_MacSymbol_e2_8e,0x8e,0x8e,0,2},
{0,utf8_MacSymbol_e2_99,0x99,0x99,0,2},
{0,utf8_MacSymbol_e2,0x9a,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e3_80[2] = {
#else
static const encpage_t utf8_MacSymbol_e3_80[2] = {
#endif
{enctable + 1850,utf8_MacSymbol,0x88,0x89,1,1},
{0,utf8_MacSymbol_e3_80,0x8a,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_e3[2] = {
#else
static const encpage_t utf8_MacSymbol_e3[2] = {
#endif
{0,utf8_MacSymbol_e3_80,0x80,0x80,0,2},
{0,utf8_MacSymbol_e3,0x81,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_ef_a3[3] = {
#else
static const encpage_t utf8_MacSymbol_ef_a3[3] = {
#endif
{enctable + 1419,utf8_MacSymbol,0xa5,0xa6,1,1},
{enctable + 1445,utf8_MacSymbol,0xbf,0xbf,1,1},
{0,utf8_MacSymbol_ef_a3,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol_ef[2] = {
#else
static const encpage_t utf8_MacSymbol_ef[2] = {
#endif
{0,utf8_MacSymbol_ef_a3,0xa3,0xa3,0,2},
{0,utf8_MacSymbol_ef,0xa4,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_MacSymbol[19] = {
#else
static const encpage_t utf8_MacSymbol[19] = {
#endif
{enctable + 1294,utf8_MacSymbol,0x00,0x21,1,1},
{enctable + 1753,utf8_MacSymbol,0x23,0x23,1,1},
{enctable + 1816,utf8_MacSymbol,0x25,0x26,1,1},
{enctable + 1757,utf8_MacSymbol,0x28,0x29,1,1},
{enctable + 1818,utf8_MacSymbol,0x2b,0x2c,1,1},
{enctable + 1393,utf8_MacSymbol,0x2e,0x3f,1,1},
{enctable + 1542,utf8_MacSymbol,0x5b,0x5b,1,1},
{enctable + 1544,utf8_MacSymbol,0x5d,0x5d,1,1},
{enctable + 1546,utf8_MacSymbol,0x5f,0x5f,1,1},
{enctable + 1720,utf8_MacSymbol,0x7b,0x7d,1,1},
{0,utf8_MacSymbol_c2,0xc2,0xc2,0,2},
{0,utf8_MacSymbol_c3,0xc3,0xc3,0,2},
{0,utf8_MacSymbol_c6,0xc6,0xc6,0,2},
{0,utf8_MacSymbol_ce,0xce,0xce,0,2},
{0,utf8_MacSymbol_cf,0xcf,0xcf,0,2},
{0,utf8_MacSymbol_e2,0xe2,0xe2,0,3},
{0,utf8_MacSymbol_e3,0xe3,0xe3,0,3},
{0,utf8_MacSymbol_ef,0xef,0xef,0,3},
{0,utf8_MacSymbol,0xf0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t dingbats_utf8[7] = {
#else
static const encpage_t dingbats_utf8[7] = {
#endif
{enctable + 1294,dingbats_utf8,0x00,0x20,1,1},
{enctable + 0,dingbats_utf8,0x21,0x7e,3,1},
{enctable + 1857,dingbats_utf8,0x7f,0x7f,1,1},
{enctable + 948,dingbats_utf8,0x80,0x9f,2,1},
{enctable + 282,dingbats_utf8,0xa1,0xef,3,1},
{enctable + 1210,dingbats_utf8,0xf1,0xfe,3,1},
{0,dingbats_utf8,0xff,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_c2[2] = {
#else
static const encpage_t utf8_dingbats_c2[2] = {
#endif
{enctable + 1328,utf8_dingbats,0x80,0x9f,1,1},
{0,utf8_dingbats_c2,0xa0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_86[3] = {
#else
static const encpage_t utf8_dingbats_e2_86[3] = {
#endif
{enctable + 1858,utf8_dingbats,0x92,0x92,1,1},
{enctable + 1846,utf8_dingbats,0x94,0x95,1,1},
{0,utf8_dingbats_e2_86,0x96,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_91[2] = {
#else
static const encpage_t utf8_dingbats_e2_91[2] = {
#endif
{enctable + 1681,utf8_dingbats,0xa0,0xa9,1,1},
{0,utf8_dingbats_e2_91,0xaa,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_96[4] = {
#else
static const encpage_t utf8_dingbats_e2_96[4] = {
#endif
{enctable + 1618,utf8_dingbats,0xa0,0xa0,1,1},
{enctable + 1674,utf8_dingbats,0xb2,0xb2,1,1},
{enctable + 1675,utf8_dingbats,0xbc,0xbc,1,1},
{0,utf8_dingbats_e2_96,0xbd,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_97[4] = {
#else
static const encpage_t utf8_dingbats_e2_97[4] = {
#endif
{enctable + 1676,utf8_dingbats,0x86,0x86,1,1},
{enctable + 1616,utf8_dingbats,0x8f,0x8f,1,1},
{enctable + 1680,utf8_dingbats,0x97,0x97,1,1},
{0,utf8_dingbats_e2_97,0x98,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_98[5] = {
#else
static const encpage_t utf8_dingbats_e2_98[5] = {
#endif
{enctable + 1595,utf8_dingbats,0x85,0x85,1,1},
{enctable + 1816,utf8_dingbats,0x8e,0x8e,1,1},
{enctable + 1856,utf8_dingbats,0x9b,0x9b,1,1},
{enctable + 1818,utf8_dingbats,0x9e,0x9e,1,1},
{0,utf8_dingbats_e2_98,0x9f,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_99[4] = {
#else
static const encpage_t utf8_dingbats_e2_99[4] = {
#endif
{enctable + 128,utf8_dingbats,0xa0,0xa0,1,1},
{enctable + 341,utf8_dingbats,0xa3,0xa3,1,1},
{enctable + 1828,utf8_dingbats,0xa5,0xa6,1,1},
{0,utf8_dingbats_e2_99,0xa7,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_9c[5] = {
#else
static const encpage_t utf8_dingbats_e2_9c[5] = {
#endif
{enctable + 1751,utf8_dingbats,0x81,0x84,1,1},
{enctable + 1755,utf8_dingbats,0x86,0x89,1,1},
{enctable + 1391,utf8_dingbats,0x8c,0xa7,1,1},
{enctable + 1524,utf8_dingbats,0xa9,0xbf,1,1},
{0,utf8_dingbats_e2_9c,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_9d[8] = {
#else
static const encpage_t utf8_dingbats_e2_9d[8] = {
#endif
{enctable + 1635,utf8_dingbats,0x80,0x8b,1,1},
{enctable + 1617,utf8_dingbats,0x8d,0x8d,1,1},
{enctable + 1759,utf8_dingbats,0x8f,0x92,1,1},
{enctable + 1823,utf8_dingbats,0x96,0x96,1,1},
{enctable + 1717,utf8_dingbats,0x98,0x9e,1,1},
{enctable + 1360,utf8_dingbats,0xa1,0xa7,1,1},
{enctable + 1381,utf8_dingbats,0xb6,0xbf,1,1},
{0,utf8_dingbats_e2_9d,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2_9e[4] = {
#else
static const encpage_t utf8_dingbats_e2_9e[4] = {
#endif
{enctable + 1547,utf8_dingbats,0x80,0x94,1,1},
{enctable + 1500,utf8_dingbats,0x98,0xaf,1,1},
{enctable + 1621,utf8_dingbats,0xb1,0xbe,1,1},
{0,utf8_dingbats_e2_9e,0xbf,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats_e2[10] = {
#else
static const encpage_t utf8_dingbats_e2[10] = {
#endif
{0,utf8_dingbats_e2_86,0x86,0x86,0,2},
{0,utf8_dingbats_e2_91,0x91,0x91,0,2},
{0,utf8_dingbats_e2_96,0x96,0x96,0,2},
{0,utf8_dingbats_e2_97,0x97,0x97,0,2},
{0,utf8_dingbats_e2_98,0x98,0x98,0,2},
{0,utf8_dingbats_e2_99,0x99,0x99,0,2},
{0,utf8_dingbats_e2_9c,0x9c,0x9c,0,2},
{0,utf8_dingbats_e2_9d,0x9d,0x9d,0,2},
{0,utf8_dingbats_e2_9e,0x9e,0x9e,0,2},
{0,utf8_dingbats_e2,0x9f,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_dingbats[5] = {
#else
static const encpage_t utf8_dingbats[5] = {
#endif
{enctable + 1294,utf8_dingbats,0x00,0x20,1,1},
{enctable + 1857,utf8_dingbats,0x7f,0x7f,1,1},
{0,utf8_dingbats_c2,0xc2,0xc2,0,2},
{0,utf8_dingbats_e2,0xe2,0xe2,0,3},
{0,utf8_dingbats,0xe3,0xff,0,0},
};
#ifdef __cplusplus
encpage_t symbol_utf8[39] = {
#else
static const encpage_t symbol_utf8[39] = {
#endif
{enctable + 1294,symbol_utf8,0x00,0x21,1,1},
{enctable + 1783,symbol_utf8,0x22,0x22,3,1},
{enctable + 1753,symbol_utf8,0x23,0x23,1,1},
{enctable + 1786,symbol_utf8,0x24,0x24,3,1},
{enctable + 1816,symbol_utf8,0x25,0x26,1,1},
{enctable + 1792,symbol_utf8,0x27,0x27,3,1},
{enctable + 1757,symbol_utf8,0x28,0x29,1,1},
{enctable + 1798,symbol_utf8,0x2a,0x2a,3,1},
{enctable + 1818,symbol_utf8,0x2b,0x2c,1,1},
{enctable + 1795,symbol_utf8,0x2d,0x2d,3,1},
{enctable + 1393,symbol_utf8,0x2e,0x3f,1,1},
{enctable + 1807,symbol_utf8,0x40,0x40,3,1},
{enctable + 1012,symbol_utf8,0x41,0x5a,2,1},
{enctable + 1542,symbol_utf8,0x5b,0x5b,1,1},
{enctable + 1801,symbol_utf8,0x5c,0x5c,3,1},
{enctable + 1544,symbol_utf8,0x5d,0x5d,1,1},
{enctable + 1810,symbol_utf8,0x5e,0x5e,3,1},
{enctable + 1546,symbol_utf8,0x5f,0x5f,1,1},
{enctable + 1813,symbol_utf8,0x60,0x60,3,1},
{enctable + 1116,symbol_utf8,0x61,0x7a,2,1},
{enctable + 1720,symbol_utf8,0x7b,0x7d,1,1},
{enctable + 1804,symbol_utf8,0x7e,0x7e,3,1},
{enctable + 1857,symbol_utf8,0x7f,0x7f,1,1},
{enctable + 948,symbol_utf8,0x80,0x9f,2,1},
{enctable + 1844,symbol_utf8,0xa1,0xa1,2,1},
{enctable + 1647,symbol_utf8,0xa2,0xa5,3,1},
{enctable + 1840,symbol_utf8,0xa6,0xa6,2,1},
{enctable + 1473,symbol_utf8,0xa7,0xaf,3,1},
{enctable + 1767,symbol_utf8,0xb0,0xb1,2,1},
{enctable + 1724,symbol_utf8,0xb2,0xb3,3,1},
{enctable + 1836,symbol_utf8,0xb4,0xb4,2,1},
{enctable + 1701,symbol_utf8,0xb5,0xb7,3,1},
{enctable + 1838,symbol_utf8,0xb8,0xb8,2,1},
{enctable + 633,symbol_utf8,0xb9,0xd1,3,1},
{enctable + 1763,symbol_utf8,0xd2,0xd3,2,1},
{enctable + 1659,symbol_utf8,0xd4,0xd7,3,1},
{enctable + 1834,symbol_utf8,0xd8,0xd8,2,1},
{enctable + 519,symbol_utf8,0xd9,0xfe,3,1},
{0,symbol_utf8,0xff,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_c2[6] = {
#else
static const encpage_t utf8_symbol_c2[6] = {
#endif
{enctable + 1328,utf8_symbol,0x80,0x9f,1,1},
{enctable + 1566,utf8_symbol,0xa9,0xa9,1,1},
{enctable + 1500,utf8_symbol,0xac,0xac,1,1},
{enctable + 1565,utf8_symbol,0xae,0xae,1,1},
{enctable + 1685,utf8_symbol,0xb0,0xb1,1,1},
{0,utf8_symbol_c2,0xb2,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_c3[3] = {
#else
static const encpage_t utf8_symbol_c3[3] = {
#endif
{enctable + 155,utf8_symbol,0x97,0x97,1,1},
{enctable + 167,utf8_symbol,0xb7,0xb7,1,1},
{0,utf8_symbol_c3,0xb8,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_c6[2] = {
#else
static const encpage_t utf8_symbol_c6[2] = {
#endif
{enctable + 113,utf8_symbol,0x92,0x92,1,1},
{0,utf8_symbol_c6,0x93,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_ce[4] = {
#else
static const encpage_t utf8_symbol_ce[4] = {
#endif
{enctable + 1589,utf8_symbol,0x91,0xa1,1,1},
{enctable + 1710,utf8_symbol,0xa3,0xa9,1,1},
{enctable + 1606,utf8_symbol,0xb1,0xbf,1,1},
{0,utf8_symbol_ce,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_cf[4] = {
#else
static const encpage_t utf8_symbol_cf[4] = {
#endif
{enctable + 1671,utf8_symbol,0x80,0x89,1,1},
{enctable + 1820,utf8_symbol,0x91,0x92,1,1},
{enctable + 1822,utf8_symbol,0x95,0x96,1,1},
{0,utf8_symbol_cf,0x97,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_80[4] = {
#else
static const encpage_t utf8_symbol_e2_80[4] = {
#endif
{enctable + 164,utf8_symbol,0xa2,0xa2,1,1},
{enctable + 179,utf8_symbol,0xa6,0xa6,1,1},
{enctable + 1824,utf8_symbol,0xb2,0xb3,1,1},
{0,utf8_symbol_e2_80,0xb4,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_81[2] = {
#else
static const encpage_t utf8_symbol_e2_81[2] = {
#endif
{enctable + 107,utf8_symbol,0x84,0x84,1,1},
{0,utf8_symbol_e2_81,0x85,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_84[6] = {
#else
static const encpage_t utf8_symbol_e2_84[6] = {
#endif
{enctable + 1548,utf8_symbol,0x91,0x91,1,1},
{enctable + 1550,utf8_symbol,0x98,0x98,1,1},
{enctable + 948,utf8_symbol,0x9c,0x9c,1,1},
{enctable + 1567,utf8_symbol,0xa2,0xa2,1,1},
{enctable + 1547,utf8_symbol,0xb5,0xb5,1,1},
{0,utf8_symbol_e2_84,0xb6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_86[3] = {
#else
static const encpage_t utf8_symbol_e2_86[3] = {
#endif
{enctable + 1736,utf8_symbol,0x90,0x94,1,1},
{enctable + 188,utf8_symbol,0xb5,0xb5,1,1},
{0,utf8_symbol_e2_86,0xb6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_87[2] = {
#else
static const encpage_t utf8_symbol_e2_87[2] = {
#endif
{enctable + 1746,utf8_symbol,0x90,0x94,1,1},
{0,utf8_symbol_e2_87,0x95,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_88[15] = {
#else
static const encpage_t utf8_symbol_e2_88[15] = {
#endif
{enctable + 1752,utf8_symbol,0x80,0x80,1,1},
{enctable + 1832,utf8_symbol,0x82,0x83,1,1},
{enctable + 1553,utf8_symbol,0x85,0x85,1,1},
{enctable + 1774,utf8_symbol,0x87,0x89,1,1},
{enctable + 1756,utf8_symbol,0x8d,0x8d,1,1},
{enctable + 1858,utf8_symbol,0x8f,0x8f,1,1},
{enctable + 1852,utf8_symbol,0x91,0x92,1,1},
{enctable + 1856,utf8_symbol,0x97,0x97,1,1},
{enctable + 1846,utf8_symbol,0x9a,0x9a,1,1},
{enctable + 1830,utf8_symbol,0x9d,0x9e,1,1},
{enctable + 1563,utf8_symbol,0xa0,0xa0,1,1},
{enctable + 1741,utf8_symbol,0xa7,0xab,1,1},
{enctable + 1543,utf8_symbol,0xb4,0xb4,1,1},
{enctable + 1723,utf8_symbol,0xbc,0xbc,1,1},
{0,utf8_symbol_e2_88,0xbd,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_89[5] = {
#else
static const encpage_t utf8_symbol_e2_89[5] = {
#endif
{enctable + 1411,utf8_symbol,0x85,0x85,1,1},
{enctable + 176,utf8_symbol,0x88,0x88,1,1},
{enctable + 1384,utf8_symbol,0xa0,0xa1,1,1},
{enctable + 583,utf8_symbol,0xa4,0xa5,1,1},
{0,utf8_symbol_e2_89,0xa6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_8a[6] = {
#else
static const encpage_t utf8_symbol_e2_8a[6] = {
#endif
{enctable + 1771,utf8_symbol,0x82,0x84,1,1},
{enctable + 1842,utf8_symbol,0x86,0x87,1,1},
{enctable + 1552,utf8_symbol,0x95,0x95,1,1},
{enctable + 1551,utf8_symbol,0x97,0x97,1,1},
{enctable + 1545,utf8_symbol,0xa5,0xa5,1,1},
{0,utf8_symbol_e2_8a,0xa6,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_8b[2] = {
#else
static const encpage_t utf8_symbol_e2_8b[2] = {
#endif
{enctable + 1848,utf8_symbol,0x84,0x85,1,1},
{0,utf8_symbol_e2_8b,0x86,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_8c[3] = {
#else
static const encpage_t utf8_symbol_e2_8c[3] = {
#endif
{enctable + 1854,utf8_symbol,0xa0,0xa1,1,1},
{enctable + 1850,utf8_symbol,0xa9,0xaa,1,1},
{0,utf8_symbol_e2_8c,0xab,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2_99[4] = {
#else
static const encpage_t utf8_symbol_e2_99[4] = {
#endif
{enctable + 125,utf8_symbol,0xa0,0xa0,1,1},
{enctable + 116,utf8_symbol,0xa3,0xa3,1,1},
{enctable + 1826,utf8_symbol,0xa5,0xa6,1,1},
{0,utf8_symbol_e2_99,0xa7,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_e2[12] = {
#else
static const encpage_t utf8_symbol_e2[12] = {
#endif
{0,utf8_symbol_e2_80,0x80,0x80,0,2},
{0,utf8_symbol_e2_81,0x81,0x81,0,2},
{0,utf8_symbol_e2_84,0x84,0x84,0,2},
{0,utf8_symbol_e2_86,0x86,0x86,0,2},
{0,utf8_symbol_e2_87,0x87,0x87,0,2},
{0,utf8_symbol_e2_88,0x88,0x88,0,2},
{0,utf8_symbol_e2_89,0x89,0x89,0,2},
{0,utf8_symbol_e2_8a,0x8a,0x8a,0,2},
{0,utf8_symbol_e2_8b,0x8b,0x8b,0,2},
{0,utf8_symbol_e2_8c,0x8c,0x8c,0,2},
{0,utf8_symbol_e2_99,0x99,0x99,0,2},
{0,utf8_symbol_e2,0x9a,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_ef_a3[2] = {
#else
static const encpage_t utf8_symbol_ef_a3[2] = {
#endif
{enctable + 1419,utf8_symbol,0xa5,0xbf,1,1},
{0,utf8_symbol_ef_a3,0xc0,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol_ef[2] = {
#else
static const encpage_t utf8_symbol_ef[2] = {
#endif
{0,utf8_symbol_ef_a3,0xa3,0xa3,0,2},
{0,utf8_symbol_ef,0xa4,0xff,0,0},
};
#ifdef __cplusplus
encpage_t utf8_symbol[19] = {
#else
static const encpage_t utf8_symbol[19] = {
#endif
{enctable + 1294,utf8_symbol,0x00,0x21,1,1},
{enctable + 1753,utf8_symbol,0x23,0x23,1,1},
{enctable + 1816,utf8_symbol,0x25,0x26,1,1},
{enctable + 1757,utf8_symbol,0x28,0x29,1,1},
{enctable + 1818,utf8_symbol,0x2b,0x2c,1,1},
{enctable + 1393,utf8_symbol,0x2e,0x3f,1,1},
{enctable + 1542,utf8_symbol,0x5b,0x5b,1,1},
{enctable + 1544,utf8_symbol,0x5d,0x5d,1,1},
{enctable + 1546,utf8_symbol,0x5f,0x5f,1,1},
{enctable + 1720,utf8_symbol,0x7b,0x7d,1,1},
{enctable + 1857,utf8_symbol,0x7f,0x7f,1,1},
{0,utf8_symbol_c2,0xc2,0xc2,0,2},
{0,utf8_symbol_c3,0xc3,0xc3,0,2},
{0,utf8_symbol_c6,0xc6,0xc6,0,2},
{0,utf8_symbol_ce,0xce,0xce,0,2},
{0,utf8_symbol_cf,0xcf,0xcf,0,2},
{0,utf8_symbol_e2,0xe2,0xe2,0,3},
{0,utf8_symbol_ef,0xef,0xef,0,3},
{0,utf8_symbol,0xf0,0xff,0,0},
};
static const U8 AdobeSymbol_encoding_rep_character[] = "\x3F";
static const char AdobeSymbol_encoding_enc_name[] = "AdobeSymbol";

 const encode_t AdobeSymbol_encoding = 
 {AdobeSymbol_utf8,utf8_AdobeSymbol,AdobeSymbol_encoding_rep_character,1,1,1,{AdobeSymbol_encoding_enc_name,(const char *)0}};

static const U8 AdobeZdingbat_encoding_rep_character[] = "\x3F";
static const char AdobeZdingbat_encoding_enc_name[] = "AdobeZdingbat";

 const encode_t AdobeZdingbat_encoding = 
 {AdobeZdingbat_utf8,utf8_AdobeZdingbat,AdobeZdingbat_encoding_rep_character,1,1,1,{AdobeZdingbat_encoding_enc_name,(const char *)0}};

static const U8 MacDingbats_encoding_rep_character[] = "\x3F";
static const char MacDingbats_encoding_enc_name[] = "MacDingbats";

 const encode_t MacDingbats_encoding = 
 {MacDingbats_utf8,utf8_MacDingbats,MacDingbats_encoding_rep_character,1,1,1,{MacDingbats_encoding_enc_name,(const char *)0}};

static const U8 MacSymbol_encoding_rep_character[] = "\x3F";
static const char MacSymbol_encoding_enc_name[] = "MacSymbol";

 const encode_t MacSymbol_encoding = 
 {MacSymbol_utf8,utf8_MacSymbol,MacSymbol_encoding_rep_character,1,1,1,{MacSymbol_encoding_enc_name,(const char *)0}};

static const U8 dingbats_encoding_rep_character[] = "\x3F";
static const char dingbats_encoding_enc_name[] = "dingbats";

 const encode_t dingbats_encoding = 
 {dingbats_utf8,utf8_dingbats,dingbats_encoding_rep_character,1,1,1,{dingbats_encoding_enc_name,(const char *)0}};

static const U8 symbol_encoding_rep_character[] = "\x3F";
static const char symbol_encoding_enc_name[] = "symbol";

 const encode_t symbol_encoding = 
 {symbol_utf8,utf8_symbol,symbol_encoding_rep_character,1,1,1,{symbol_encoding_enc_name,(const char *)0}};


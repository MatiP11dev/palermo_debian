extern encode_t cp936_encoding;

extern encode_t ascii_encoding;
extern encode_t ascii_ctrl_encoding;
extern encode_t cp1252_encoding;
extern encode_t iso_8859_1_encoding;
extern encode_t null_encoding;

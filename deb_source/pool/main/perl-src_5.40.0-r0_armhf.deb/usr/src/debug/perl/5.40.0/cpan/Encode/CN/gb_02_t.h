extern encode_t gb12345_raw_encoding;

extern encode_t MacJapanese_encoding;

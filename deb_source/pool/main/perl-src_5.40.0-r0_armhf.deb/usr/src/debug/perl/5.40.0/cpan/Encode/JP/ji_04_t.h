extern encode_t jis0212_raw_encoding;

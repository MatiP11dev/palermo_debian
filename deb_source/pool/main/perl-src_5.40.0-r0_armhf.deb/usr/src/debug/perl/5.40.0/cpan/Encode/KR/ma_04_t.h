extern encode_t MacKorean_encoding;

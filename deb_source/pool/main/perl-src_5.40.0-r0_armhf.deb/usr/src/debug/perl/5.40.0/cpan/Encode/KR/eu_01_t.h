extern encode_t euc_kr_encoding;

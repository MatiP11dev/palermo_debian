extern encode_t euc_jp_encoding;

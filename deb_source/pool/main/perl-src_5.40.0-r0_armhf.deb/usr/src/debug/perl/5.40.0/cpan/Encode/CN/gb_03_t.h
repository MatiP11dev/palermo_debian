extern encode_t gb2312_raw_encoding;

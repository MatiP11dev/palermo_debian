extern encode_t ksc5601_raw_encoding;

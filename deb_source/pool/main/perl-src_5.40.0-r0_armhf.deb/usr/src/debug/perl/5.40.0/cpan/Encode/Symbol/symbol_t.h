extern encode_t AdobeSymbol_encoding;
extern encode_t AdobeZdingbat_encoding;
extern encode_t MacDingbats_encoding;
extern encode_t MacSymbol_encoding;
extern encode_t dingbats_encoding;
extern encode_t symbol_encoding;

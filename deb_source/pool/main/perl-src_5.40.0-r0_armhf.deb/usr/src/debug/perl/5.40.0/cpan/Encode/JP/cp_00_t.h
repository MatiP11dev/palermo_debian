extern encode_t cp932_encoding;

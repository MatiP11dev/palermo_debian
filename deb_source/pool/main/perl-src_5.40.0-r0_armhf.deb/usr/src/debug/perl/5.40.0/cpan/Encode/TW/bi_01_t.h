extern encode_t big5_hkscs_encoding;

extern encode_t euc_cn_encoding;

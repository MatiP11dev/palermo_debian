extern encode_t jis0208_raw_encoding;

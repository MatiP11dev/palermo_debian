extern encode_t iso_ir_165_encoding;

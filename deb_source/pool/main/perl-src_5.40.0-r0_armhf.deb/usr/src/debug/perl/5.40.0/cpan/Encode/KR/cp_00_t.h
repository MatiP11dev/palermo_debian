extern encode_t cp949_encoding;

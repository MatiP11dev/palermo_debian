/* Locale-specific memory comparison.

   Copyright (C) 1999, 2003, 2009-2024 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* Contributed by Paul Eggert <eggert@twinsun.com>.  */

#ifndef MEMCOLL_H_
# define MEMCOLL_H_ 1

# include <stddef.h>

int memcoll (char *restrict, size_t, char *restrict, size_t);
int memcoll0 (char const *, size_t, char const *, size_t);

#endif /* MEMCOLL_H_ */

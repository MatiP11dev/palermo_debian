extern const struct bluetooth_plugin_desc __bluetooth_builtin_hostname;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_wiimote;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_autopair;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_policy;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_a2dp;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_avrcp;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_network;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_input;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_hog;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_gap;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_scanparam;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_deviceinfo;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_battery;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_bap;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_bass;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_mcp;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_vcp;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_micp;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_ccp;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_csip;
extern const struct bluetooth_plugin_desc __bluetooth_builtin_asha;

static const struct bluetooth_plugin_desc *__bluetooth_builtin[] = {
  &__bluetooth_builtin_hostname,
  &__bluetooth_builtin_wiimote,
  &__bluetooth_builtin_autopair,
  &__bluetooth_builtin_policy,
  &__bluetooth_builtin_a2dp,
  &__bluetooth_builtin_avrcp,
  &__bluetooth_builtin_network,
  &__bluetooth_builtin_input,
  &__bluetooth_builtin_hog,
  &__bluetooth_builtin_gap,
  &__bluetooth_builtin_scanparam,
  &__bluetooth_builtin_deviceinfo,
  &__bluetooth_builtin_battery,
  &__bluetooth_builtin_bap,
  &__bluetooth_builtin_bass,
  &__bluetooth_builtin_mcp,
  &__bluetooth_builtin_vcp,
  &__bluetooth_builtin_micp,
  &__bluetooth_builtin_ccp,
  &__bluetooth_builtin_csip,
  &__bluetooth_builtin_asha,
  NULL
};

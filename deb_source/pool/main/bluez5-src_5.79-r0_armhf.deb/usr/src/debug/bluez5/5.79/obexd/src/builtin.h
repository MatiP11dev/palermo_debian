extern const struct obex_plugin_desc __obex_builtin_filesystem;
extern const struct obex_plugin_desc __obex_builtin_bluetooth;
extern const struct obex_plugin_desc __obex_builtin_opp;
extern const struct obex_plugin_desc __obex_builtin_ftp;
extern const struct obex_plugin_desc __obex_builtin_irmc;
extern const struct obex_plugin_desc __obex_builtin_pbap;
extern const struct obex_plugin_desc __obex_builtin_mas;
extern const struct obex_plugin_desc __obex_builtin_mns;

static const struct obex_plugin_desc *__obex_builtin[] = {
  &__obex_builtin_filesystem,
  &__obex_builtin_bluetooth,
  &__obex_builtin_opp,
  &__obex_builtin_ftp,
  &__obex_builtin_irmc,
  &__obex_builtin_pbap,
  &__obex_builtin_mas,
  &__obex_builtin_mns,
  NULL
};
